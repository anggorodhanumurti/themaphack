hcaptcha.render('your-form-id', {
  sitekey: 'd4fc641a-f214-4928-bb32-bcf824822438'
});