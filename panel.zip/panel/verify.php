<?php
if (isset($_POST['h-captcha-response'])) {
    $response = $_POST['h-captcha-response'];
    //$response = $_POST['h-captcha-response'];
    $secretKey = 'ES_328825da63424da38cd70562e382b39a';
    $url = 'https://hcaptcha.com/siteverify';
    $data = array('secret' => $secretKey, 'response' => $response);

    // Use cURL to send the POST request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    // Decode the JSON response
    $responseData = json_decode($response, true);
    
    // Check if the verification was successful
    if ($responseData['success']) {
        header('Location: https://t0pgamemurah.xyz/app/auth/login.php');
        exit;
    } else {
        header('Location: https://t0pgamemurah.xyz/');
        exit;
    }
} else {
    echo "hCaptcha response is missing. Please try again.";
}