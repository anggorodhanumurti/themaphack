<?php

if (empty($_SERVER['HTTP_USER_AGENT'])) {
    header("HTTP/1.1 403 Forbidden");
    header("Location: https://google.com");
    exit;
} else {
    //=============================END OF PROTECT=================================
    require 'app/mainconfig.php';
    require 'app/lib/partials/head-css.php';
    require 'app/lib/partials/title-meta.php';
}

?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>XYOURZONE</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
        <style>
            body {
                font-family: 'Montserrat', sans-serif;
                background: #f0f2f5;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
            .card {
                background: #ffffff;
                border-radius: 15px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                padding: 20px;
                text-align: center;
                width: 100%;
                max-width: 400px;
                position: relative;
                overflow: hidden;
                transition: transform 0.3s, box-shadow 0.3s;
            }
            .card:hover {
                transform: scale(1.02);
                box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            }
            .card::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 40%;
                background: linear-gradient(to bottom, rgba(0, 123, 255, 0.3), rgba(0, 123, 255, 0));
                z-index: 0;
            }
            .cover-photo {
                position: relative;
                margin-bottom: -60px;
                z-index: 1;
            }
            .cover-photo img {
                width: 120px;
                height: 120px;
                border-radius: 50%;
                border: 5px solid #007bff;
                object-fit: cover;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                display: block;
                margin: 0 auto;
            }
            .profile-name {
                font-size: 24px;
                color: #343a40;
                margin: 20px 0 10px;
                position: relative;
                z-index: 1;
            }
            .about {
                font-size: 14px;
                color: #6c757d;
                margin-bottom: 20px;
                position: relative;
                z-index: 1;
            }
            .btn-primary {
                background-color: #007bff;
                border: none;
                border-radius: 50px;
                padding: 12px 24px;
                font-size: 16px;
                color: #fff;
                transition: background-color 0.3s, transform 0.3s;
                position: relative;
                z-index: 1;
            }
            .btn-primary:hover {
                background-color: #0056b3;
                transform: scale(1.05);
            }
            .btn-primary:active {
                background-color: #004080;
                transform: scale(0.95);
            }
            .icons {
                margin-top: 20px;
                display: flex;
                justify-content: center;
                gap: 15px;
                position: relative;
                z-index: 1;
            }
            .icons a {
                text-decoration: none;
                color: #007bff;
                transition: color 0.3s;
            }
            .icons a:hover {
                color: #0056b3;
            }
            .icons i {
                font-size: 24px;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <p class="about">Before visiting our official website, you must to completely this captcha!</p>
            <form method="POST" action="verify.php">
                <div class="h-captcha" data-sitekey="d4fc641a-f214-4928-bb32-bcf824822438"></div>
                <button class="btn btn-primary" type="submit" name="Server2">Submit</button>
            </form>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
        <script src="https://hcaptcha.com/1/api.js" async defer></script>
    </body>
    </html>