<?php
require 'mainconfig.php';
unset($_SESSION['key']);
 
header("Location: ".$config['web']['base_url']."client/");
exit();