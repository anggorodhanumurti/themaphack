<?php
$page_type = "Login";
require '../mainconfig.php';


if (empty($_SERVER['HTTP_USER_AGENT'])) {
    header("HTTP/1.1 403 Forbidden");
    header("Location: https://google.com");
    exit;
} else {
    
    //=============================BEGIN OF PROTECT=================================
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $currentTime = time();
    $maxRequests = 1;
    $timeWindow = 1; // 1 second
    
    // Initialize IP data in session if it doesn't exist
    if (!isset($_SESSION['ip_data'][$ip])) {
        $_SESSION['ip_data'][$ip] = [
            'requests' => [],
            'blocked_until' => 0,
        ];
    }
    
    $ipData = &$_SESSION['ip_data'][$ip]; // Use reference for easier modification
    
    // Check if IP is currently blocked
    if ($ipData['blocked_until'] > $currentTime) {
        http_response_code(429); // Too Many Requests
        header("Location: https://google.com");
        die("You are temporarily blocked due to excessive requests.");
    }
    
    // Clean up old requests (older than the time window)
    $ipData['requests'] = array_filter($ipData['requests'], function ($timestamp) use ($currentTime, $timeWindow) {
        return $timestamp > ($currentTime - $timeWindow);
    });
    
    // Add current request
    $ipData['requests'][] = $currentTime;
    
    // Check if request limit is exceeded
    if (count($ipData['requests']) > $maxRequests) {
        // Block the IP for a certain duration (e.g., 60 seconds)
        $blockDuration = 60;
        $ipData['blocked_until'] = $currentTime + $blockDuration;
    
        // Log the blocked IP (important for monitoring)
        error_log("DDOS Protection: IP $ip blocked for $blockDuration seconds.");
    
        http_response_code(429); // Too Many Requests
        //die("You are temporarily blocked due to excessive requests.");
        header("Location: https://google.com");
        die("DDOS Protection: IP $ip blocked for $blockDuration seconds.");
    } else {
        error_log("DDOS Protection: IP $ip blocked for $blockDuration seconds.");
    
        http_response_code(429); // Too Many Requests
    }
    
    //=============================END OF PROTECT=================================
    
    
    function validate_user($username, $password) {
        
        $stmt = $db->prepare("SELECT password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($hashed_password);
            $stmt->fetch();
            
            if (password_verify($password, $hashed_password)) {
                return true;
            }
        }
        
        return false;
    }
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $remember = isset($_POST['remember']);
        
        $data = array('username', 'password');
    	$login = $model->db_query($db, "*", "users", "id = '".isset($_SESSION['login'])."'");
    	if (check_input($_POST, $data) == false) {
    		$result_msg = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'Input tidak sesuai.');
    	} else {
    		$input_post = array(
    			'username' => save_input($_POST['username']),
    			'password' => protect_input($_POST['password'])
    		);
    		if (check_empty($input_post) == true) {
    			$result_msg = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'Input tidak boleh kosong.');
    		} else {
    			$check_user = $model->db_query($db, "*", "users", "BINARY username = '".$input_post['username']."'");
    			if ($check_user['count'] == 1) {
    				if (password_verify($input_post['password'], $check_user['rows']['password']) == true) {
    					$model->db_insert($db, "login_logs", array('user_id' => $check_user['rows']['id'], 'ip_address' => get_client_ip(), 'user_agent' => $_SERVER['HTTP_USER_AGENT'], 'created_at' => date('Y-m-d H:i:s')));
    					$_SESSION['login'] = $check_user['rows']['id'];
    					$result_msg = array('alert' => 'success', 'title' => 'Berhasil masuk!', 'msg' => 'Selamat datang '.$check_user['rows']['username'].'!');
    					exit(header("Location: ".$config['web']['base_url']));
    				} else {
    					$result_msg = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'Username atau password salah.');
    				}
    			} else {
    				$result_msg = array('alert' => 'danger', 'title' => 'Gagal!', 'msg' => 'Username atau password salah.');
    			}
    		}
    	}
    }
    
    require '../lib/partials/head-css.php';
    require '../lib/partials/title-meta.php';
    require '../lib/is_login.php';
    require '../lib/csrf_token.php';

}


?>
<body oncontextmenu="return false">
    <div class="text_ads"> </div>
    <div id="app" data-bs-theme="light">
        <div class="container-fluid d-flex align-items-center vh-100">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-md-7 col-lg-6 col-xl-5 col-xxl-4">
                        <div class="card m-0" data-aos="zoom-in">
                            <div class="card-content">
                                <div class="card-body">
                                    
                                    <div class="theme-toggle d-flex gap-2  align-items-center mt-3 mt-sm-0">
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                                            class="iconify iconify--system-uicons" width="20" height="20"
                                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 21 21">
                                            <g fill="none" fill-rule="evenodd" stroke="currentColor"
                                                stroke-linecap="round" stroke-linejoin="round">
                                                <path
                                                    d="M10.5 14.5c2.219 0 4-1.763 4-3.982a4.003 4.003 0 0 0-4-4.018c-2.219 0-4 1.781-4 4c0 2.219 1.781 4 4 4zM4.136 4.136L5.55 5.55m9.9 9.9l1.414 1.414M1.5 10.5h2m14 0h2M4.135 16.863L5.55 15.45m9.899-9.9l1.414-1.415M10.5 19.5v-2m0-14v-2"
                                                    opacity=".3"></path>
                                                <g transform="translate(-210 -1)">
                                                    <path d="M220.5 2.5v2m6.5.5l-1.5 1.5"></path>
                                                    <circle cx="220.5" cy="11.5" r="4"></circle>
                                                    <path
                                                        d="m214 5l1.5 1.5m5 14v-2m6.5-.5l-1.5-1.5M214 18l1.5-1.5m-4-5h2m14 0h2">
                                                    </path>
                                                </g>
                                            </g>
                                        </svg>
                                        <div class="form-check form-switch fs-6">
                                            <input class="form-check-input  me-0" type="checkbox" id="toggle-dark"
                                                style="cursor: pointer">
                                            <label class="form-check-label"></label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                                            class="iconify iconify--mdi" width="20" height="20"
                                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="m17.75 4.09l-2.53 1.94l.91 3.06l-2.63-1.81l-2.63 1.81l.91-3.06l-2.53-1.94L12.44 4l1.06-3l1.06 3l3.19.09m3.5 6.91l-1.64 1.25l.59 1.98l-1.7-1.17l-1.7 1.17l.59-1.98L15.75 11l2.06-.05L18.5 9l.69 1.95l2.06.05m-2.28 4.95c.83-.08 1.72 1.1 1.19 1.85c-.32.45-.66.87-1.08 1.27C15.17 23 8.84 23 4.94 19.07c-3.91-3.9-3.91-10.24 0-14.14c.4-.4.82-.76 1.27-1.08c.75-.53 1.93.36 1.85 1.19c-.27 2.86.69 5.83 2.89 8.02a9.96 9.96 0 0 0 8.02 2.89m-1.64 2.02a12.08 12.08 0 0 1-7.8-3.47c-2.17-2.19-3.33-5-3.49-7.82c-2.81 3.14-2.7 7.96.31 10.98c3.02 3.01 7.84 3.12 10.98.31Z">
                                            </path>
                                        </svg>
                                    </div>
                                    
                                    <h4 class="header-title">Login</h4>
                                    <hr />
                                    <form method="POST">
                                        <input type="hidden" name="csrf_token" value="<?php echo $config['csrf_token'] ?>" />               
                                        <div class="form-group">
                                            <label>Username <font color="red">*</font></label>
                                            <input type="text" class="form-control" name="username" placeholder="username" autocomplete="off" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Password <font color="red">*</font></label>
                                            <div class="input-group input-group-merge">
                                                <input type="password" class="form-control" name="password" placeholder="password" autocomplete="off" required>
                                                <div class="input-group-append" data-password="false">
                                                    <div class="input-group-text">
                                                        <span class="password-eye">                 </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="form-check my-3">
                                            <div class="checkbox">
                                                <input type="checkbox" class="form-check-input" id="checkbox"
                                                    name="remember">
                                                <label for="checkbox">Remember Me</label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-block btn-primary">Login</button>
                                        </div>
                                        <p class="text-center">
                                            <span>New on our platform?</span>
                                            <a href="https://t0pgamemurah.xyz/app/auth/register.php">
                                                <span>Create an account</span>
                                            </a>
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
    </div>
        <!-- end page -->
  <div class="rightbar-overlay"></div>
  
    <script src="https://t0pgamemurah.xyz/assets/js/dark.js"></script>
    <script src="https://t0pgamemurah.xyz/assets/js/perfect-scrollbar.min.js"></script>
    <script src="https://t0pgamemurah.xyz/assets/js/app.js"></script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.3.2/html2canvas.min.js"></script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php
  if (isset($result_msg)) {
    if ($result_msg['alert'] == "danger") {
?>
  <script>
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
    Toast.fire({
      type: 'error',
      title: '<?php echo $result_msg['msg'] ?>'
    })
  </script>
  <?php
    } else {
  ?>
  <script>
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
    Toast.fire({
      type: 'success',
      title: '<?php echo $result_msg['msg'] ?>'
    })
  </script>
  <?php
    }
  }
  ?>
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
    </script>
        
    <script>
        document.addEventListener('contextmenu', event=> event.preventDefault()); 
        document.onkeydown = function(e) {
            if(event.keyCode == 123) {
                return false;
            }
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){ 
                return false; 
            }
        }
    </script>
    
    <script>
    (function() {

        var detector = function() {
            setTimeout(function() {

                if(!document.getElementsByClassName) return;
                var ads =
                        document.getElementsByClassName('banner_ad'),
                    ad  = ads[ads.length - 1];

                if(!ad || ad.innerHTML.length == 0
                                || ad.clientHeight === 0) {
                    console.log('Ad Blocker Detected');
                } else {
                    console.log('No Ad Blocker');
                }

            }, 2000);
        }

        /* Add a page load listener */
        if(window.addEventListener) {
            window.addEventListener('load', detector, false);
        }
})();
</script>
</body>
</html>
<?php
//require '../lib/footer.php';
?>
