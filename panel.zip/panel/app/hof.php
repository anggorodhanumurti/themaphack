<?php
require '../mainconfig.php';
require '../lib/check_session.php';
require '../lib/header.php';

$orders = mysqli_query($db, "SELECT SUM(orders.price) AS tamount, count(orders.id) AS tcount, orders.user_id, users.full_name FROM orders JOIN users ON orders.user_id = users.id WHERE MONTH(orders.created_at) = '".date('m')."' AND YEAR(orders.created_at) = '".date('Y')."' GROUP BY orders.user_id ORDER BY tamount DESC LIMIT 5");
$deposits = mysqli_query($db, "SELECT SUM(deposits.amount) AS tamount, count(deposits.id) AS tcount, deposits.user_id, users.full_name FROM deposits JOIN users ON deposits.user_id = users.id WHERE MONTH(deposits.created_at) = '".date('m')."' AND YEAR(deposits.created_at) = '".date('Y')."' AND deposits.status = 'Success' GROUP BY deposits.user_id ORDER BY tamount DESC LIMIT 5");
?>
<div class="content-page">
    <div id="app" data-bs-theme="light" class="text-ad-links">
        <div class="card-box">
            <div class="col-lg-12 text-center" style="margin: 15px 0;">
        		<h3 class="text-uppercase"><i class="fa fa-trophy fa-fw"></i> Top Users</h3>
        		<p>Below are the top 5 users with the highest total orders and deposits this month.<br />Thank you for being our loyal customer!</p>
        	</div>
        	<div class="row mb-3">
            	<div class="col-lg-6">
            		<div class="card m-0" data-aos="zoom-in">
            		    
            		    <div class="card-header bg-dark text-white p-3">
            		        <i class="fa fa-trophy fa-fw"></i>5 Most Orders
                        </div>
            			
            			<div class="table-responsive">
            				<table class="table">
            					<tr>
            						<th>RANKING</th>
            						<th>NAME</th>
            						<th>TOTAL</th>
            					</tr>
                                <?php
                                $no = 1;
                                while($data = mysqli_fetch_array($orders)) {
                                if ($no == 1) {
                                ?> 
            					<tr class="table-warning">
            						<td><?php echo $no ?></td>
            						<td><span class="badge badge-warning" style="margin-right: 5px;"><i class="mdi mdi-crown"></i></span><?php echo $data['full_name'] ?></td>
            						<td>Rp <?php echo number_format($data['tamount'],0,',','.') ?> (<?php echo number_format($data['tcount'],0,',','.') ?>)</td>
            					</tr>
                                <?php
                                } else { 
                                ?>
            					<tr>
            						<td><?php echo $no ?></td>
            						<td><?php echo $data['full_name'] ?></td>
            						<td>Rp <?php echo number_format($data['tamount'],0,',','.') ?> (<?php echo number_format($data['tcount'],0,',','.') ?>)</td>
            					</tr>
                                <?php 
                                }
                                ?>
                                <?php
                                	$no++;
                                }
                                ?>
            				</table>
            			</div>
            		</div>
            	</div>
        	    <div class="col-lg-6">
        		    <div class="card m-0" data-aos="zoom-in">
        		        
            		    <div class="card-header bg-dark text-white p-3">
            		        <i class="fa fa-trophy fa-fw"></i>5 Most Deposits
                        </div>
            			
        		        <div class="table-responsive">
        					<table class="table">
        						<tr>
        							<th>RANKING</th>
        							<th>NAME</th>
        							<th>TOTAL</th>
        						</tr>
        						<?php
                                $no = 1;
                                while($data = mysqli_fetch_array($deposits)) {
                                if ($no == 1) {
                                ?> 
        						<tr class="table-warning">
        						    <td><?php echo $no ?></td>
        						    <td><span class="badge badge-warning" style="margin-right: 5px;"><i class="mdi mdi-crown"></i></span><?php echo $data['full_name'] ?></td>
        							<td>Rp <?php echo number_format($data['tamount'],0,',','.') ?> (<?php echo number_format($data['tcount'],0,',','.') ?>)</td>
        						</tr>
                                <?php
                                } else { 
                                ?>
        						<tr>
        							<td><?php echo $no ?></td>
        							<td><?php echo $data['full_name'] ?></td>
        				    		<td>Rp <?php echo number_format($data['tamount'],0,',','.') ?> (<?php echo number_format($data['tcount'],0,',','.') ?>)</td>
        						</tr>
                                <?php 
                                }
                                ?>
                                <?php
                                	$no++;
                                }
                                ?>
        					</table>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
    </div>
</div>

    <script src="https://t0pgamemurah.xyz/assets/js/dark.js"></script>
    <script src="https://t0pgamemurah.xyz/assets/js/perfect-scrollbar.min.js"></script>
    <script src="https://t0pgamemurah.xyz/assets/js/app.js"></script>
<?php
require '../lib/footer.php';
?>