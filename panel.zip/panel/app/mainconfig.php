<?php

date_default_timezone_set('Asia/Jakarta');
ini_set('memory_limit', '1025M');

$config['db'] = array(
	'host' => 'localhost', //Server
	'name' => 'cheat_db', //db name
	'username' => 'cheat_admin', //Username DB
	'password' => 'yourdbpassword' //Password DB
);

require 'lib/db.php';
require 'lib/model.php';
require 'lib/function.php';

session_start();
$model = new Model();

$config['web'] = array(
	'maintenance' =>  $model->db_query($db,"maintenance", "pgen", "id ='1'")['rows']['maintenance'],
	'FreeToken' => $model->db_query($db,"keygen", "pgen", "id ='1'")['rows']['keygen'],
	'title' => '>XYZ<',
	'meta' => array(
		'description' => 'The Best Software Provider',
		'keywords' => 'Software',
		'author' => 'XYOURZONE'
	),
	'base_url' => 'https://t0pgamemurah.xyz/app/'
);

