<?php
require '../mainconfig.php';
require '../lib/check_session.php';

if (isset($_GET['search']) AND isset($_GET['status'])) {
	if (!empty($_GET['search']) AND !empty($_GET['status'])) {
		$query_list = "SELECT * FROM orders WHERE user_id = '".$_SESSION['login']."' AND data LIKE '%".protect_input($_GET['search'])."%' AND status LIKE '%".protect_input($_GET['status'])."%' ORDER BY id DESC";
	} else if (!empty($_GET['search'])) {
		$query_list = "SELECT * FROM orders WHERE user_id = '".$_SESSION['login']."' AND data LIKE '%".protect_input($_GET['search'])."%' ORDER BY id DESC";
	} else if (!empty($_GET['status'])) {
		$query_list = "SELECT * FROM orders WHERE user_id = '".$_SESSION['login']."' AND status LIKE '%".protect_input($_GET['status'])."%' ORDER BY id DESC";
	} else {
		$query_list = "SELECT * FROM orders WHERE user_id = '".$_SESSION['login']."' ORDER BY id DESC";
	}
} else {
	$query_list = "SELECT * FROM orders WHERE user_id = '".$_SESSION['login']."' ORDER BY id DESC";
}

$records_per_page = 30;
$starting_position = 0;
if(isset($_GET["page"])) {
	$starting_position = ($_GET["page"]-1) * $records_per_page;
}
$new_query = $query_list." LIMIT $starting_position, $records_per_page";
$new_query = mysqli_query($db, $new_query);
require '../lib/header.php';

?>

<div class="content-page">
    <div class="col-lg-12">
        <div class="card-header text-white p-3">
            <div class="card m-0" data-aos="zoom-in">
                <div class="card-body p-3">
            		<h4 class="m-t-0 m-b-30 header-title"><i class="fa fa-history"></i> Order History</h4>
            		<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        			    <div class="row">
                            <div class="form-group col-lg-5">
                        		<label>Filter Status</label>
                                <select class="form-control" name="status">
                                    <option value="">All</option>
                                    <option value="Pending" >Pending</option>
                                    <option value="Processing" >Processing</option>
                                    <option value="Success" >Success</option>
                                    <option value="Error" >Error</option>
                                    <option value="Partial" >Partial</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-5">
                                <label>Find</label>
                                <input type="text" class="form-control" name="search" placeholder="Keywords..." value="">
                            </div>
                            <div class="form-group col-lg-2">
                                <label>Submit</label>
                                <button type="submit" class="btn btn-block btn-dark">Filter</button>
                            </div>
                        </div>
        		    </form>
        			<div class="table-responsive">
        			    <table class="table table-bordered table-hover">
        					<thead>
        			    		<tr>
        							<th>DATE/TIME</th>
        							<th style="max-width: 100px;">SERVICE</th>
        							<th>BUYERS</th>
        							<th>DEVICE</th>
        							<th>PRICES</th>
        							<th>STATUS</th>
        						</tr>
        					</thead>
        					<?php while ($data_query = mysqli_fetch_assoc($new_query)) {
        					    if($data_query['status'] == "Pending") {
        					        $label = "warning";
        						} else if($data_query['status'] == "Processing") {
        						    $label = "info";
        						} else if($data_query['status'] == "Error") {
        							$label = "danger";
        						} else if($data_query['status'] == "Partial") {
        							$label = "danger";
        						} else if($data_query['status'] == "Success") {
        							$label = "success";
        						}
        					?>
        					<tbody>
        						<tr>
        							<td><?php echo format_date(substr($data_query['created_at'], 0, -9)).", ".substr($data_query['created_at'], -8) ?></td>
        						    <td><?php echo $data_query['service_name'] ?></td>
        							<td><?php echo $data_query['data'] ?></td>
        							<td><?php echo $data_query['quantity'] ?></td>
        							<td>Rp <?php echo number_format($data_query['price'],0,',','.') ?></td>
        							<td><span class="badge badge-<?php echo $label; ?>"><?php echo $data_query['status'] ?></span></td>
        						</tr>
                            </tbody>
        					<?php
        					    }
        					?>
        				</table>
        				<?php
        				    require '../lib/pagination.php';
                        ?>
        			</div>
        		</div>
        	</div>
        </div>
    </div>
</div>

<script src="https://t0pgamemurah.xyz/assets/js/dark.js"></script>
    <script src="https://t0pgamemurah.xyz/assets/js/perfect-scrollbar.min.js"></script>
    <script src="https://t0pgamemurah.xyz/assets/js/app.js"></script>

<script>
    window.addEventListener('swal-confirm', event => {
        Swal.fire({
            title: 'Apakah anda yakin?',
            text: event.detail.text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Confirm'
        }).then((result) => {
            if (result.isConfirmed) {
                window.livewire.emit(event.detail.array, event.detail.id);
            }
        });
    });

    window.addEventListener('swal:modal', event => {
        Swal.fire({
            title: event.detail.title,
            text: event.detail.text,
            icon: event.detail.type,
            confirmButtonText: 'Ok'
        });
        $('#editDurasi').modal('hide');
        $('#tambahPaket').modal('hide');
    });
</script>

<?php
require '../lib/footer.php';
?>