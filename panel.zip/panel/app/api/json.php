<?php

require '../mainconfig.php';
header('Content-Type: application/json');
if ($config['web']['maintenance'] == 1) {
	$result = array('status' => false, 'data' => array('msg' => 'Maintenance'));
	exit(json_encode($result, JSON_PRETTY_PRINT));
}
if ($_POST) {
	if (check_input($_POST, array('api_key', 'action')) == false) {
		$result = array('status' => false, 'data' => array('msg' => 'Request Not Allowed'));
	} else {
		$user = $model->db_query($db, "*", "users", "BINARY api_key = '".mysqli_real_escape_string($db, $_POST['api_key'])."'");
		if ($user['count'] <> 1) {
			$result = array('status' => false, 'data' => array('msg' => 'API Key salah'));
		} else {
			if ($_POST['action'] == 'order') {
                if (check_input($_POST, array('service', 'data', 'quantity')) == false) {
                    $result = array('status' => false, 'data' => array('msg' => 'Permintaan tidak sesuai'));
                } else {
                    $service = $model->db_query($db, "*", "services", "id = '".mysqli_real_escape_string($db, $_POST['service'])."' AND status = '1'");
                    if ($service['count'] == 0) {
                        $result = array('status' => false, 'data' => array('msg' => 'Layanan tidak ditemukan'));
                    } else {
                        $total_price = intval($service['rows']['price'] * $_POST['quantity']);
                        $total_profit = intval(($service['rows']['profit'] / 1000) * $_POST['quantity']);
                        $provider = $model->db_query($db, "*", "provider", "id = '".$service['rows']['provider_id']."'");
            
                        if ($provider['count'] == 0) {
                            $result = array('status' => false, 'data' => array('msg' => 'Layanan tidak tersedia'));
                        } elseif ($_POST['quantity'] < $service['rows']['min'] || $_POST['quantity'] > $service['rows']['max']) {
                            $result = array('status' => false, 'data' => array('msg' => 'Jumlah pesanan tidak sesuai'));
                        } elseif ($user['rows']['balance'] < $total_price) {
                            $result = array('status' => false, 'data' => array('msg' => 'Saldo tidak cukup'));
                        } else {
                            $result_api = false;
                            $curl = '';
                            $provider_order_id = '1';
            
                            if ($service['rows']['provider_id'] == '1') { // MANUAL
                                $result_api = '1';
                            } elseif ($service['rows']['provider_id'] == '2') { // IRVANKEDE
                                $post_api = array(
                                    'api_key'   => $provider['rows']['api_key'],
                                    'service'   => $service['rows']['provider_service_id'],
                                    'target'    => $_POST['data'],
                                    'quantity'  => $_POST['quantity']
                                );
                                $curl = post_curl($provider['rows']['api_url_order'], $post_api);
                                $result = json_decode($curl, true);
                                if (isset($result['status']) && $result['status'] == true) {
                                    $provider_order_id = $result['data']['id'];
                                    $result_api = true;
                                }
                            }
                            
                            function randomPassword() {
    					        $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    					        $paw = "VN";
    					        $pass = array();
    					        $alphaLength = strlen($alphabet) - 3;
    					        for ($i = 0; $i < 10; $i++) {
    					            $n = rand(0, $alphaLength);
    					            $pass[] = $alphabet[$n];
    					            
    					        }
    					        return implode($pass);
    					    }
    					    $str2 = randomPassword();
                            $token = "XYZ_" . strtoupper(randomPassword());
                            
                            date_default_timezone_set('Asia/Jakarta');
					        $besok = date('Y-m-d H:i:s', strtotime("+".$service['rows']['profit']." day", strtotime(date("Y-m-d H:i:s"))));
                            // Ambil kategori dari layanan yang dipesan
                            $category = $model->db_query($db, "*", "categories", "id ='".$service['rows']['category_id']."'")['rows']['name'];

                            if ($result_api == false) {
                                $result = array('status' => false, 'data' => array('msg' => 'Layanan tidak tersedia'));
                            } else {
                                $input_post = array(
                                    'user_id'           => $user['rows']['id'],
                                    'service_name'      => $service['rows']['service_name'],
                                    'data'              => $_POST['data'],
                                    'quantity'          => $_POST['quantity'],
                                    'price'             => $total_price,
                                    'profit'            => $total_profit,
                                    'remains'           => $_POST['quantity'],
                                    'status'            => 'Success',
                                    'provider_id'       => $service['rows']['provider_id'],
                                    'provider_order_id' => $provider_order_id,
                                    'created_at'        => date('Y-m-d H:i:s'),
                                    'token'             => $token
                                );
                                
                                $insert = $model->db_insert($db, "orders", $input_post);
            
                                if ($insert) {
                                    $model->db_update($db, "users", array('balance' => $user['rows']['balance'] - $total_price), "id = '".$user['rows']['id']."'");
                                    
                                    $model->db_insert($db, "balance_logs", array(
                                        'user_id' => $user['rows']['id'],
                                        'type' => 'minus',
                                        'amount' => $total_price,
                                        'note' => 'Membuat Pesanan melalui API. ID Pesanan: '.$insert.'.',
                                        'created_at' => date('Y-m-d H:i:s')
                                    ));
                                    
                                    $token_insert = $model->db_insert($db, "token", array(
                                        'uid'        => $user['rows']['id'],
                                        'data'       => $_POST['data'],
                                        'access_key' => "XYZ_" . strtoupper($str2),
                                        'cheat_name' => "XYOURZONE",
                                        'cheat_text' => "Bypass Allways On 24 hours",
                                        'cheat_exp'   => $besok,
                                        'cheat_slot' => 1,
                                        'slot'       => 1,
                                        'device'     => 0,
                                        'status'     => "Safe",
                                        'games'      => $category,
                                        'active'     => 0,
                                        'durasi'     => $service['rows']['profit'],
                                        'start'      => date('Y-m-d H:i:s'),
                                        'vip'        => 100,
                                        'isUse'      => 0
                                    ));
                                
                                    if ($token_insert) {
                                        $result = array(
                                            'status' => true,
                                            'data' => array(
                                                'id'           => $insert,
                                                'token'        => "XYZ_" . strtoupper($str2),
                                                'games'        => $category
                                            )
                                        );
                                    } else {
                                        $result = array('status' => false, 'data' => array('msg' => 'Gagal menyimpan token ke database'));
                                    }
                                }


                            }
                        }
                    }
                }
            } elseif ($_POST['action'] == 'status') {
				if (check_input($_POST, array('id')) == false) {
					$result = array('status' => false, 'data' => array('msg' => 'Permintaan tidak sesuai'));
				} else {
					$order = $model->db_query($db, "*", "orders", "id = '".mysqli_real_escape_string($db, $_POST['id'])."' AND user_id = '".$user['rows']['id']."'");
					if ($order['count'] == 0) {
						$result = array('status' => false, 'data' => array('msg' => 'Pesanan tidak ditemukan'));
					} else {
						$result = array('status' => true, 'data' => array('status' => $order['rows']['status'], 'start_count' => $order['rows']['start_count'], 'remains' => $order['rows']['remains']));
					}
				}
			} elseif ($_POST['action'] == 'services') {
				$query = "SELECT services.id, service_name AS name, price, min, max, note, categories.name AS category 
              FROM services 
              JOIN categories ON categories.id = services.category_id 
              WHERE services.status = '1'";

    $service = mysqli_query($db, $query);

    // Cek apakah query berhasil
    if (!$service) {
        $result = array(
            'status' => false,
            'data' => array('msg' => 'Query gagal', 'error' => mysqli_error($db))
        );
    } else {
        $services = array();
        while ($data = mysqli_fetch_assoc($service)) {
            $services[] = $data;
        }
        $result = array('status' => true, 'data' => $services);
    }
			} else {
				$result = array('status' => false, 'data' => array('msg' => 'Permintaan tidak sesuai'));
			}
		}
	}
} else {
	$result = array('status' => false, 'data' => array('msg' => 'Only POST Method'));
}
print(json_encode($result, JSON_PRETTY_PRINT));
