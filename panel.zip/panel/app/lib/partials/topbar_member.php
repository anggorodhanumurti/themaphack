    <!-- Topbar Start -->
    <div class="navbar-custom">
        <div class="topbar">
            <ul class="list-unstyled topnav-menu float-right mb-0">
    
                        <li class="dropdown d-none d-lg-inline-block">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen" href="#">
                                <i class="fe-maximize noti-icon"></i>
                            </a>
                        </li>
                        
                        <li class="dropdown d-none d-lg-inline-block">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" href="<?php echo $config['web']['base_url'] ?>logoutz.php" class="dropdown-item notify-item">
                                <i class="fe-log-out"></i>
                            </a>
                        </li>
                        
            </ul>
            <!-- end Topbar -->
            
            <!-- NEW TOP BAR -->
            
            <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                        <li>
                            <button class="button-menu-mobile waves-effect waves-light">
                                <i class="fe-menu"></i>
                            </button>
                        </li>

                        <li>
                            <!-- Mobile menu toggle (Horizontal Layout)-->
                            <a class="navbar-toggle nav-link" data-toggle="collapse" data-target="#topnav-menu-content">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </li>   
            
                        
                    </ul>
            
            <div class="rightbar-overlay"></div>
        </div>
    </div>
    <!-- end Topbar -->
    