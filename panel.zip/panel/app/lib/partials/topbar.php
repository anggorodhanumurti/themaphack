    <div id="app" data-bs-theme="light" class="text-ad-links">
        <!-- Topbar Start -->
        <div class="navbar-custom">
            <div class="topbar">
                <ul class="list-unstyled topnav-menu float-right mb-0">
                    
                    <li class="d-none d-lg-block">
                                <form class="app-search">
                                    <div class="app-search-box dropdown">
                                        <div class="input-group">
                                            <input type="search" class="form-control" placeholder="Search..." id="top-search">
                                            <div class="input-group-append">
                                                <button class="btn" type="submit">
                                                    <i class="fe-search"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="dropdown-menu dropdown-lg" id="search-dropdown">
                                            <!-- item-->
                                            <div class="dropdown-header noti-title">
                                                <h5 class="text-overflow mb-2">Found 22 results</h5>
                                            </div>
                
                                            <!-- item-->
                                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                                <i class="fe-home mr-1"></i>
                                                <span>Analytics Report</span>
                                            </a>
                
                                            <!-- item-->
                                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                                <i class="fe-aperture mr-1"></i>
                                                <span>How can I help you?</span>
                                            </a>
                                
                                            <!-- item-->
                                            <a href="javascript:void(0);" class="dropdown-item notify-item">
                                                <i class="fe-settings mr-1"></i>
                                                <span>User profile settings</span>
                                            </a>
    
                                            <!-- item-->
                                            <div class="dropdown-header noti-title">
                                                <h6 class="text-overflow mb-2 text-uppercase">Users</h6>
                                            </div>
    
                                            <div class="notification-list">
                                                <!-- item-->
                                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                                    <div class="media">
                                                        <img class="d-flex mr-2 rounded-circle" src="../assets/images/users/user-2.jpg" alt="Generic placeholder image" height="32">
                                                        <div class="media-body">
                                                            <h5 class="m-0 font-14">Erwin E. Brown</h5>
                                                            <span class="font-12 mb-0">UI Designer</span>
                                                        </div>
                                                    </div>
                                                </a>
    
                                                <!-- item-->
                                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                                    <div class="media">
                                                        <img class="d-flex mr-2 rounded-circle" src="../assets/images/users/user-5.jpg" alt="Generic placeholder image" height="32">
                                                        <div class="media-body">
                                                            <h5 class="m-0 font-14">Jacob Deo</h5>
                                                            <span class="font-12 mb-0">Developer</span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                
                                        </div>  
                                    </div>
                                </form>
                            </li>
        
                            <li class="dropdown notification-list">
                                <a href="javascript:void(0);" class="nav-link right-bar-toggle waves-effect waves-light">
                                    <i class="fe-settings noti-icon"></i>
                                </a>
                            </li>
                            
                            
        
                            <li class="dropdown d-inline-block d-lg-none">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <i class="fe-search noti-icon"></i>
                                </a>
                                <div class="dropdown-menu dropdown-lg dropdown-menu-right p-0">
                                    <form class="p-3">
                                        <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                                    </form>
                                </div>
                            </li>
        
                            <li class="dropdown d-none d-lg-inline-block">
                                <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen" href="#">
                                    <i class="fe-maximize noti-icon"></i>
                                </a>
                            </li>
                            
                    
                    <?php
                if (isset($_SESSION['login']))
                { ?>
                    <li class="dropdown notification-list topbar-dropdown">
                        <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="javascript:void(0);" role="button" aria-haspopup="false" aria-expanded="false">
                            <img src="<?php echo $config['web']['base_url'] ?>assets/images/users/man.svg" alt="user-image" class="rounded-circle" />
                            <span class="pro-user-name ml-1">
                                <?php echo $login['username'] ?>
                                <i class="mdi mdi-chevron-down"> </i>
                            </span>
                        </a>
                        
                        <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                            <!-- item-->
                            <div class="dropdown-header noti-title">
                                <h6 class="text-overflow m-0">Welcome !</h6>
                            </div>
                            <!-- item-->
                            <a href="<?php echo $config['web']['base_url'] ?>user/settings.php" class="dropdown-item notify-item">
                                <i data-feather="user" class="icons-xs icon-dual-primary mr-1"></i>
                                <span> Pengaturan Akun </span>
                            </a>
                            <!-- item-->
                            <a href="<?php echo $config['web']['base_url'] ?>user/log_balance_usage.php" class="dropdown-item notify-item">
                                <i data-feather="repeat" class="icons-xs icon-dual-primary mr-1"></i>
                                <span> Mutasi Saldo </span>
                            </a>
                            <?php
                            if ($login['level'] == 'Admin') {
                            ?>
                            <a href="<?php echo $config['web']['base_url'] ?>order/durasi.php" class="dropdown-item notify-item">
                                <i data-feather="refresh-cw" class="icons-xs icon-dual-primary mr-1"></i>
                                <span> Key List </span>
                            </a>
                            <?php
                            }else{
                            ?>
                            <a href="<?php echo $config['web']['base_url'] ?>order/key.php" class="dropdown-item notify-item">
                                <i data-feather="refresh-cw" class="icons-xs icon-dual-primary mr-1"></i>
                                <span> Key List </span>
                            </a>
                            <?php
                            }
                            ?>
                            <!-- item-->
                            <a href="<?php echo $config['web']['base_url'] ?>user/log_login.php" class="dropdown-item notify-item">
                                <i data-feather="refresh-cw" class="icons-xs icon-dual-primary mr-1"></i>
                                <span> Riwayat Login </span>
                            </a>
                            
                            <div class="dropdown-divider"></div>
                            
                            <!-- item-->
                            <a href="<?php echo $config['web']['base_url'] ?>logout.php" class="dropdown-item notify-item">
                                <i data-feather="log-out" class="icons-xs icon-dual-primary mr-1"></i>
                                <span> Logout </span>
                            </a>
                        </div>
                    </li>
                    <?php
                }
                ?>
                </ul>
                <!-- end Topbar -->
                
                <!-- NEW TOP BAR -->
                
                <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                            <li>
                                <button class="button-menu-mobile waves-effect waves-light">
                                    <i class="fe-menu"></i>
                                </button>
                            </li>
    
                            <li>
                                <!-- Mobile menu toggle (Horizontal Layout)-->
                                <a class="navbar-toggle nav-link" data-toggle="collapse" data-target="#topnav-menu-content">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>   
                
                            
                        </ul>
                
                <div class="rightbar-overlay"></div>
            </div>
        </div>
    <!-- end Topbar -->
    </div>