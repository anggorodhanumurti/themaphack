<?php
require 'is_login.php';
require 'csrf_token.php';
?>
<!DOCTYPE html>
<html>
    <head>
<?php
require 'partials/title-meta.php';
require 'partials/head-css.php';
?>
    </head>
    
    <body class="loading" data-layout-mode="vertical" data-layout='{"mode": "light", "width": "fluid", "menuPosition": "fixed", "sidebar": { "color": "light", "size": "default", "showuser": false}, "topbar": {"color": "light"}, "showRightSidebarOnPageLoad": true}'>


<!-- Begin page -->
<div id="wrapper">

<?php
require 'partials/topbar_member.php';
?>

    <div class="left-side-menu">
        <div class="h-100" data-simplebar>
            
            <ul class="nav nav-tabs nav-bordered nav-justified" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link py-2 active" data-toggle="tab" href="#chat-tab" role="tab">
                            <i class="mdi mdi-view-dashboard-outline d-block font-22 my-1"></i>
                        </a>
                    </li>
                </ul>

            
            <div class="tab-content pt-0">
                    <div class="tab-pane active" id="chat-tab" role="tabpanel">
                

                        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <ul id="side-menu">
					    <?php
						if (isset($_SESSION['login']))
						{
						?>
                        <li class="menu-title mt-2">Apps</li>
                        <li>
                            <a href="<?php echo $config['web']['base_url'] ?>page/hof.php">
                                <i data-feather="grid"></i>
                                <span> Top Users </span>
                            </a>
						</li>
						<li>
						    <a href="#ordersDropdown" data-toggle="collapse">
                                <i data-feather="shopping-cart"></i>
                                <span> Orders </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="ordersDropdown">
                                <ul class="nav-second-level">
                                    <li>
                                        <a href="<?php echo $config['web']['base_url'] ?>order/new.php" class="dropdown-item">New Orders
                                        </a>
                                        
                                        <a href="<?php echo $config['web']['base_url'] ?>order/history.php" class="dropdown-item">Orders History </a>
                                        
                                        <a href="<?php echo $config['web']['base_url'] ?>order/graph.php" class="dropdown-item">Report Orders </a>
                                        
                                        <a href="<?php echo $config['web']['base_url'] ?>api/documentation.php" class="dropdown-item">API Docs </a>
                                    </li>
                                </ul>
                            </div>
						</li>
						
						<li>
						    <a href="#depositDropdown" data-toggle="collapse">
                                <i data-feather="dollar-sign"></i>
                                <span> Deposit </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="depositDropdown">
                                <ul class="nav-second-level">
                                    <li>
                                        <a href="<?php echo $config['web']['base_url'] ?>deposit/new.php" class="dropdown-item">Deposit/Top Up Balance </a>
    									<a href="<?php echo $config['web']['base_url'] ?>deposit/history.php" class="dropdown-item">Deposit History </a>
    									<a href="<?php echo $config['web']['base_url'] ?>deposit/voucher.php" class="dropdown-item">Claim Voucher</a> 
                                    </li>
                                </ul>
                            </div>
						</li>
						
						<li>
						    <a href="#ticketsDropdown" data-toggle="collapse">
                                <i data-feather="message-square"></i>
                                <span> Tickets </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="ticketsDropdown">
                                <ul class="nav-second-level">
                                    <li>
                                        <a href="<?php echo $config['web']['base_url'] ?>ticket/submit.php" class="dropdown-item">Create Tickets </a>
    									<a href="<?php echo $config['web']['base_url'] ?>ticket" class="dropdown-item">Tickets Data </a>
                                    </li>
                                </ul>
                            </div>
						</li>
						
						<li>
						    <a href="#pageDropdown" data-toggle="collapse">
                                <i data-feather="message-square"></i>
                                <span> Page </span>
                                <span class="menu-arrow"></span>
                            </a>
                            <div class="collapse" id="pageDropdown">
                                <ul class="nav-second-level">
                                    <li>
                                        <a href="<?php echo $config['web']['base_url'] ?>page/contact.php" class="dropdown-item">Contact </a>
                                        <a href="<?php echo $config['web']['base_url'] ?>page/faq.php" class="dropdown-item">General Questions </a>
                                        <a href="<?php echo $config['web']['base_url'] ?>page/tos.php" class="dropdown-item">Terms of Service</a>
                                    </li>
                                </ul>
                            </div>
						</li>
						
                        <?php
                        }
                        else
                        {
                        ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $config['web']['base_url'] ?>"> <i data-feather="home" class="icons-xs icon-dual-primary mr-1"></i> Dashboard </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $config['web']['base_url'] ?>auth/login.php"> <i data-feather="log-in" class="icons-xs icon-dual-primary mr-1"></i> Login </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $config['web']['base_url'] ?>auth/register.php"> <i data-feather="user-plus" class="icons-xs icon-dual-primary mr-1"></i> Register </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $config['web']['base_url'] ?>page/services.php"> <i data-feather="list" class="icons-xs icon-dual-primary mr-1"></i> Daftar Layanan </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="javascript:void(0);" id="topnav-dashboard" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i data-feather="more-horizontal" class="icons-xs icon-dual-primary mr-1"></i> Halaman
                                <div class="arrow-down"></div>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="topnav-dashboard">
                                <a href="<?php echo $config['web']['base_url'] ?>page/contact.php" class="dropdown-item">Kontak </a>
                                <a href="<?php echo $config['web']['base_url'] ?>page/faq.php" class="dropdown-item">Pertanyaan Umum </a>
                                <a href="<?php echo $config['web']['base_url'] ?>page/tos.php" class="dropdown-item">Ketentuan Layanan</a> 
                            </div>
                        </li>
                        <?php
                        }
                        ?>
                        </ul>

                    </div>
                    </aside>

                    </div>

                    
                </div>
            
            
                    <!-- End Sidebar -->

                    <div class="rightbar-overlay"></div>

                </div>
                <!-- Sidebar -left -->

            </div>

             <!-- modal -->
             <div class="wrapper">
                 <div class="container-boxed">
                     <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="topModalLabel" aria-hidden="true" style="display: none;">
                         <div class="modal-dialog modal-dialog-top">
                             <div class="modal-content">
                                 <div class="modal-header">
                                     <h4 class="modal-title" id="modal-title"></h4>
                                     <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                 </div>
                                 <div class="modal-body" id="modal-body"></div>
                                 <div class="modal-footer"></div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>


<?php
require 'partials/body-result.php';
?>