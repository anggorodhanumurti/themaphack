<?php

if(isset($_SESSION["login"]) && $_SESSION["login"] === true){
	$_SESSION['result_msg'] = array('alert' => 'danger', 'title' => 'Otentikasi dibutuhkan!', 'msg' => 'Silahkan masuk terlebih dahulu.');
	exit(header("Location: ".$config['web']['base_url']."auth/login.php"));
} else if (!isset($_SESSION['login'])) {
    header("Location: ".$config['web']['base_url']."auth/login.php");
}
if ($model->db_query($db, "*", "users", "id = '".$_SESSION['login']."' AND level = 'Admin'")['count'] == 0) {
	exit(header("Location: ".$config['web']['base_url']."logout.php"));
}