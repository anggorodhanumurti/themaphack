<!-- Footer Start -->

<!-- End Footer -->
<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>
<!-- App js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/app.min.js"></script>

<script src="<?php echo $config['web']['base_url'] ?>assets/js/clipboard.js"></script>

<script src="<?php echo $config['web']['base_url'] ?>assets/libs/select2/js/select2.min.js"></script>

<!-- Init js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/pages/form-advanced.init.js"></script>
<!-- Sweet Alerts js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

<!-- Sweet alert init js-->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/pages/sweet-alerts.init.js"></script>

<?php
  if (isset($_SESSION['result_msg'])) {
    if ($_SESSION['result_msg']['alert'] == "danger") {
?>
<script>
Swal.fire(
  '<?php echo $_SESSION['result_msg']['title'] ?>',
  '<?php echo $_SESSION['result_msg']['msg'] ?>',
  'error'
).then((result) => {
  if (result.isConfirmed) {
    <?php unset($_SESSION['result_msg']) ?>
  }
})
</script>
?>
<?php
    } else {
?>
<script>
Swal.fire(
  '<?php echo $_SESSION['result_msg']['title'] ?>',
  '<?php echo $_SESSION['result_msg']['msg'] ?>',
  'success'
).then((result) => {
  if (result.isConfirmed) {
    <?php unset($_SESSION['result_msg']); ?>
  }
})
</script>
<?php
      }
  }
?>
    <script>
    const detect = document.querySelector("#detect");
    const wrapper = document.querySelector(".wrapper");
    const button = wrapper.querySelector("button");
    let adClasses = ["ad", "ads", "adsbox", "doubleclick", "ad-placement", "ad-placeholder", "adbadge", "BannerAd"];
    for(let item of adClasses){
      detect.classList.add(item);
    }
    let getProperty = window.getComputedStyle(detect).getPropertyValue("display");
    if(!wrapper.classList.contains("show")){
      getProperty == "none" ? wrapper.classList.add("show") : wrapper.classList.remove("show");
    }
    button.addEventListener("click", ()=>{
      wrapper.classList.remove("show");
    });
  </script>
</body>

</html>