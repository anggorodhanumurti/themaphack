<?php

require 'mainconfig.php';

if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['login'])) {
    exit(header("Location: ".$config['web']['base_url']."auth/login.php"));
}


$profile = $model->db_query($db, "*", "users", "id='".$_SESSION['login']."'");

require 'lib/header.php';

?>
<div class="content-page">
    <div id="app" data-bs-theme="light" class="text-ad-links">
        <div class="card-box">
            <div class="col-lg-12 text-center" style="margin: 15px 0;">
                <h4 class="m-t-0 m-b-30 header-title"><i class="fa fa-info-circle"></i> New Information</h4>
            </div>
            <div class="col-12 card-body pb-3">
                <div class="card-header text-white p-3">
                    
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 250px;">DATE/TIME</th>
                                    <th>CONTENT</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $news = $model->db_query($db, "*", "news", null, "id DESC", "LIMIT 5"); if ($news['count'] == 1) {
                                ?>
                                <tr>
                                    <td><?php echo format_date(substr($news['rows']['created_at'], 0, -9)).", ".substr($news['rows']['created_at'], -8) ?></td>
                                    <td><?php echo nl2br($news['rows']['content']) ?></td>
                                </tr>
                                <?php
                                } else {
                                foreach ($news['rows'] as $key => $value) {
                                ?>
                                <tr>
                                    <td><?php echo format_date(substr($value['created_at'], 0, -9)).", ".substr($value['created_at'], -8) ?></td>
                                    <td><?php echo nl2br($value['content']) ?></td>
                                </tr>
                                <?php
                                }
                            }
                            if ($news['count'] >= 5) {
                            ?>
                                <tr>
                                    <td colspan="3" align="center">
                                        <a href="<?php echo $config['web']['base_url'] ?>news">See all...</a>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-box">
            <div class="theme-toggle d-flex gap-2  align-items-center mt-3 mt-sm-0">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--system-uicons" width="20" height="20" preserveAspectRatio="xMidYMid meet" viewBox="0 0 21 21">
                    <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M10.5 14.5c2.219 0 4-1.763 4-3.982a4.003 4.003 0 0 0-4-4.018c-2.219 0-4 1.781-4 4c0 2.219 1.781 4 4 4zM4.136 4.136L5.55 5.55m9.9 9.9l1.414 1.414M1.5 10.5h2m14 0h2M4.135 16.863L5.55 15.45m9.899-9.9l1.414-1.415M10.5 19.5v-2m0-14v-2" opacity=".3"></path>
                        <g transform="translate(-210 -1)">
                            <path d="M220.5 2.5v2m6.5.5l-1.5 1.5"></path>
                            <circle cx="220.5" cy="11.5" r="4"></circle>
                            <path
                                d="m214 5l1.5 1.5m5 14v-2m6.5-.5l-1.5-1.5M214 18l1.5-1.5m-4-5h2m14 0h2">
                            </path>
                        </g>
                    </g>
                </svg>
                <div class="form-check form-switch fs-6">
                    <input class="form-check-input  me-0" type="checkbox" id="toggle-dark" style="cursor: pointer">
                    <label class="form-check-label"></label>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--mdi" width="20" height="20" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                    <path fill="currentColor"
                        d="m17.75 4.09l-2.53 1.94l.91 3.06l-2.63-1.81l-2.63 1.81l.91-3.06l-2.53-1.94L12.44 4l1.06-3l1.06 3l3.19.09m3.5 6.91l-1.64 1.25l.59 1.98l-1.7-1.17l-1.7 1.17l.59-1.98L15.75 11l2.06-.05L18.5 9l.69 1.95l2.06.05m-2.28 4.95c.83-.08 1.72 1.1 1.19 1.85c-.32.45-.66.87-1.08 1.27C15.17 23 8.84 23 4.94 19.07c-3.91-3.9-3.91-10.24 0-14.14c.4-.4.82-.76 1.27-1.08c.75-.53 1.93.36 1.85 1.19c-.27 2.86.69 5.83 2.89 8.02a9.96 9.96 0 0 0 8.02 2.89m-1.64 2.02a12.08 12.08 0 0 1-7.8-3.47c-2.17-2.19-3.33-5-3.49-7.82c-2.81 3.14-2.7 7.96.31 10.98c3.02 3.01 7.84 3.12 10.98.31Z">
                    </path>
                </svg>
            </div>
            <div class="card-header bg-dark text-white p-3">
                <i class="fas fa-user me-2"></i>Details Account
            </div>
            <div class="row mb-3">
                <div class="col-md-6 col-xl-4 mb-2">
                    <div class="card-header text-white p-3">
                        <div class="card m-0" data-aos="zoom-in">
                            <div class="card-body p-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                      <h4 class="mt-0 font-16">Income Status</h4>
                                      <h2 class="text-primary my-3 text-center">Rp.<?php echo number_format($model->db_query($db, "SUM(price) as total", "orders WHERE user_id = '".$_SESSION['login']."'")['rows']['total'],0,',','.') ?></h2>
                                      <p class="text-muted mb-0">Total Transaction: <?php echo number_format($model->db_query($db, "*", "orders WHERE user_id = '".$_SESSION['login']."'")['count'],0,',','.') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-xl-4">
                    <div class="card-header text-white p-3">
                        <div class="card m-0" data-aos="zoom-in">
                            <div class="card-body p-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                        <h4 class="mt-0 font-16">Deposits Status</h4>
                                          <h2 class="text-primary my-3 text-center">Rp.<?php echo number_format($model->db_query($db, "SUM(amount) as total", "deposits WHERE user_id = '".$_SESSION['login']."'")['rows']['total'],0,',','.') ?></h2>
                                          <p class="text-uted mb-0">Total Deposit:  <?php echo number_format($model->db_query($db, "*","deposits WHERE user_id = '".$_SESSION['login']."'")['count'],0,',','.') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-xl-4">
                    <div class="card-header text-white p-3">
                        <div class="card m-0" data-aos="zoom-in">
                            <div class="card-body p-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div>
                                        <i class="fa fa-info-circle text-muted float-right" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Your Balance"></i>
                                        <h4 class="mt-0 font-16">Total Balance</h4>
                                        <h2 class="text-primary my-3 text-center">Rp.<?php echo number_format($login['balance'],0,',','.'); ?></h2>
                                        <p class="text-muted mb-0">Total Transaction: <?php echo number_format($model->db_query($db, "*", "orders WHERE user_id = '".$_SESSION['login']."'")['count'],0,',','.') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- END CARD -->
        <div class="card-box">
            <div class="card-header bg-dark text-white p-3">
                <i class="fas fa-user me-2"></i>Status Account
            </div>
            <div class="col-12 card-body pb-3">
                <ul class="list-group list-hover mb-3">
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"> Roles <span class="badge text-dark"> </strong><span class="ml-2"><?php echo $profile['rows']['level']; ?></span>
                    </li>
                    
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"> Name <span class="badge text-dark"> </strong><span class="ml-2"><?php echo $profile['rows']['full_name']; ?></span>
                    </li>
                    
                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"> API <span class="badge text-dark"> </strong><span class="ml-2"><?php echo $profile['rows']['api_key']; ?></span>
                    </li>
                </ul>
            </div> <!-- end col-->
        </div>
        
        
        <div class="card-box">
            <div class="card-header bg-dark text-white p-3">
                <i class="fas fa-user me-2"></i>Last 7 Days Order & Deposit Graph
            </div>
            <div class="col-12 card-body pb-3">
                <div class="card-header text-white p-3">
                    <div class="card m-0" data-aos="zoom-in">
                        <div class="card-content">
                            <div id="last-order-chart" style="height: 200px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End content-page -->
</div>

<script src="https://t0pgamemurah.xyz/assets/js/dark.js"></script>
<script src="https://t0pgamemurah.xyz/assets/js/perfect-scrollbar.min.js"></script>
<script src="https://t0pgamemurah.xyz/assets/js/app.js"></script>

<script type="text/javascript">
Morris.Area({
	element: 'last-order-chart',
	data: [
<?php
$date_list = array();
for ($i = 6; $i > -1; $i--) {
	$date_list[] = date('Y-m-d', strtotime('-'.$i.' days'));
}
for ($i = 0; $i < count($date_list); $i++) {
	$get_order = $model->db_query($db, "*", "orders", "user_id = '".$login['id']."' AND DATE(created_at) = '".$date_list[$i]."'");
	$get_deposit = $model->db_query($db, "*", "deposits", "user_id = '".$login['id']."' AND DATE(created_at) = '".$date_list[$i]."' AND status = 'Success'");
	print("{ y: '".format_date($date_list[$i])."', a: ".$get_order['count'].", b: ".$get_deposit['count']." }, ");
}
?>
	],
	xkey: 'y',
	ykeys: ['a', 'b'],
	labels: ['Pesanan', 'Deposit'],
	lineColors: ['#02c0ce', '#53c68c'],
	gridLineColor: '#eef0f2',
	pointSize: 0,
	lineWidth: 0,
	resize: true,
	parseTime: false
});
</script>
<?php
require 'lib/footer.php';
?>