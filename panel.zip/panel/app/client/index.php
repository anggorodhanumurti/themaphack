<?php
require '../mainconfig.php';

if($_POST['dataserial']){
    if($_POST['dataserial'] != "Not Login Yet"){
        if($model->db_update($db, "token", array('serial' => 0), "id = '".$_SESSION['key']."'") == true){
            $_SESSION['result_msg'] = array('alert' => 'info', 'title' => 'Success!', 'msg' => "Serial Successful Reset", 'show' => true);
        }else{
            $_SESSION['result_msg'] = array('alert' => 'danger', 'title' => 'Error!', 'msg' => "Please Try Again!", 'show' => true);
        }
    }else{
        $_SESSION['result_msg'] = array('alert' => 'danger', 'title' => 'Failed!', 'msg' => "Please login first!!!", 'show' => true);
    }
}

if($_POST['dataserial'] == XYZ_FKWWRRIZZH){
    $_SESSION['result_msg'] = array('alert' => 'danger', 'title' => 'Failed!', 'msg' => "Your Key Doesnt Work", 'show' => true);
}

if (!isset($_SESSION['key'])) {
    exit(header("Location: ".$config['web']['base_url']."auth/"));
    
} else {
    $cek = $model->db_query($db, "*", "token", "id = '" .$_SESSION['key']."'");
    $dw = $model->db_query($db, "*", "app");
    $d_sell = $model->db_query($db, "*", "users", "id = '" .$cek['rows']['uid']."'");
    $penjual = $d_sell['rows']['username'];
    $time1 = new DateTime(date("Y-m-d H:i:s"));
    $time2 = new DateTime($cek['rows']['cheat_exp']);
    $interval = $time1->diff($time2)->format("%r%a");
    $jam = $time1->diff($time2)->format("%r%h");
    $sisa = "$interval Days $jam Hour";
    $isVip = '';
    $durasi = '';
    $serial = '';
    if ($cek['rows']['vip'] == 1){
        $isVip = 'VIP Client';
        $downloads = $dw['rows']['url'];
    } else {
        $isVip = 'FREE Client';
        $downloads = $dw['rows']['purl'];
    }
    if($cek['rows']['serial'] == 0){
        $serial = 'Not Login Yet';
    }else{
        $serial = $cek['rows']['serial'];
    }
    if($cek['rows']['active'] == 0){
        $durasi = 'Not Login Yet';
    }else{
        $durasi = $sisa;
    }
    require '../lib/partials/head-css.php';
    require '../lib/partials/title-meta.php';
}
?>

<div class="account-pages mt-5 mb-5">
    <div id="app" data-bs-theme="light" class="text-ad-links">
        <div class="card">
            <div class="row justify-content-center">
                <div class="col-lg-4 col-xl-4 justify-content-center">
                    <div class="card-header bg-dark text-white p-3">
                        <i class="fas fa-user me-2"></i>XYOURZONE
                    </div>
                    <div class="card text-center" style="height:480px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19) box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                        <img src="../../img/image.jpg" class="rounded-circle  avatar-lg img-thumbnail" alt="profile-image">
                        <h4 class="mb-0"><strong>XYOURZONE</strong></h4>
                        <p class="text-muted">Provider Cheat</p>
                        <div class="text-left mt-3">
                          <h4 class="font-13 text-uppercase">Price List MLBB Cheat</h4>
                          <p class="text-muted font-13 mb-3">
                            💰3 Day - 20K IDR ($5)</br>
                            💰7 Day - 30K IDR ($7)</br>
                            💰15 Day - 45K IDR ($8)</br>
                            💰30 Day - 80K IDR ($10)</br>
                            💰60 Day Bonus 3 Day - 140K IDR ($17)</br>
                            💰90 Day Bonus 3 Day - 180K IDR ($20)</br>
                            💰120 Day Bonus 7 Day - 230K IDR ($26)</br>
                          </p>
                        </div>
                        <button class="btn btn-primary btn-block" onclick="document.location.href='https://t.me/ToracinnoBold'"> Renew Token </button>
                        <button class="btn btn-primary btn-block" onclick="document.location.href='https://t0pgamemurah.xyz/app/logoutz.php">Logout Panel</button>
                    </div> <!-- end card-box -->
                </div> <!-- end col-->
                
                <div class="col-lg-12 col-xl-7">
                    <div class="card-header bg-dark text-white p-3">
                        <i class="fas fa-user me-2"></i>Details Account
                    </div>
                    <div class="card" style="height:480px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                        <div class="row">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="datatable">
                                    <tbody>
                                        <tr>
                                            <td>Member Name</td>
                                            <td><?php echo $cek['rows']['data'] ?></td>
                                        </tr>
                                        <tr>
                                            <td>Seller Name</td>
                                            <td><?php echo $model->db_query($db,"username", "users", "id ='".$cek['rows']['uid']."'")['rows']['username'] ?></td>
                                        </tr>
                                        <tr>
                                            <td>Remaining Time</td>
                                            <td><?php echo $durasi ?></td>
                                        </tr>
                                        <tr>
                                        	<td>Status Key</td>
                                            <td><?php echo $isVip ?></td>
                                        <tr>
                                    </tbody>	
                                </table>
                                
                                <div class="card text-center" style="margin:10px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                                        <h4 class="mb-0"><strong>Serial</strong></h4>
                                        <p class="text-muted"></p>
                                        <form method="POST">
                                            <div class="form-group mb-3">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                                    </div>
                                                    <input type="text" class="form-control" name="dataserial" value="<?php echo $serial ?>" readonly </input>
                                                </div>
                                            </div>
                                        </form>
                                    </div> <!-- end card-box -->
                                
                                <div class="card text-center" style="margin:10px;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                                    <h4 class="mb-0"><strong>Reset Your Serial</strong></h4>
                                    <p class="text-muted"></p>
                                    <form method="POST">
                                        <div class="form-group mb-3">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                                </div>
                                                <input type="text" class="form-control" name="dataserial" value="<?php echo $serial ?>" readonly </input>
                                            </div>
                                        </div>
                                        <div class="form-group mb-0 text-center">
                                            <button class="btn btn-primary btn-block" type="submit"> Reset </button>
                                        </div>
                                    </form>
                                </div> <!-- end card-box -->
                                
                            </div>
                        </div>
                    </div>
                </div> <!-- end col-box-->
            </div>
        </div>
    </div>
</div>
<script src="https://t0pgamemurah.xyz/assets/js/dark.js"></script>
<script src="https://t0pgamemurah.xyz/assets/js/perfect-scrollbar.min.js"></script>
<script src="https://t0pgamemurah.xyz/assets/js/app.js"></script>

<script src="<?php echo $config['web']['base_url'] ?>assets/js/app.min.js"></script>

<script src="<?php echo $config['web']['base_url'] ?>assets/js/clipboard.js"></script>

<script src="<?php echo $config['web']['base_url'] ?>assets/libs/select2/js/select2.min.js"></script>

<!-- Init js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/pages/form-advanced.init.js"></script>
<!-- Sweet Alerts js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

<!-- Sweet alert init js-->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/pages/sweet-alerts.init.js"></script>

<?php
  if (isset($_SESSION['result_msg'])) {
    if ($_SESSION['result_msg']['alert'] == "danger") {
?>
<script>
Swal.fire(
  '<?php echo $_SESSION['result_msg']['title'] ?>',
  '<?php echo $_SESSION['result_msg']['msg'] ?>',
  'error'
).then((result) => {
  if (result.isConfirmed) {
    <?php unset($_SESSION['result_msg']) ?>
  }
})
</script>

<?php
    } else {
?>
<script>
Swal.fire(
  '<?php echo $_SESSION['result_msg']['title'] ?>',
  '<?php echo $_SESSION['result_msg']['msg'] ?>',
  'success'
).then((result) => {
  if (result.isConfirmed) {
    <?php unset($_SESSION['result_msg']); ?>
  }
})
</script>
<?php
      }
  }
?>
    <script>
    const detect = document.querySelector("#detect");
    const wrapper = document.querySelector(".wrapper");
    const button = wrapper.querySelector("button");
    let adClasses = ["ad", "ads", "adsbox", "doubleclick", "ad-placement", "ad-placeholder", "adbadge", "BannerAd"];
    for(let item of adClasses){
      detect.classList.add(item);
    }
    let getProperty = window.getComputedStyle(detect).getPropertyValue("display");
    if(!wrapper.classList.contains("show")){
      getProperty == "none" ? wrapper.classList.add("show") : wrapper.classList.remove("show");
    }
    button.addEventListener("click", ()=>{
      wrapper.classList.remove("show");
    });
  </script>