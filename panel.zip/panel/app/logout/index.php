<?php
require '../mainconfig.php';
// Unset all of the session variables
$_SESSION = array();

// If it's desired to kill the session, also delete the session cookie
// Note: This will destroy the session, and not just the session data!
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Remove cookies set for "Remember Me"
setcookie('username', '', time() - 3600, "/");
setcookie('password', '', time() - 3600, "/");

unset($_SESSION['login']);
exit(header("Location: https://t0pgamemurah.xyz/app/auth/login.php"));