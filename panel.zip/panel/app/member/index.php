<?php

require '../mainconfig.php';
session_start();

if (isset($_SESSION['key'])) {
    exit(header("Location: ".$config['web']['base_url']."client/"));
}

$mod = $model->db_query($db, "*", "mod_data", "id = '1' AND status = '1'");

date_default_timezone_set('Asia/Jakarta');
if ($_POST['key']){
    $cek = $model->db_query($db, "*", "token", "access_key = '" .$_POST['key']."'");
    
    if ($cek['rows']['vip'] == 0){
        $msg = 'Your Key Is Not VIP!';
        $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
    } else {
        if ($_POST['key'] == 'XYZ_KULU5L3SXY' || $_POST['key'] == 'XYZ_XQUSJMWEJ7'){
            $msg = 'Your Key Is Not Allow To Reset Devices';
            $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
        } else{
            if ($cek['count'] == 0){
            $msg = 'Key not found!!';
            $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
            }else {
                if ($cek['rows']['active'] != 0){
                    if (date('Y-m-d H:i:s') > $cek['rows']['cheat_exp']){
                        $msg = 'Your Key Expired';
                        $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
                    } else {
                        $_SESSION['key'] = $cek['rows']['id'];
                        header("Location: ".$config['web']['base_url']."client/");
                    }
                }else{
                    $_SESSION['key'] = $cek['rows']['id'];
                    header("Location: ".$config['web']['base_url']."client/");
                }
            }
        }
    }
    
}

require '../lib/partials/head-css.php';
require '../lib/partials/title-meta.php';
?>
<body oncontextmenu="return false">
    <div id="app" data-bs-theme="light">
  <div class="account-pages mt-5 mb-5">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 col-xl-5">
          <div class="card">

            <div class="card-body p-4">
                <div class="theme-toggle d-flex gap-2  align-items-center mt-3 mt-sm-0">
                    <svg xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                    class="iconify iconify--system-uicons" width="20" height="20"
                    preserveAspectRatio="xMidYMid meet" viewBox="0 0 21 21">
                        <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M10.5 14.5c2.219 0 4-1.763 4-3.982a4.003 4.003 0 0 0-4-4.018c-2.219 0-4 1.781-4 4c0 2.219 1.781 4 4 4zM4.136 4.136L5.55 5.55m9.9 9.9l1.414 1.414M1.5 10.5h2m14 0h2M4.135 16.863L5.55 15.45m9.899-9.9l1.414-1.415M10.5 19.5v-2m0-14v-2"
                            opacity=".3"></path>
                            <g transform="translate(-210 -1)">
                                <path d="M220.5 2.5v2m6.5.5l-1.5 1.5"></path>
                                <circle cx="220.5" cy="11.5" r="4"></circle>
                                <path d="m214 5l1.5 1.5m5 14v-2m6.5-.5l-1.5-1.5M214 18l1.5-1.5m-4-5h2m14 0h2">
                                </path>
                                                </g>
                                            </g>
                                        </svg>
                                        <div class="form-check form-switch fs-6">
                                            <input class="form-check-input  me-0" type="checkbox" id="toggle-dark"
                                                style="cursor: pointer">
                                            <label class="form-check-label"></label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                                            class="iconify iconify--mdi" width="20" height="20"
                                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="m17.75 4.09l-2.53 1.94l.91 3.06l-2.63-1.81l-2.63 1.81l.91-3.06l-2.53-1.94L12.44 4l1.06-3l1.06 3l3.19.09m3.5 6.91l-1.64 1.25l.59 1.98l-1.7-1.17l-1.7 1.17l.59-1.98L15.75 11l2.06-.05L18.5 9l.69 1.95l2.06.05m-2.28 4.95c.83-.08 1.72 1.1 1.19 1.85c-.32.45-.66.87-1.08 1.27C15.17 23 8.84 23 4.94 19.07c-3.91-3.9-3.91-10.24 0-14.14c.4-.4.82-.76 1.27-1.08c.75-.53 1.93.36 1.85 1.19c-.27 2.86.69 5.83 2.89 8.02a9.96 9.96 0 0 0 8.02 2.89m-1.64 2.02a12.08 12.08 0 0 1-7.8-3.47c-2.17-2.19-3.33-5-3.49-7.82c-2.81 3.14-2.7 7.96.31 10.98c3.02 3.01 7.84 3.12 10.98.31Z">
                                            </path>
                                        </svg>
                                    </div>
                
              <div class="text-center w-75 m-auto">
                <img src="../../img/image.jpg" height="88" alt="user-image" class="rounded-circle shadow">
                <h4 class="text-dark-50 text-center mt-3">Welcome To User Area </h4>
                <p class="text-muted mb-4">Enter your key to access the User Area.</p>
              </div>


              <form method="POST">
                <div class="form-group mb-3">
                  <label for="password">Key</label>
                  <input class="form-control" type="text" required="" name="key" id="key" placeholder="Enter your Key">
                </div>
                <div class="form-group mb-0 text-center">
                  <button class="btn btn-primary btn-block" type="submit"> Log In </button>
                </div>
              </form>
            </div> <!-- end card-body -->
          </div><!-- end card -->

          <div class="row mt-3">
            <div class="col-12 text-center">
            </div> <!-- end col -->
          </div><!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
       <div class="rightbar-overlay"></div>
<!-- App js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/app.min.js"></script>

<script src="<?php echo $config['web']['base_url'] ?>assets/js/clipboard.js"></script>

<script src="<?php echo $config['web']['base_url'] ?>assets/libs/select2/js/select2.min.js"></script>

<!-- Init js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/pages/form-advanced.init.js"></script>
<!-- Sweet Alerts js -->
<script src="<?php echo $config['web']['base_url'] ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

<!-- Sweet alert init js-->
<script src="<?php echo $config['web']['base_url'] ?>assets/js/pages/sweet-alerts.init.js"></script>

<script src="https://t0pgamemurah.xyz/datZ/assets/js/dark.js"></script>
<script src="https://d5studio.my.id/assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.3.2/html2canvas.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
  if (isset($result_msg)) {
    if ($result_msg['alert'] == "danger") {
?>
  <script>
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
    Toast.fire({
      type: 'error',
      title: '<?php echo $result_msg['msg'] ?>'
    })
  </script>
  <?php
    } else {
  ?>
  <script>
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
    Toast.fire({
      type: 'success',
      title: '<?php echo $result_msg['msg'] ?>'
    })
  </script>
  <?php
    }
  }
  ?>
   <script> 
      document.addEventListener('contextmenu', event=> event.preventDefault()); 
      document.onkeydown = function(e) { 
      if(event.keyCode == 123) { 
      return false; 
      } 
      if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){ 
      return false; 
      } 
      if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){ 
      return false; 
      } 
      if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){ 
      return false; 
      } 
      } 
      </script> 
    </body>
</html>