
<?php

require '../../app/mainconfig.php';

date_default_timezone_set('Asia/Jakarta');

$GAME_MLBB = $model->db_query($db, "*", "categories", "id = '1'");
$GAME_MLBB_NAME = $GAME_MLBB['rows']['name'];

$GAME_EXTERNAL = $model->db_query($db, "*", "categories", "id = '2'");
$GAME_EXTERNAL_NAME = $GAME_EXTERNAL['rows']['name'];

$GAME_HYPERROOM = $model->db_query($db, "*", "categories", "id = '3'");
$GAME_HYPERROOM_NAME = $GAME_HYPERROOM['rows']['name'];

$GAME_PUBG = $model->db_query($db, "*", "categories", "id = '4'");
$GAME_PUBG_NAME = $GAME_PUBG['rows']['name'];

$GAME_AOV = $model->db_query($db, "*", "categories", "id = '6'");
$GAME_AOV_NAME = $GAME_AOV['rows']['name'];

$GAME_HOK = $model->db_query($db, "*", "categories", "id = '5'");
$GAME_HOK_NAME = $GAME_HOK['rows']['name'];

if ($_POST){
	if (check_input($_POST, array('user_key', 'serial', 'game')) == false) {
		$result = array('status' => false, 'data' => array('reason' => 'Inappropriate request'));
	} else {
		if ($_POST['game'] == $GAME_MLBB_NAME) {
		    $cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_MLBB_NAME."'")) {
                if (mysqli_num_rows($ress) == 1) {
                    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
                        $result = array('status' => false, 'reason' => 'Input Your Key');
                    } else {
                        if($cek1['count'] > 0){
                            if($cek1['rows']['status'] == 0) {
                                $result = array('status' => false, 'reason' => 'Service Under Maintenance');
                            }else{
                                $cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
                                $slot = $cek2['rows']['cheat_slot'];
                                $vip = false;
                                if ($cek2['rows']['vip'] == 1) {
                                    $vip = true;
                                }
                                
                                $enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
                                $stime =  time();
                                $serial = "";
                                $time1 = new DateTime(date("Y-m-d H:i:s"));
                                $time2 = new DateTime($cek2['rows']['cheat_exp']);
                                $interval = $time1->diff($time2)->format("%r%a");
                                $jam = $time1->diff($time2)->format("%r%h");
                                $sisa = "$interval hari $jam jam";
                                $min = intval($cek2['rows']['cheat_slot']) - 1;
                                $besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                                $myArray = array(
                                    'token'=> $enc,
                					'MOD_NAME'      => $cek1['rows']['brand'],
                					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                					'EXP'           => $cek2['rows']['cheat_exp'],
                					'MOD_SLOT'      => $cek2['rows']['slot'],
                					'device'        => $cek2['rows']['slot'],
                					'MOD_STATUS'    => 'Safe',
                					'isVip'         => $cek2['rows']['vip'],
                					'iniVip'        => $cek2['rows']['vip'],
                					'DURASI'        => $sisa,
                					'rng'           => $stime,
                					'client'        => $cek2['rows']['data'],
                					'AutoSkills'    => 'on',
                					'serial'        => $_POST['serial']
                                );
                                if ($cek2['count'] == 0) { //if serial is zero
									$result = array('status' => false, 'msg' => 'Key Invalid');
								} else {
									if ($cek2['rows']['serial'] == 0){
										date_default_timezone_set('Asia/Jakarta');
										$sql = "UPDATE token SET serial='"."".$_POST['serial']."'"."WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_MLBB_NAME."'";
										if ($db->query($sql) == TRUE){
											if($cek2['rows']['active'] == 0){
												$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
												$upexp = "UPDATE token SET cheat_exp='".$besok."'"."WHERE access_key = '".$_POST['user_key']."'";
												if ($db->query($upexp) == TRUE){
													$aktif = "UPDATE token SET active='1'"."WHERE access_key = '".$_POST['user_key']."'";
													if($db->query($aktif) == TRUE){
														date_default_timezone_set('Asia/Jakarta');
														$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
														$time11 = new DateTime(date("Y-m-d H:i:s"));
														$time21 = new DateTime($besok);
														$interval1 = $time11->diff($time21)->format("%r%a");
														$jam1 = $time11->diff($time21)->format("%r%h");
														$sisa1 = "$interval1 hari $jam1 jam";
													}
												}
											}else{
												$result = array('status' => true, 'data' => $myArray);
											}
										} else {
											$result = array('status' => false, 'reason'=> 'Failed to upload your serial');
										}
									} else {
										if($cek2['rows']['serial'] == 0){
											if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
												if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
													$result = array('status' => true, 'data' => $myArray);
												}else{
													$result = array('status' => false, 'reason' => 'Try Again');
												}
											}
										}else{
											if ($cek2['rows']['cheat_slot'] > 1){
												$result = array('status' => true, 'data' => $myArray);
											} else {
											    if ($cek2['rows']['vip'] == 1) {
											        $result = array('status' => false, 'reason' => 'What u want to do idiot.');
											    } else {
											        if($_POST['serial'] == $cek2['rows']['serial']){
    													if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
    														$result = array('status' => true, 'data' => $myArray);
    													} else {
    														if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
    															$result = array('status' => false, 'msg' => 'Expired Key');
    														}else {
    															$result = array('status' => false, 'msg' => 'Error To Get key Data'); 
    														}
    													}
    												} else {
    													$result = array('status' => false, 'reason' => 'Invalid Device');
    												}
											    }
												
											}
										}
									}
								}
                            }
                        }
                    }
			    }else {
            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
            	}
			}
		} else if ($_POST['game'] == $GAME_EXTERNAL_NAME) {
    		$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_EXTERNAL_NAME."'")) {
			    if (mysqli_num_rows($ress) == 1) {
    			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
    					$result = array('status' => false, 'reason' => 'Input Your Key');
    				} else {
    				    if($cek1['count'] > 0){
            				if($cek1['rows']['status'] == 0) {
            					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
            				}else{
            					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
            					$slot = $cek2['rows']['cheat_slot'];
            					$vip = false;
            					if ($cek2['rows']['vip'] == 1) {
            						$vip = true;
            					}
            
            					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
            					$stime =  time();
            					$serial = "";
            					$time1 = new DateTime(date("Y-m-d H:i:s"));
            					$time2 = new DateTime($cek2['rows']['cheat_exp']);
            					$interval = $time1->diff($time2)->format("%r%a");
            					$jam = $time1->diff($time2)->format("%r%h");
            					$sisa = "$interval hari $jam jam";
            					$min = intval($cek2['rows']['cheat_slot']) - 1;
            					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
            					$myArray = array(
                					'token'=> $enc,
                					'MOD_NAME'      => $cek1['rows']['brand'],
                					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                					'EXP'           => $cek2['rows']['cheat_exp'],
                					'MOD_SLOT'      => $cek2['rows']['slot'],
                					'device'        => $cek2['rows']['slot'],
                					'MOD_STATUS'    => 'Safe',
                					'isVip'         => $cek2['rows']['vip'],
                					'iniVip'        => $cek2['rows']['vip'],
                					'DURASI'        => $sisa,
                					'rng'           => $stime,
                					'client'        => $cek2['rows']['data'],
                					'AutoSkills'    => 'on',
                					'serial'        => $_POST['serial']
            					);
            					if ($cek2['count'] == 0) { //if serial is zero
            						$result = array('status' => false, 'reason' => 'Key Invalid');
            					} else {
            						if ($cek2['rows']['active'] == 0) {
            							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
            							$result = array('status' => true, 'data' => $myArray);
            							}else{
            							$result = array('status' => false, 'reason' => 'Try Again');
            							}
            						} else {
            							if($cek2['rows']['serial'] == 0){
            								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
            									$result = array('status' => true, 'data' => $myArray);
            									}else{
            									$result = array('status' => false, 'reason' => 'Try Again');
            									}
            								}
            							}else{
            								if($_POST['serial'] == $cek2['rows']['serial']){
            									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            										$result = array('status' => true, 'data' => $myArray);
            									} else {
            										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
            											$result = array('status' => false, 'reason' => 'Expired Key');
            										}else {
            											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
            										}
            									}
            								}else{
            									$result = array('status' => false, 'reason' => 'Invalid Device'); 
            								}
            							}
            						}
            					}
            				}
            			}
    				}
			    }else {
            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
            	}
			}
		} else if ($_POST['game'] == $GAME_HYPERROOM_NAME) {
			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_HYPERROOM_NAME."'")) {
			    if (mysqli_num_rows($ress) == 1) {
    			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
    					$result = array('status' => false, 'reason' => 'Input Your Key');
    				} else {
    				    if($cek1['count'] > 0){
            				if($cek1['rows']['status'] == 0) {
            					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
            				}else{
            					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
            					$slot = $cek2['rows']['cheat_slot'];
            					$vip = false;
            					if ($cek2['rows']['vip'] == 1) {
            						$vip = true;
            					}
            
            					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
            					$stime =  time();
            					$serial = "";
            					$time1 = new DateTime(date("Y-m-d H:i:s"));
            					$time2 = new DateTime($cek2['rows']['cheat_exp']);
            					$interval = $time1->diff($time2)->format("%r%a");
            					$jam = $time1->diff($time2)->format("%r%h");
            					$sisa = "$interval hari $jam jam";
            					$min = intval($cek2['rows']['cheat_slot']) - 1;
            					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
            					$myArray = array(
                					'token'=> $enc,
                					'MOD_NAME'      => $cek1['rows']['brand'],
                					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                					'EXP'           => $cek2['rows']['cheat_exp'],
                					'MOD_SLOT'      => $cek2['rows']['slot'],
                					'device'        => $cek2['rows']['slot'],
                					'MOD_STATUS'    => 'Safe',
                					'isVip'         => $cek2['rows']['vip'],
                					'iniVip'        => $cek2['rows']['vip'],
                					'DURASI'        => $sisa,
                					'rng'           => $stime,
                					'client'        => $cek2['rows']['data'],
                					'AutoSkills'    => 'on',
                					'serial'        => $_POST['serial']
            					);
            					if ($cek2['count'] == 0) { //if serial is zero
            						$result = array('status' => false, 'reason' => 'Key Invalid');
            					} else {
            						if ($cek2['rows']['active'] == 0) {
            							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
            							$result = array('status' => true, 'data' => $myArray);
            							}else{
            							$result = array('status' => false, 'reason' => 'Try Again');
            							}
            						} else {
            							if($cek2['rows']['serial'] == 0){
            								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
            									$result = array('status' => true, 'data' => $myArray);
            									}else{
            									$result = array('status' => false, 'reason' => 'Try Again');
            									}
            								}
            							}else{
            								if($_POST['serial'] == $cek2['rows']['serial']){
            									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            										$result = array('status' => true, 'data' => $myArray);
            									} else {
            										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
            											$result = array('status' => false, 'reason' => 'Expired Key');
            										}else {
            											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
            										}
            									}
            								}else{
            									$result = array('status' => false, 'reason' => 'Invalid Device'); 
            								}
            							}
            						}
            					}
            				}
            			}
    				}
			    }else {
            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
            	}
			}
		} else if ($_POST['game'] == $GAME_PUBG_NAME) {
		    $cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_PUBG_NAME."'")) {
                if (mysqli_num_rows($ress) == 1) {
                    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
                        $result = array('status' => false, 'reason' => 'Input Your Key');
                    } else {
                        if($cek1['count'] > 0){
                            if($cek1['rows']['status'] == 0) {
                                $result = array('status' => false, 'reason' => 'Service Under Maintenance');
                            }else{
                                $cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
                                $slot = $cek2['rows']['cheat_slot'];
                                $vip = false;
                                if ($cek2['rows']['vip'] == 1) {
                                    $vip = true;
                                }
                                
                                $enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
                                $stime =  time();
                                $serial = "";
                                $time1 = new DateTime(date("Y-m-d H:i:s"));
                                $time2 = new DateTime($cek2['rows']['cheat_exp']);
                                $interval = $time1->diff($time2)->format("%r%a");
                                $jam = $time1->diff($time2)->format("%r%h");
                                $sisa = "$interval hari $jam jam";
                                $min = intval($cek2['rows']['cheat_slot']) - 1;
                                $besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                                $myArray = array(
                                    'token'=> $enc,
                					'NAME_MOD'      => $cek1['rows']['brand'],
                					'EXP_MOD'       => $cek2['rows']['cheat_exp'],
                					'device'        => $cek2['rows']['slot'],
                					'MOD_STATUS'    => 'Safe',
                					'iniVip'        => $cek2['rows']['vip'],
                					'DURASI'        => $sisa,
                					'rng'           => $stime,
                					'client'        => $cek2['rows']['data'],
                					'AutoSkills'    => 'on',
                					'serial'        => $_POST['serial']
                                );
                                if ($cek2['count'] == 0) { //if serial is zero
									$result = array('status' => false, 'msg' => 'Key Invalid');
								} else {
									if ($cek2['rows']['serial'] == 0){
										date_default_timezone_set('Asia/Jakarta');
										$sql = "UPDATE token SET serial='"."".$_POST['serial']."'"."WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_PUBG_NAME."'";
										if ($db->query($sql) == TRUE){
											if($cek2['rows']['active'] == 0){
												$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
												$upexp = "UPDATE token SET cheat_exp='".$besok."'"."WHERE access_key = '".$_POST['user_key']."'";
												if ($db->query($upexp) == TRUE){
													$aktif = "UPDATE token SET active='1'"."WHERE access_key = '".$_POST['user_key']."'";
													if($db->query($aktif) == TRUE){
														date_default_timezone_set('Asia/Jakarta');
														$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
														$time11 = new DateTime(date("Y-m-d H:i:s"));
														$time21 = new DateTime($besok);
														$interval1 = $time11->diff($time21)->format("%r%a");
														$jam1 = $time11->diff($time21)->format("%r%h");
														$sisa1 = "$interval1 hari $jam1 jam";
													}
												}
											}else{
												$result = array('status' => true, 'data' => $myArray);
											}
										} else {
											$result = array('status' => false, 'reason'=> 'Failed to upload your serial');
										}
									} else {
										if($cek2['rows']['serial'] == 0){
											if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
												if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
													$result = array('status' => true, 'data' => $myArray);
												}else{
													$result = array('status' => false, 'reason' => 'Try Again');
												}
											}
										}else{
											if ($cek2['rows']['cheat_slot'] > 1){
												$result = array('status' => true, 'data' => $myArray);
											} else {
											    if ($cek2['rows']['vip'] == 1) {
											        $result = array('status' => false, 'reason' => 'What u want to do idiot.');
											    } else {
											        if($_POST['serial'] == $cek2['rows']['serial']){
    													if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
    														$result = array('status' => true, 'data' => $myArray);
    													} else {
    														if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
    															$result = array('status' => false, 'msg' => 'Expired Key');
    														}else {
    															$result = array('status' => false, 'msg' => 'Error To Get key Data'); 
    														}
    													}
    												} else {
    													$result = array('status' => false, 'reason' => 'Invalid Device');
    												}
											    }
												
											}
										}
									}
								}
                            }
                        }
                    }
			    }else {
            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
            	}
			}
		} else if ($_POST['game'] == $GAME_AOV_NAME) {
			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_AOV_NAME."'")) {
			    if (mysqli_num_rows($ress) == 1) {
    			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
    					$result = array('status' => false, 'reason' => 'Input Your Key');
    				} else {
    				    if($cek1['count'] > 0){
            				if($cek1['rows']['status'] == 0) {
            					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
            				}else{
            					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
            					$slot = $cek2['rows']['cheat_slot'];
            					$vip = false;
            					if ($cek2['rows']['vip'] == 1) {
            						$vip = true;
            					}
            
            					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
            					$stime =  time();
            					$serial = "";
            					$time1 = new DateTime(date("Y-m-d H:i:s"));
            					$time2 = new DateTime($cek2['rows']['cheat_exp']);
            					$interval = $time1->diff($time2)->format("%r%a");
            					$jam = $time1->diff($time2)->format("%r%h");
            					$sisa = "$interval hari $jam jam";
            					$min = intval($cek2['rows']['cheat_slot']) - 1;
            					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
            					$myArray = array(
                					'token'=> $enc,
                					'MOD_NAME'      => $cek1['rows']['brand'],
                					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                					'EXP'           => $cek2['rows']['cheat_exp'],
                					'MOD_SLOT'      => $cek2['rows']['slot'],
                					'device'        => $cek2['rows']['slot'],
                					'MOD_STATUS'    => 'Safe',
                					'isVip'         => $cek2['rows']['vip'],
                					'iniVip'        => $cek2['rows']['vip'],
                					'DURASI'        => $sisa,
                					'rng'           => $stime,
                					'client'        => $cek2['rows']['data'],
                					'AutoSkills'    => 'on',
                					'serial'        => $_POST['serial']
            					);
            					if ($cek2['count'] == 0) { //if serial is zero
            						$result = array('status' => false, 'reason' => 'Key Invalid');
            					} else {
            						if ($cek2['rows']['active'] == 0) {
            							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
            							$result = array('status' => true, 'data' => $myArray);
            							}else{
            							$result = array('status' => false, 'reason' => 'Try Again');
            							}
            						} else {
            							if($cek2['rows']['serial'] == 0){
            								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
            									$result = array('status' => true, 'data' => $myArray);
            									}else{
            									$result = array('status' => false, 'reason' => 'Try Again');
            									}
            								}
            							}else{
            								if($_POST['serial'] == $cek2['rows']['serial']){
            									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            										$result = array('status' => true, 'data' => $myArray);
            									} else {
            										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
            											$result = array('status' => false, 'reason' => 'Expired Key');
            										}else {
            											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
            										}
            									}
            								}else{
            									$result = array('status' => false, 'reason' => 'Invalid Device'); 
            								}
            							}
            						}
            					}
            				}
            			}
    				}
			    }else {
            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
            	}
			}
		} else if ($_POST['game'] == $GAME_HOK_NAME) {
			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$GAME_HOK_NAME."'")) {
			    if (mysqli_num_rows($ress) == 1) {
    			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
    					$result = array('status' => false, 'reason' => 'Input Your Key');
    				} else {
    				    if($cek1['count'] > 0){
            				if($cek1['rows']['status'] == 0) {
            					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
            				}else{
            					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
            					$slot = $cek2['rows']['cheat_slot'];
            					$vip = false;
            					if ($cek2['rows']['vip'] == 1) {
            						$vip = true;
            					}
            
            					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
            					$stime =  time();
            					$serial = "";
            					$time1 = new DateTime(date("Y-m-d H:i:s"));
            					$time2 = new DateTime($cek2['rows']['cheat_exp']);
            					$interval = $time1->diff($time2)->format("%r%a");
            					$jam = $time1->diff($time2)->format("%r%h");
            					$sisa = "$interval hari $jam jam";
            					$min = intval($cek2['rows']['cheat_slot']) - 1;
            					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
            					$myArray = array(
                					'token'=> $enc,
                					'MOD_NAME'      => $cek1['rows']['brand'],
                					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                					'EXP'           => $cek2['rows']['cheat_exp'],
                					'MOD_SLOT'      => $cek2['rows']['slot'],
                					'device'        => $cek2['rows']['slot'],
                					'MOD_STATUS'    => 'Safe',
                					'isVip'         => $cek2['rows']['vip'],
                					'iniVip'        => $cek2['rows']['vip'],
                					'DURASI'        => $sisa,
                					'rng'           => $stime,
                					'client'        => $cek2['rows']['data'],
                					'AutoSkills'    => 'on',
                					'serial'        => $_POST['serial']
            					);
            					if ($cek2['count'] == 0) { //if serial is zero
            						$result = array('status' => false, 'reason' => 'Key Invalid');
            					} else {
            						if ($cek2['rows']['active'] == 0) {
            							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
            							$result = array('status' => true, 'data' => $myArray);
            							}else{
            							$result = array('status' => false, 'reason' => 'Try Again');
            							}
            						} else {
            							if($cek2['rows']['serial'] == 0){
            								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
            									$result = array('status' => true, 'data' => $myArray);
            									}else{
            									$result = array('status' => false, 'reason' => 'Try Again');
            									}
            								}
            							}else{
            								if($_POST['serial'] == $cek2['rows']['serial']){
            									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            										$result = array('status' => true, 'data' => $myArray);
            									} else {
            										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
            											$result = array('status' => false, 'reason' => 'Expired Key');
            										}else {
            											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
            										}
            									}
            								}else{
            									$result = array('status' => false, 'reason' => 'Invalid Device'); 
            								}
            							}
            						}
            					}
            				}
            			}
    				}
			    }else {
            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
            	}
			}
		} else {
			$result = array('status' => false, 'reason' => 'Key Expired or Not Register in This Game');
		}
        print(json_encode($result, JSON_PRETTY_PRINT));
    }
} else {
	exit("No direct script access allowed!");
?>
</html>

<?php
}
?>
