-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 15, 2025 at 12:06 AM
-- Server version: 10.11.11-MariaDB-0+deb12u1
-- PHP Version: 8.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cheat_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_log`
--

CREATE TABLE `access_log` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `access_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `app`
--

CREATE TABLE `app` (
  `id` int(11) NOT NULL,
  `name` varchar(9999) NOT NULL,
  `url` varchar(9999) NOT NULL,
  `purl` varchar(9999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `app`
--

INSERT INTO `app` (`id`, `name`, `url`, `purl`) VALUES
(1, 'THEMAPHACK', 'https://t.me/themaphack', 'https://t.me/themaphack');

-- --------------------------------------------------------

--
-- Table structure for table `balance_logs`
--

CREATE TABLE `balance_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(5) NOT NULL,
  `amount` double NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `balance_logs`
--

INSERT INTO `balance_logs` (`id`, `user_id`, `type`, `amount`, `note`, `created_at`) VALUES
(1, 43, 'minus', 5000, 'Place an Order. Order ID: 1.', '2025-01-16 15:07:37'),
(2, 56, 'minus', 5000, 'Place an Order. Order ID: 2.', '2025-01-18 16:04:33'),
(3, 63, 'minus', 5000, 'Place an Order. Order ID: 3.', '2025-01-19 23:05:13'),
(4, 43, 'minus', 25000, 'Place an Order. Order ID: 4.', '2025-01-20 06:11:19'),
(5, 62, 'minus', 35000, 'Place an Order. Order ID: 5.', '2025-01-20 17:12:48'),
(6, 56, 'minus', 5000, 'Place an Order. Order ID: 6.', '2025-01-20 23:36:24'),
(7, 1, 'minus', 15000, 'Place an Order. Order ID: 7.', '2025-02-02 13:28:02'),
(8, 1, 'minus', 70000, 'Place an Order. Order ID: 8.', '2025-02-02 13:29:00'),
(9, 1, 'minus', 70000, 'Place an Order. Order ID: 9.', '2025-02-02 13:38:00'),
(10, 1, 'minus', 35000, 'Place an Order. Order ID: 10.', '2025-02-02 15:05:43'),
(11, 1, 'minus', 35000, 'Place an Order. Order ID: 11.', '2025-02-04 13:42:17'),
(12, 1, 'minus', 15000, 'Place an Order. Order ID: 12.', '2025-02-05 10:48:53'),
(13, 1, 'minus', 134999, 'Place an Order. Order ID: 13.', '2025-02-05 15:06:55'),
(14, 1, 'minus', 35000, 'Place an Order. Order ID: 14.', '2025-02-05 16:36:50'),
(15, 1, 'minus', 350000, 'Place an Order. Order ID: 15.', '2025-02-05 18:34:57'),
(16, 1, 'minus', 70000, 'Place an Order. Order ID: 16.', '2025-02-05 21:00:31'),
(17, 1, 'minus', 15000, 'Place an Order. Order ID: 17.', '2025-02-06 07:26:19'),
(18, 1, 'minus', 65000, 'Place an Order. Order ID: 18.', '2025-02-06 08:09:48'),
(19, 1, 'minus', 35000, 'Place an Order. Order ID: 19.', '2025-02-06 08:42:45'),
(20, 1, 'minus', 35000, 'Place an Order. Order ID: 20.', '2025-02-06 15:17:28'),
(21, 1, 'minus', 35000, 'Place an Order. Order ID: 21.', '2025-03-03 03:53:12'),
(22, 1, 'minus', 700000, 'Place an Order. Order ID: 22.', '2025-03-03 13:00:15'),
(23, 1, 'minus', 70000, 'Place an Order. Order ID: 23.', '2025-03-13 13:59:59'),
(24, 1, 'minus', 674995, 'Place an Order. Order ID: 24.', '2025-03-14 14:07:31'),
(25, 1, 'minus', 1349990, 'Place an Order. Order ID: 25.', '2025-03-19 14:40:41'),
(26, 1, 'minus', 140000, 'Place an Order. Order ID: 26.', '2025-03-22 13:52:34'),
(27, 1, 'minus', 500000, 'Place an Order. Order ID: 27.', '2025-03-22 20:06:49'),
(28, 1, 'minus', 134999, 'Membuat Pesanan melalui API. ID Pesanan: 28.', '2025-03-25 14:29:27'),
(29, 1, 'minus', 134999, 'Membuat Pesanan melalui API. ID Pesanan: 29.', '2025-03-26 10:10:30'),
(30, 1, 'minus', 70000, 'Place an Order. Order ID: 30.', '2025-03-30 14:30:29'),
(31, 1, 'minus', 13499900, 'Place an Order. Order ID: 31.', '2025-04-23 09:23:24'),
(32, 1, 'minus', 13499900, 'Place an Order. Order ID: 32.', '2025-05-03 14:18:29'),
(33, 1, 'minus', 13499900, 'Place an Order. Order ID: 33.', '2025-05-11 19:21:52'),
(34, 1, 'minus', 350000, 'Place an Order. Order ID: 34.', '2025-06-26 22:23:57'),
(35, 1, 'minus', 1349990, 'Place an Order. Order ID: 35.', '2025-07-03 11:12:15'),
(36, 1, 'minus', 849990, 'Place an Order. Order ID: 36.', '2025-07-06 09:13:51'),
(37, 1, 'minus', 849990, 'Place an Order. Order ID: 37.', '2025-07-06 09:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `appver` varchar(255) NOT NULL DEFAULT '0.0.0.0',
  `brand` varchar(255) DEFAULT NULL,
  `static` varchar(9999) NOT NULL DEFAULT 'D5STATIC',
  `status` int(11) NOT NULL DEFAULT 1,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `appver`, `brand`, `static`, `status`, `time`) VALUES
(1, 'MLBB', '2.6', 'XYOURZONE', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 1, 23);

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment` enum('pulsa','bank','redeem') NOT NULL,
  `type` enum('manual','auto') NOT NULL,
  `method_name` varchar(255) NOT NULL,
  `post_amount` double NOT NULL,
  `amount` double NOT NULL,
  `note` text NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Canceled','Success') NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `user_id`, `payment`, `type`, `method_name`, `post_amount`, `amount`, `note`, `phone`, `status`, `created_at`) VALUES
(0, 1, 'bank', 'manual', 'E-wallet', 500000000, 500000000, 'Chat Admin Untuk Deposit Saldo', '', 'Success', '2023-09-02 11:45:18');

-- --------------------------------------------------------

--
-- Table structure for table `deposit_methods`
--

CREATE TABLE `deposit_methods` (
  `id` int(11) NOT NULL,
  `payment` enum('pulsa','bank') NOT NULL,
  `type` enum('manual','auto') NOT NULL,
  `name` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `rate` double NOT NULL,
  `min_amount` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `deposit_methods`
--

INSERT INTO `deposit_methods` (`id`, `payment`, `type`, `name`, `note`, `rate`, `min_amount`, `status`) VALUES
(1, 'bank', 'manual', 'Bank Transfer', 'Chat Admin Untuk Deposit Saldo', 1, 300000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `free`
--

CREATE TABLE `free` (
  `id` int(11) NOT NULL,
  `ip` varchar(9999) DEFAULT NULL,
  `code` varchar(9999) DEFAULT NULL,
  `isUse` int(11) DEFAULT 0,
  `sn` varchar(9999) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `free`
--

INSERT INTO `free` (`id`, `ip`, `code`, `isUse`, `sn`) VALUES
(1, '110.138.83.112', 'GMODS-FREE-OBIBNG3P', 1, '2023-09-11 00:16:47'),
(2, '180.247.44.25, 172.70.189.65', NULL, 0, '2023-12-14 05:50:43'),
(3, '180.247.44.25, 108.162.227.113', NULL, 0, '2023-12-14 05:57:25'),
(4, '159.146.10.156, 172.69.199.162', NULL, 0, '2023-12-14 05:57:27'),
(5, '180.247.44.25, 172.70.189.72', NULL, 0, '2023-12-14 05:58:56'),
(6, '180.247.44.25, 172.69.165.6', NULL, 0, '2023-12-14 06:03:50'),
(7, '159.146.10.156, 172.69.199.156', NULL, 0, '2023-12-14 06:20:43'),
(8, '103.255.156.9, 108.162.226.5', NULL, 0, '2023-12-14 06:22:38'),
(9, '103.255.156.9, 108.162.226.4', NULL, 0, '2023-12-14 06:24:05'),
(10, '103.147.82.243, 162.158.106.54', NULL, 0, '2023-12-14 06:25:45'),
(11, '103.147.82.243, 162.158.106.54', NULL, 0, '2023-12-14 06:25:50'),
(12, '103.147.82.243, 162.158.189.20', NULL, 0, '2023-12-14 06:36:25'),
(13, '103.147.82.243, 162.158.162.80', NULL, 0, '2023-12-14 06:39:05'),
(14, '180.242.214.255, 172.71.218.193', NULL, 0, '2023-12-14 06:49:35');

-- --------------------------------------------------------

--
-- Table structure for table `invite`
--

CREATE TABLE `invite` (
  `id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `saldo` int(11) DEFAULT 0,
  `isUse` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invite`
--

INSERT INTO `invite` (`id`, `code`, `saldo`, `isUse`) VALUES
(33, 'XYZ-INVITE-07SIWYCZ', 300000, 1),
(34, 'XYZ-INVITE-W72AG8HO', 350000, 1),
(35, 'XYZ-INVITE-GST20SHX', 350000, 1),
(36, 'XYZ-INVITE-AE13DF0N', 400000, 1),
(37, 'XYZ-INVITE-CYYJGZUL', 350000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `login_logs`
--

INSERT INTO `login_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 56, '250.68.194.15, 172.71.124.112', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-16 02:33:03'),
(2, 55, '114.10.146.16, 108.162.226.107', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36', '2025-01-16 14:11:46'),
(3, 43, '103.120.170.9, 172.68.164.50', 'Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.200 Mobile Safari/537.36', '2025-01-16 15:07:23'),
(4, 1, '103.147.82.243, 172.70.208.151', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-16 15:55:09'),
(5, 38, '158.140.165.0, 172.70.208.128', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1', '2025-01-16 19:01:54'),
(6, 52, '182.1.67.186, 172.70.211.88', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-17 08:57:23'),
(7, 1, '103.147.82.243, 162.158.189.62', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 OPR/115.0.0.0', '2025-01-17 11:49:42'),
(8, 1, '103.147.82.243, 172.71.82.150', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 OPR/115.0.0.0', '2025-01-17 14:17:18'),
(9, 52, '114.5.246.230, 172.71.124.237', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-17 16:57:11'),
(10, 52, '114.5.246.100, 172.68.164.81', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-17 18:20:42'),
(11, 1, '103.147.82.243, 162.158.170.104', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-17 18:30:11'),
(12, 55, '249.129.236.213, 172.70.216.33', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36', '2025-01-17 18:47:33'),
(13, 58, '103.46.10.205, 172.70.143.63', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', '2025-01-17 20:12:03'),
(14, 52, '114.5.246.100, 172.68.164.155', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-17 20:25:11'),
(15, 38, '158.140.165.0, 172.70.208.128', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', '2025-01-17 20:37:27'),
(16, 1, '103.147.82.243, 172.71.152.2', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-18 13:27:34'),
(17, 52, '210.87.125.114, 172.70.147.128', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-18 14:47:16'),
(18, 56, '250.68.194.15, 162.158.107.16', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-18 16:03:55'),
(19, 63, '180.242.130.189, 172.70.210.169', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-01-18 17:19:06'),
(20, 1, '103.147.82.243, 172.71.82.50', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-19 13:02:44'),
(21, 63, '180.242.130.189, 172.69.34.13', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-01-19 23:04:49'),
(22, 43, '103.120.170.9, 162.158.106.39', 'Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.79 Mobile Safari/537.36', '2025-01-20 05:45:16'),
(23, 43, '103.120.170.9, 172.71.82.150', 'Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.79 Mobile Safari/537.36', '2025-01-20 06:11:02'),
(24, 62, '103.160.149.34, 162.158.88.129', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-20 17:12:25'),
(25, 1, '103.147.82.243, 172.70.208.151', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-20 17:24:18'),
(26, 1, '103.147.82.243, 172.70.143.230', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 OPR/115.0.0.0', '2025-01-20 20:47:25'),
(27, 1, '103.147.82.243, 172.68.164.154', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-20 22:30:13'),
(28, 1, '103.147.82.243, 172.71.124.179', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-20 22:31:25'),
(29, 67, '114.10.66.106, 162.158.190.82', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-20 22:59:13'),
(30, 56, '250.68.194.15, 162.158.106.232', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-20 23:35:22'),
(31, 1, '103.147.82.243, 162.158.108.151', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2025-01-20 23:50:52'),
(32, 1, '114.10.67.21', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-01 18:37:32'),
(33, 1, '114.10.67.21', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-01 19:12:50'),
(34, 1, '114.10.113.42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-01 23:26:13'),
(35, 1, '114.10.113.42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-01 23:28:37'),
(36, 1, '114.10.113.42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-02 00:01:27'),
(37, 1, '114.10.113.42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-02 00:01:47'),
(38, 1, '114.10.64.224', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-02 08:12:19'),
(39, 1, '114.10.64.224', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-02 13:26:49'),
(40, 1, '120.188.95.131', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-02 15:04:50'),
(41, 1, '120.188.95.131', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-02 15:35:13'),
(42, 1, '114.10.31.145', 'Mozilla/5.0 (Linux; Android 12; TECNO LG8n) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.122 Mobile Safari/537.36', '2025-02-03 14:51:44'),
(43, 1, '114.10.65.63', 'Mozilla/5.0 (Linux; Android 10; SM-A205F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.122 Mobile Safari/537.36', '2025-02-04 13:38:52'),
(44, 1, '120.188.92.24', 'Mozilla/5.0 (Linux; Android 12; TECNO LG8n) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.122 Mobile Safari/537.36', '2025-02-04 17:39:43'),
(45, 1, '114.10.31.151', 'Mozilla/5.0 (Linux; Android 12; TECNO LG8n) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.163 Mobile Safari/537.36', '2025-02-05 10:38:29'),
(46, 1, '114.10.31.151', 'Mozilla/5.0 (Linux; Android 10; SM-A205F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.122 Mobile Safari/537.36', '2025-02-05 10:48:10'),
(47, 1, '114.10.29.248', 'Mozilla/5.0 (Linux; Android 12; TECNO LG8n) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.6834.163 Mobile Safari/537.36', '2025-02-05 13:30:47'),
(48, 1, '114.10.29.248', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-05 15:06:29'),
(49, 1, '114.10.29.248', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-05 16:36:07'),
(50, 1, '114.10.112.225', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-05 18:34:34'),
(51, 1, '114.10.112.225', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-05 20:57:55'),
(52, 1, '114.10.65.161', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-06 06:48:54'),
(53, 1, '114.10.65.161', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-06 07:25:41'),
(54, 1, '114.10.65.161', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-06 08:08:34'),
(55, 1, '114.10.112.220', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-06 11:49:31'),
(56, 1, '114.10.112.220', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-06 15:17:06'),
(57, 1, '103.147.82.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 OPR/116.0.0.0', '2025-02-06 16:02:17'),
(58, 1, '114.10.113.51', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-06 18:02:40'),
(59, 1, '114.10.113.51', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-06 18:41:51'),
(60, 1, '114.10.66.30', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36', '2025-02-08 11:14:10'),
(61, 1, '114.10.28.45', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', '2025-03-03 03:52:18'),
(62, 1, '114.10.30.213', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', '2025-03-03 12:59:41'),
(63, 1, '114.10.66.249', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', '2025-03-13 13:59:30'),
(64, 1, '114.10.64.101', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', '2025-03-14 14:07:00'),
(65, 1, '114.4.82.223', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36', '2025-03-19 14:36:48'),
(66, 1, '103.147.82.243', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 00:01:16'),
(67, 1, '114.10.113.46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 09:31:14'),
(68, 1, '114.10.65.19', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 10:48:14'),
(69, 1, '114.10.65.19', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 11:42:28'),
(70, 1, '114.10.65.19', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 13:51:35'),
(71, 1, '140.213.7.27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 15:55:13'),
(72, 1, '114.10.31.14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 19:22:31'),
(73, 1, '114.10.31.14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 19:23:44'),
(74, 1, '114.10.31.14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 20:06:12'),
(75, 1, '114.10.31.14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-22 21:40:33'),
(76, 1, '114.10.115.46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-23 10:09:48'),
(77, 1, '114.10.115.46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-23 11:44:21'),
(78, 1, '114.10.66.102', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-24 09:13:47'),
(79, 1, '114.10.112.201', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-25 14:22:10'),
(80, 1, '114.10.113.179', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', '2025-03-30 14:30:04'),
(81, 1, '120.188.64.70', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36', '2025-04-23 09:22:51'),
(82, 1, '120.188.32.163', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36', '2025-05-03 14:16:23'),
(83, 1, '114.10.64.89', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', '2025-05-11 18:53:48'),
(84, 1, '114.10.30.212', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', '2025-05-22 15:44:22'),
(85, 1, '114.4.213.28', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', '2025-05-25 13:29:59'),
(86, 1, '114.10.64.25', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', '2025-06-26 22:22:49'),
(87, 1, '120.188.34.90', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-07-03 11:11:21'),
(88, 1, '114.10.64.255', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-07-06 09:12:58'),
(89, 1, '114.10.64.255', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-07-06 09:15:14');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `username` varchar(255) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `action` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_akses`
--

CREATE TABLE `log_akses` (
  `id` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `timestamp` timestamp NULL DEFAULT current_timestamp(),
  `user_agent` text DEFAULT NULL,
  `page_url` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `log_akses`
--

INSERT INTO `log_akses` (`id`, `ip`, `timestamp`, `user_agent`, `page_url`) VALUES
(1, '120.188.35.77', '2025-05-23 11:28:46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(2, '114.4.213.254', '2025-05-24 07:24:20', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(3, '114.4.213.28', '2025-05-25 06:45:41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(4, '160.22.206.49', '2025-05-25 08:35:45', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(5, '114.10.112.84', '2025-05-25 09:36:03', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(6, '120.188.33.38', '2025-05-26 01:02:18', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(7, '114.10.113.172', '2025-05-26 05:36:20', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(8, '120.188.67.71', '2025-05-26 11:23:48', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(9, '140.213.185.2', '2025-05-27 11:06:22', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(10, '140.213.185.198', '2025-05-27 11:14:52', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(11, '140.213.184.100', '2025-05-27 11:39:27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(12, '90.134.5.236', '2025-05-28 20:16:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', NULL),
(13, '112.215.238.35', '2025-05-29 02:05:27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(14, '125.166.179.25', '2025-05-29 08:12:54', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(15, '158.62.9.189', '2025-05-30 07:01:15', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(16, '160.25.94.242', '2025-05-30 14:10:47', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(17, '114.10.153.159', '2025-05-30 18:38:47', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36', NULL),
(18, '112.215.45.205', '2025-05-31 06:45:36', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(19, '114.10.152.106', '2025-05-31 18:47:24', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.33.0-gn', NULL),
(20, '140.213.169.145', '2025-06-01 05:22:14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', NULL),
(21, '140.213.163.103', '2025-06-01 05:22:20', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', NULL),
(22, '140.213.161.201', '2025-06-01 05:24:55', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', NULL),
(23, '182.1.230.204', '2025-06-01 15:09:00', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(24, '176.64.17.49', '2025-06-01 16:58:01', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36', NULL),
(25, '114.10.152.98', '2025-06-01 17:36:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36', NULL),
(26, '114.10.152.14', '2025-06-02 01:13:49', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(27, '114.10.30.137', '2025-06-02 06:00:25', 'Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1', NULL),
(28, '77.222.156.55', '2025-06-02 07:39:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36', NULL),
(29, '31.41.90.36', '2025-06-02 07:39:30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', NULL),
(30, '88.154.1.72', '2025-06-02 08:08:00', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(31, '77.111.246.40', '2025-06-02 11:04:30', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36 OPR/89.0.0.0', NULL),
(32, '140.213.13.176', '2025-06-02 14:56:15', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(33, '182.253.57.133', '2025-06-03 00:28:25', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(34, '43.245.86.40', '2025-06-03 08:06:22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(35, '136.158.10.27', '2025-06-03 09:18:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(36, '103.151.92.15', '2025-06-03 09:32:12', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', NULL),
(37, '106.73.158.39', '2025-06-03 12:24:03', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(38, '114.125.43.219', '2025-06-03 16:44:40', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', NULL),
(39, '77.111.247.7', '2025-06-04 00:14:23', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36 OPR/89.0.0.0', NULL),
(40, '106.73.158.39', '2025-06-04 15:03:29', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(41, '45.87.213.218', '2025-06-04 15:14:23', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(42, '103.155.232.225', '2025-06-04 15:18:56', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(43, '182.178.97.98', '2025-06-04 15:32:44', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(44, '219.100.37.233', '2025-06-04 16:12:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(45, '92.115.70.112', '2025-06-05 09:39:05', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(46, '27.125.242.98', '2025-06-05 14:50:15', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(47, '115.164.140.5', '2025-06-05 14:50:18', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(48, '203.189.186.241', '2025-06-06 02:45:51', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(49, '182.178.97.98', '2025-06-06 13:05:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(50, '203.189.189.49', '2025-06-06 13:18:14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(51, '93.159.49.145', '2025-06-06 17:34:16', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/89.0.0.0', NULL),
(52, '46.32.187.42', '2025-06-06 17:57:15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(53, '36.75.2.138', '2025-06-06 18:02:14', 'Mozilla/5.0 (Android 11; Mobile; rv:139.0) Gecko/139.0 Firefox/139.0', NULL),
(54, '116.97.107.196', '2025-06-07 05:18:42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(55, '182.253.57.133', '2025-06-07 06:02:51', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(56, '116.97.107.174', '2025-06-07 13:28:01', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(57, '212.192.245.188', '2025-06-07 14:19:26', 'Mozilla/5.0 (Linux; Android 15; RMX5020 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.127 Mobile Safari/537.36', NULL),
(58, '171.241.164.17', '2025-06-07 15:38:56', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(59, '185.41.120.40', '2025-06-07 19:44:34', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(60, '66.102.9.100', '2025-06-07 19:44:39', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(61, '66.102.9.101', '2025-06-07 19:44:40', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(62, '59.146.107.194', '2025-06-08 06:55:11', 'Mozilla/5.0 (Linux; Android 15; RMX5020 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.127 Mobile Safari/537.36', NULL),
(63, '46.32.187.42', '2025-06-08 10:22:52', 'Mozilla/5.0 (Linux; Android 8.1.0; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.7151.72 Mobile Safari/537.36', NULL),
(64, '113.185.43.53', '2025-06-08 12:30:14', 'Mozilla/5.0 (Linux; Android 15; RMX5020 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.127 Mobile Safari/537.36', NULL),
(65, '113.185.42.14', '2025-06-08 16:12:08', 'Mozilla/5.0 (Linux; Android 15; RMX5020 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.127 Mobile Safari/537.36', NULL),
(66, '182.1.209.152', '2025-06-09 09:20:47', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(67, '116.97.107.173', '2025-06-10 05:14:07', 'Mozilla/5.0 (Linux; Android 15; RMX5020 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.127 Mobile Safari/537.36', NULL),
(68, '113.185.44.173', '2025-06-10 08:26:34', 'Mozilla/5.0 (Linux; Android 15; RMX5020 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.127 Mobile Safari/537.36', NULL),
(69, '110.227.183.247', '2025-06-11 01:27:43', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.125 Mobile Safari/537.36', NULL),
(70, '206.85.1.107', '2025-06-11 02:50:35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(71, '116.97.106.140', '2025-06-11 02:59:27', 'Mozilla/5.0 (Linux; Android 15; RMX5020 Build/AP3A.240617.008) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.127 Mobile Safari/537.36', NULL),
(72, '114.79.1.150', '2025-06-11 03:33:26', 'Mozilla/5.0 (Linux; Android 11; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.125 Mobile Safari/537.36', NULL),
(73, '180.75.247.172', '2025-06-11 06:02:37', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(74, '175.143.56.131', '2025-06-11 07:11:21', 'Mozilla/5.0 (Linux; Android 11; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.7151.61 Mobile Safari/537.36', NULL),
(75, '193.104.75.35', '2025-06-11 08:29:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 Edg/137.0.0.0', NULL),
(76, '180.190.41.138', '2025-06-11 10:13:56', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', NULL),
(77, '180.253.187.217', '2025-06-11 15:33:29', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(78, '116.97.107.118', '2025-06-12 01:49:07', 'Mozilla/5.0 (Linux; Android 9; Nexus 5 Build/PQ3A.190801.002) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.117 Mobile Safari/537.36', NULL),
(79, '114.10.31.124', '2025-06-12 02:48:31', 'Mozilla/5.0 (Linux; Android 10; SM-A205F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.125 Mobile Safari/537.36', NULL),
(80, '88.204.52.108', '2025-06-12 15:27:31', 'Mozilla/5.0 (Linux; arm_64; Android 15; M2102K1G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.49 YaBrowser/25.4.6.49.00 SA/3 Mobile Safari/537.36', NULL),
(81, '79.105.221.30', '2025-06-13 04:13:05', 'Mozilla/5.0 (Linux; arm_64; Android 15; CPH2711) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.49 YaBrowser/25.4.6.49.00 SA/3 Mobile Safari/537.36', NULL),
(82, '49.37.100.188', '2025-06-13 04:14:42', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(83, '79.105.37.254', '2025-06-13 06:04:40', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/22A3354 Safari/604.1', NULL),
(84, '180.75.247.172', '2025-06-13 13:13:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(85, '112.215.174.107', '2025-06-13 13:55:04', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(86, '176.62.76.5', '2025-06-14 13:00:05', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(87, '5.90.7.115', '2025-06-15 01:50:05', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(88, '5.90.13.95', '2025-06-15 01:59:10', 'Mozilla/5.0 (Linux; Android 15; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.7151.88 Mobile Safari/537.36', NULL),
(89, '176.62.76.3', '2025-06-15 05:19:16', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(90, '36.69.230.99', '2025-06-15 11:55:03', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', NULL),
(91, '146.190.97.85', '2025-06-15 12:58:59', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36', NULL),
(92, '114.10.66.135', '2025-06-15 13:46:48', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/368.0.756386193 Mobile/15E148 Safari/604.1', NULL),
(93, '136.158.58.194', '2025-06-15 15:04:12', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(94, '112.200.225.84', '2025-06-15 17:06:25', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 Edg/137.0.0.0', NULL),
(95, '175.158.36.154', '2025-06-15 19:17:14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36', NULL),
(96, '140.213.244.152', '2025-06-15 21:17:01', 'Mozilla/5.0 (Linux; Android 15; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.7151.61 Mobile Safari/537.36', NULL),
(97, '103.190.41.31', '2025-06-16 12:12:30', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(98, '125.164.126.162', '2025-06-16 15:33:40', 'Mozilla/5.0 (Linux; Android 15; SM-A536E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.7151.61 Mobile Safari/537.36', NULL),
(99, '177.244.106.18', '2025-06-16 19:48:27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(100, '169.224.105.230', '2025-06-16 22:31:25', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(101, '49.145.238.164', '2025-06-17 08:14:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(102, '175.158.36.154', '2025-06-17 08:31:43', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(103, '114.122.38.38', '2025-06-18 14:00:38', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(104, '140.213.147.84', '2025-06-18 14:31:58', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(105, '112.215.200.143', '2025-06-18 15:50:25', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(106, '128.1.190.8', '2025-06-18 17:50:05', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(107, '125.164.11.247', '2025-06-19 11:13:37', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(108, '49.145.196.156', '2025-06-19 13:52:20', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(109, '110.139.236.12', '2025-06-19 16:21:01', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(110, '114.122.38.38', '2025-06-19 16:41:43', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(111, '185.107.56.212', '2025-06-20 06:53:09', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(112, '175.176.39.154', '2025-06-20 06:53:10', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(113, '74.125.208.14', '2025-06-20 06:53:15', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(114, '66.249.83.109', '2025-06-20 06:53:17', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(115, '66.249.83.76', '2025-06-20 06:53:17', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(116, '180.253.191.72', '2025-06-21 07:28:32', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(117, '182.253.57.133', '2025-06-21 13:04:34', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(118, '104.28.249.187', '2025-06-21 14:20:26', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(119, '114.122.40.178', '2025-06-21 17:12:28', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(120, '104.28.217.187', '2025-06-21 17:56:29', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(121, '143.44.165.47', '2025-06-21 18:13:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(122, '114.122.39.23', '2025-06-21 18:35:57', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(123, '180.191.162.243', '2025-06-21 23:50:46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(124, '110.138.34.10', '2025-06-22 00:06:43', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', NULL),
(125, '112.215.245.22', '2025-06-22 01:44:55', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.32.0-gn', NULL),
(126, '140.213.149.229', '2025-06-22 02:06:14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(127, '210.170.22.208', '2025-06-22 03:36:43', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36', NULL),
(128, '112.215.236.252', '2025-06-22 04:13:14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(129, '8.212.169.70', '2025-06-22 05:01:56', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(130, '209.107.192.16', '2025-06-22 07:10:30', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(131, '124.150.139.62', '2025-06-22 08:11:11', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/368.0.756386193 Mobile/15E148 Safari/604.1', NULL),
(132, '172.105.9.117', '2025-06-22 11:02:52', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', NULL),
(133, '216.247.19.111', '2025-06-23 13:30:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(134, '95.135.232.147', '2025-06-23 17:58:34', 'Go-http-client/1.1', NULL),
(135, '114.122.39.177', '2025-06-23 20:21:20', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.32.0-gn', NULL),
(136, '114.10.135.49', '2025-06-24 03:09:35', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(137, '125.164.22.197', '2025-06-24 11:37:34', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(138, '136.158.58.154', '2025-06-24 15:43:27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(139, '77.79.175.95', '2025-06-24 17:24:43', 'Mozilla/5.0 (Linux; arm_64; Android 12; SM-F900F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.7103.271 YaBrowser/25.6.0.271.00 SA/3 Mobile Safari/537.36', NULL),
(140, '37.76.159.108', '2025-06-24 19:50:14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 YaBrowser/25.4.0.0 Safari/537.36', NULL),
(141, '178.47.65.241', '2025-06-24 19:50:34', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36', NULL),
(142, '180.242.68.169', '2025-06-25 05:31:32', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(143, '27.109.115.158', '2025-06-25 09:41:46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(144, '103.214.185.89', '2025-06-25 10:30:57', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 Edg/137.0.0.0', NULL),
(145, '185.184.192.219', '2025-06-25 10:56:21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(146, '180.191.162.243', '2025-06-26 05:19:59', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36', NULL),
(147, '27.109.115.158', '2025-06-26 10:25:46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(148, '208.115.233.116', '2025-06-26 15:01:29', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(149, '185.184.192.219', '2025-06-26 16:46:45', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(150, '110.5.69.94', '2025-06-26 19:21:23', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(151, '95.180.128.103', '2025-06-27 00:48:20', 'Mozilla/5.0 (Linux; Android 12; SM-A536E Build/V417IR) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.120 Mobile Safari/537.36', NULL),
(152, '36.70.172.187', '2025-06-27 13:14:42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.36.0-gn', NULL),
(153, '172.105.92.147', '2025-06-28 11:58:10', 'Fuzz Faster U Fool v2.1.0-dev', NULL),
(154, '36.70.172.187', '2025-06-28 19:24:32', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.36.0-gn', NULL),
(155, '136.158.78.67', '2025-06-29 03:34:27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(156, '114.122.41.221', '2025-06-29 06:42:56', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(157, '37.19.205.247', '2025-06-29 15:08:28', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL),
(158, '180.191.207.254', '2025-06-29 15:54:34', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(159, '36.70.172.187', '2025-06-30 04:25:19', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/14.36.0-gn', NULL),
(160, '213.230.118.27', '2025-06-30 07:08:04', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', NULL),
(161, '210.170.22.208', '2025-06-30 14:52:35', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', NULL),
(162, '180.253.73.44', '2025-06-30 17:16:46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(163, '38.54.4.14', '2025-06-30 18:43:25', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36', NULL),
(164, '90.156.162.246', '2025-07-01 00:43:57', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(165, '66.102.9.101', '2025-07-01 00:44:02', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(166, '66.102.9.99', '2025-07-01 00:44:04', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(167, '66.102.9.100', '2025-07-01 00:44:04', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(168, '36.81.11.54', '2025-07-01 07:43:19', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36', NULL),
(169, '213.230.78.2', '2025-07-01 09:31:36', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(170, '175.100.59.202', '2025-07-01 14:07:05', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(171, '146.70.72.92', '2025-07-01 17:51:07', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36', NULL),
(172, '210.170.22.208', '2025-07-02 00:48:34', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(173, '213.206.62.182', '2025-07-02 08:49:57', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(174, '74.125.208.15', '2025-07-02 08:50:02', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(175, '66.249.83.108', '2025-07-02 08:50:03', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(176, '74.125.210.33', '2025-07-02 08:50:03', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(177, '66.249.81.99', '2025-07-02 17:46:55', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(178, '66.102.8.130', '2025-07-02 17:46:59', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(179, '172.104.155.149', '2025-07-02 21:30:35', 'Fuzz Faster U Fool v2.1.0-dev', NULL),
(180, '66.249.81.101', '2025-07-02 23:17:53', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(181, '66.249.81.100', '2025-07-02 23:17:54', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(182, '66.102.9.100', '2025-07-02 23:20:28', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(183, '66.102.9.101', '2025-07-02 23:20:30', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(184, '185.213.230.57', '2025-07-02 23:20:57', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36', NULL),
(185, '156.244.8.82', '2025-07-03 00:56:02', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36', NULL),
(186, '135.125.239.228', '2025-07-03 02:12:29', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(187, '84.54.80.181', '2025-07-03 02:55:59', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(188, '203.106.115.158', '2025-07-03 18:03:46', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0', NULL),
(189, '121.7.181.34', '2025-07-04 15:53:40', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36', NULL),
(190, '202.166.81.117', '2025-07-05 03:24:05', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', NULL),
(191, '210.10.1.200', '2025-07-05 04:51:30', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(192, '45.84.107.55', '2025-07-05 06:22:29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0', NULL),
(193, '192.42.116.185', '2025-07-05 11:02:00', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0', NULL),
(194, '185.40.4.29', '2025-07-05 11:03:53', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0', NULL),
(195, '162.128.3.77', '2025-07-06 00:33:58', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', NULL),
(196, '178.128.54.80', '2025-07-07 06:53:42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', NULL),
(197, '110.136.30.47', '2025-07-07 07:31:30', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(198, '85.140.161.90', '2025-07-07 12:49:31', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(199, '66.249.81.99', '2025-07-07 12:49:45', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(200, '66.102.8.132', '2025-07-07 12:49:47', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(201, '66.102.9.101', '2025-07-07 12:49:47', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(202, '125.164.19.188', '2025-07-07 13:59:50', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(203, '125.164.17.111', '2025-07-07 14:11:20', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(204, '125.164.23.52', '2025-07-07 14:16:01', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(205, '125.164.20.206', '2025-07-07 14:19:06', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(206, '120.28.200.119', '2025-07-07 14:55:22', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(207, '103.80.230.97', '2025-07-07 16:54:59', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(208, '202.43.172.4', '2025-07-07 16:55:04', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(209, '196.131.157.220', '2025-07-08 01:21:31', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(210, '66.249.93.76', '2025-07-08 01:21:36', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(211, '66.249.93.77', '2025-07-08 01:21:37', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(212, '120.29.69.69', '2025-07-08 02:32:37', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/136.0.7103.91 Mobile/15E148 Safari/604.1', NULL),
(213, '182.4.39.17', '2025-07-08 06:25:50', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(214, '62.16.2.22', '2025-07-08 06:38:41', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', NULL),
(215, '103.105.76.87', '2025-07-08 07:45:04', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(216, '125.162.209.254', '2025-07-08 14:01:09', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36', NULL),
(217, '149.102.244.69', '2025-07-08 22:45:26', 'Mozilla/5.0 (Linux; arm_64; Android 10; DNN-LX9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.1823 YaApp_Android/24.120.1 YaSearchBrowser/24.120.1 BroPP/1.0 SA/3 Mobile Safari/537.36', NULL),
(218, '95.25.169.45', '2025-07-08 22:56:46', 'Mozilla/5.0 (Linux; arm_64; Android 10; DNN-LX9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.1823 YaApp_Android/24.120.1 YaSearchBrowser/24.120.1 BroPP/1.0 SA/3 Mobile Safari/537.36', NULL),
(219, '54.175.74.27', '2025-07-08 23:42:03', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.1.25 (KHTML, like Gecko) Version/8.0 Safari/600.1.25', NULL),
(220, '54.37.204.108', '2025-07-09 00:11:27', 'Mozilla/5.0 (Linux; arm_64; Android 10; DNN-LX9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.1823 YaApp_Android/24.120.1 YaSearchBrowser/24.120.1 BroPP/1.0 SA/3 Mobile Safari/537.36', NULL),
(221, '140.213.139.228', '2025-07-09 04:58:20', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(222, '62.16.2.22', '2025-07-09 13:52:36', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', NULL),
(223, '2.134.162.150', '2025-07-09 17:30:27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36', NULL),
(224, '66.249.81.100', '2025-07-09 18:53:51', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(225, '66.249.81.99', '2025-07-09 18:53:52', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(226, '66.249.83.108', '2025-07-09 18:53:52', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)', NULL),
(227, '85.117.106.141', '2025-07-09 19:03:18', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/138.0.7204.119 Mobile/15E148 Safari/604.1', NULL),
(228, '196.191.159.11', '2025-07-09 20:46:55', 'Mozilla/5.0 (Linux; Android 13; TECNO BG6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.7151.115 Mobile Safari/537.36', NULL),
(229, '117.20.116.247', '2025-07-10 04:26:29', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(230, '185.228.105.23', '2025-07-10 16:58:29', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', NULL),
(231, '188.162.1.206', '2025-07-10 20:54:36', 'Mozilla/5.0 (Linux; Android 11; 220333QPG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.98 Mobile Safari/537.36', NULL),
(232, '188.162.1.83', '2025-07-11 07:46:55', 'Mozilla/5.0 (Linux; Android 11; 220333QPG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.98 Mobile Safari/537.36', NULL),
(233, '180.253.164.141', '2025-07-11 09:03:48', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL),
(234, '112.205.143.183', '2025-07-11 13:58:46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(235, '31.223.42.189', '2025-07-11 14:55:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL),
(236, '85.106.97.38', '2025-07-11 15:35:51', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(237, '140.233.157.100', '2025-07-11 23:18:15', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36', NULL),
(238, '185.228.105.23', '2025-07-12 06:28:58', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36', NULL),
(239, '50.60.236.208', '2025-07-12 22:01:43', 'Mozilla/5.0 (Linux; Android 15; SM-S908E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.7204.67 Mobile Safari/537.36', NULL),
(240, '140.213.171.14', '2025-07-13 04:10:16', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', NULL),
(241, '61.245.13.10', '2025-07-13 11:22:55', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', NULL),
(242, '46.155.230.101', '2025-07-14 06:00:47', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(243, '176.219.6.229', '2025-07-14 06:24:32', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL),
(244, '112.215.165.123', '2025-07-14 12:34:38', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/28.0 Chrome/130.0.0.0 Mobile Safari/537.36', NULL),
(245, '120.188.37.143', '2025-07-14 15:09:18', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mod_data`
--

CREATE TABLE `mod_data` (
  `id` int(11) NOT NULL,
  `name` varchar(9999) NOT NULL,
  `mod_status` varchar(255) NOT NULL,
  `text` varchar(9999) NOT NULL,
  `version` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mod_data`
--

INSERT INTO `mod_data` (`id`, `name`, `mod_status`, `text`, `version`, `status`) VALUES
(1, 'XYOURZONE', 'Safe', 'Bypass Allways On 24 hours', '2.6', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `created_at`, `content`) VALUES
(8, '2024-06-04 12:51:39', 'Peringatan untuk semua seller resmi xyourzone untuk tidak memainkan harga jual yang sudah di berikan, jika kam menemukan seller yang bermain harga akan kami block permanen tanpa adanya pemberitahuan terlebih dahulu!');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `data` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `profit` double NOT NULL,
  `remains` int(11) NOT NULL DEFAULT 0,
  `status` enum('Pending','Processing','Error','Partial','Success') NOT NULL,
  `token` varchar(255) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `provider_order_id` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `service_name`, `data`, `quantity`, `price`, `profit`, `remains`, `status`, `token`, `provider_id`, `provider_order_id`, `created_at`) VALUES
(1, 43, 'MLBB - Key 1 Day', 'Kkk', 1, 5000, 1, 1, 'Success', 'MLBB_CNUQNYAEHE', 1, '', '2025-01-16 15:07:37'),
(2, 56, 'MLBB - Key 3 Day', 'DAZETT STORE.', 1, 5000, 3, 1, 'Success', 'MLBB_4OLFAYLSZJ', 1, '', '2025-01-18 16:04:33'),
(3, 63, 'MLBB - Key 1 Day', 'tester', 1, 5000, 1, 1, 'Success', 'MLBB_QXOFOGGUZB', 1, '', '2025-01-19 23:05:13'),
(4, 43, 'MLBB Injector - 7 Day', 'Lanz', 1, 25000, 7, 1, 'Success', 'MLBB_Injector_ZFO1OHDFLD', 1, '', '2025-01-20 06:11:19'),
(5, 62, 'MLBB - Key 30 Day', 'KIISTOREID', 1, 35000, 30, 1, 'Success', 'MLBB_USGDHOWICD', 1, '', '2025-01-20 17:12:48'),
(6, 56, 'MLBB - Key 1 Day', 'DAZETT STORE.', 1, 5000, 1, 1, 'Success', 'MLBB_HDSJTDLA5F', 1, '', '2025-01-20 23:36:24'),
(7, 1, 'MLBB - Key 7 Day', 'Bayu', 1, 15000, 7, 1, 'Success', 'MLBB_H0SYFNRKPX', 1, '', '2025-02-02 13:28:02'),
(8, 1, 'MLBB - Key 30 Day', 'Bayu2', 2, 70000, 60, 2, 'Success', 'MLBB_2YHCIXMDTL', 1, '', '2025-02-02 13:29:00'),
(9, 1, 'MLBB - Key 30 Day', 'rendi', 2, 70000, 60, 2, 'Success', 'MLBB_I04BRCUPTT', 1, '', '2025-02-02 13:38:00'),
(10, 1, 'MLBB - Key 30 Day', 'aji', 1, 35000, 30, 1, 'Success', 'MLBB_E0LHOD5AMN', 1, '', '2025-02-02 15:05:43'),
(11, 1, 'MLBB - Key 30 Day', 'myusername', 1, 35000, 30, 1, 'Success', 'MLBB_TBJOUNBDQT', 1, '', '2025-02-04 13:42:17'),
(12, 1, 'MLBB - Key 7 Day', 'user234', 1, 15000, 7, 1, 'Success', 'MLBB_A2JHTRRWDW', 1, '', '2025-02-05 10:48:53'),
(13, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'baru', 1, 134999, 127, 1, 'Success', 'MLBB_XUEITG21KU', 1, '', '2025-02-05 15:06:55'),
(14, 1, 'MLBB - Key 30 Day', 'elang', 1, 35000, 30, 1, 'Success', 'MLBB_AT4JUGJMGM', 1, '', '2025-02-05 16:36:50'),
(15, 1, 'MLBB - Key 30 Day', 'ling', 10, 350000, 300, 10, 'Success', 'MLBB_R7J37WOIDS', 1, '', '2025-02-05 18:34:57'),
(16, 1, 'MLBB - Key 30 Day', 'puput', 2, 70000, 60, 2, 'Success', 'MLBB_O3HMRWN2LS', 1, '', '2025-02-05 21:00:31'),
(17, 1, 'MLBB - Key 7 Day', 'kntol', 1, 15000, 7, 1, 'Success', 'MLBB_ZWR0BMMHAQ', 1, '', '2025-02-06 07:26:19'),
(18, 1, 'MLBB Injector - 30 Day', 'testing20', 1, 65000, 30, 1, 'Success', 'MLBB_Injector_ZHPAHSM15I', 1, '', '2025-02-06 08:09:48'),
(19, 1, 'MLBB - Key 30 Day', 'baru', 1, 35000, 30, 1, 'Success', 'MLBB_3ONSPDTQZM', 1, '', '2025-02-06 08:42:45'),
(20, 1, 'MLBB - Key 30 Day', 'zilong', 1, 35000, 30, 1, 'Success', 'MLBB_2GDDM2E42I', 1, '', '2025-02-06 15:17:28'),
(21, 1, 'MLBB - Key 30 Day', 'pharsa', 1, 35000, 30, 1, 'Success', 'MLBB_31AM6TRHL3', 1, '', '2025-03-03 03:53:12'),
(22, 1, 'MLBB - Key 30 Day', 'harith', 20, 700000, 600, 20, 'Success', 'MLBB_B3MS2ADXAA', 1, '', '2025-03-03 13:00:15'),
(23, 1, 'MLBB - Key 30 Day', 'gusion', 2, 70000, 60, 2, 'Success', 'MLBB_JE5L6YRQMW', 1, '', '2025-03-13 13:59:59'),
(24, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'eudora', 5, 674995, 635, 5, 'Success', 'MLBB_IJWLQSNDRF', 1, '', '2025-03-14 14:07:31'),
(25, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'lukas', 10, 1349990, 1270, 10, 'Success', 'MLBB_ILLIQDGSNN', 1, '', '2025-03-19 14:40:41'),
(26, 1, 'MLBB - Key 30 Day', 'nobara', 4, 140000, 120, 4, 'Success', 'MLBB_ZJGM0Y6ZJM', 1, '', '2025-03-22 13:52:34'),
(27, 1, 'MLBB Private - Key 30 Day', 'aulus', 5, 500000, 150, 5, 'Success', 'MLBB_PRIVATE_CU6QTJRSZP', 1, '', '2025-03-22 20:06:49'),
(28, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', '@ToracinnoBold', 1, 134999, 0, 1, 'Success', 'XYZ_GKD1I2MSKD', 1, '1', '2025-03-25 14:29:27'),
(29, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'ToracinnoBold', 1, 134999, 0, 1, 'Success', 'XYZ_UO2BHQPAXN', 1, '1', '2025-03-26 10:10:30'),
(30, 1, 'MLBB - Key 30 Day', 'kylearchangel', 2, 70000, 60, 2, 'Success', 'MLBB_XLDNHLA50L', 1, '', '2025-03-30 14:30:29'),
(31, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'julian', 100, 13499900, 12700, 100, 'Success', 'MLBB_R40HZYIYMM', 1, '', '2025-04-23 09:23:24'),
(32, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'millo', 100, 13499900, 12700, 100, 'Success', 'MLBB_X6RUCOYD1Y', 1, '', '2025-05-03 14:18:29'),
(33, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'LAYLA', 100, 13499900, 12700, 100, 'Success', 'MLBB_AXGYZ3XXLX', 1, '', '2025-05-11 19:21:52'),
(34, 1, 'MLBB - Key 30 Day', 'VIP 31', 10, 350000, 300, 10, 'Success', 'MLBB_HCNS7FWQPD', 1, '', '2025-06-26 22:23:57'),
(35, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'zetian', 10, 1349990, 1270, 10, 'Success', 'MLBB_GDZWJHRTMT', 1, '', '2025-07-03 11:12:15'),
(36, 1, 'MLBB - Key 60 Days + 3 Days (Bonus)', 'VIP - Omega Zero', 10, 849990, 630, 10, 'Success', 'MLBB_FL5NDKUHMS', 1, '', '2025-07-06 09:13:51'),
(37, 1, 'MLBB - Key 60 Days + 3 Days (Bonus)', 'Omega Zero | VIP', 10, 849990, 630, 10, 'Success', 'MLBB_7Z71MIDORM', 1, '', '2025-07-06 09:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `created_at`, `content`) VALUES
(1, 'INFO UPDATE', '2021-03-10 16:11:31', '<h5 style=\"margin-top: 0px; margin-bottom: 0.5rem; font-weight: 600; line-height: 1.2; font-size: 1.16875rem; font-family: \"Baloo Paaji 2\", cursive;\"><span style=\"color: rgb(73, 80, 87); font-family: \"Times New Roman\";\">- Telegram:Â </span><a href=\"https://t.me/ToracinnoBold\" target=\"_blank\" style=\"\"><span style=\"font-family: \"Times New Roman\";\"><font color=\"#ff0000\">@XYOURZONE</font></span></a> </br> <span style=\"color: rgb(73, 80, 87); font-family: \"Times New Roman\";\">- Whatsapp:Â </span><a href=\"https://wa.me/+6289637740891\" target=\"_blank\" style=\"\"><span style=\"font-family: \"Times New Roman\";\"><font color=\"#ff0000\">XYOURZONE</font></span></a> </h5> '),
(2, 'Ketentuan layanan', '2021-03-10 16:13:23', '<h5 style=\"margin-top: 0px; margin-bottom: 0.5rem; font-weight: 600; line-height: 1.2; font-size: 1.16875rem; color: rgb(73, 80, 87); font-family: \"Baloo Paaji 2\", cursive;\"><span style=\"font-family: \"Times New Roman\";\">ï»¿</span><span style=\"font-family: \"Times New Roman\";\">1. Umum</span></h5><ul style=\"color: rgb(116, 122, 128); font-family: \"Baloo Paaji 2\", cursive; font-size: 14.96px;\"><li><span style=\"font-weight: bold; font-family: \"Times New Roman\";\">XYOURZONE</span><span style=\"font-family: \"Times New Roman\";\">Â sama sekali tidak akan bertanggung jawab jika anda memasukkan Data yang salah dalam melakukan pemesanan.</span></li><li><span style=\"font-family: \"Times New Roman\";\">Tidak dapat mengembalikan dana yang sudah ada jika key sudah digunakan dalam 1x24 Jam</span></li><li><span style=\"font-family: \"Times New Roman\";\">Harga yang sudah di terapkan tidak dapat di ubah-ubah.</li></span><li><span style=\"font-family: \"Times New Roman\";\">Tidak boleh memainkan harga yang sudah ada, mengurangi atau menambahkan harga yang sudah ada, jika ketahuan akun anda akan di tutup permanen tanpa pengembalian dana</li></span></ul><h5 style=\"margin-top: 0px; margin-bottom: 0.5rem; font-weight: 600; line-height: 1.2; font-size: 1.16875rem; color: rgb(73, 80, 87); font-family: \"Baloo Paaji 2\", cursive;\"><span style=\"font-family: \"Times New Roman\";\">2. Transaksi</span></h5><ul style=\"color: rgb(116, 122, 128); font-family: \"Baloo Paaji 2\", cursive; font-size: 14.96px;\"><li><span style=\"font-family: \"Times New Roman\";\">Transaksi atau pemesanan yang anda telah buat tidak dapat dibatalkan.</span></li><li><span style=\"font-family: \"Times New Roman\";\">Harga produk yang kami sediakan dapatÂ  berubah sewaktu-waktu.</span></li></ul> '),
(3, 'Pertanyaan umum', '2021-03-10 16:15:21', '<h5 style=\"margin-top: 0px; margin-bottom: 0.5rem; font-weight: 600; line-height: 1.2; font-size: 1.16875rem; color: rgb(73, 80, 87); font-family: &quot;Baloo Paaji 2&quot;, cursive;\"><span style=\"font-family: &quot;Times New Roman&quot;;\">1. Bagaimana cara membuat pesanan?</span></h5><ul style=\"color: rgb(116, 122, 128); font-family: &quot;Baloo Paaji 2&quot;, cursive; font-size: 14.96px;\"><li><span style=\"font-family: &quot;Times New Roman&quot;;\">Anda dapat langsung membaca&nbsp;</span><span style=\"font-weight: bold; font-family: &quot;Times New Roman&quot;;\">Informasi</span><span style=\"font-family: &quot;Times New Roman&quot;;\">&nbsp;pada halaman&nbsp;</span><span style=\"font-weight: bold; font-family: &quot;Times New Roman&quot;;\">Pemesanan</span></li></ul><h5 style=\"margin-top: 0px; margin-bottom: 0.5rem; font-weight: 600; line-height: 1.2; font-size: 1.16875rem; color: rgb(73, 80, 87); font-family: &quot;Baloo Paaji 2&quot;, cursive;\"><span style=\"font-family: &quot;Times New Roman&quot;;\">2. Bagaimana jika Pesanan Gagal?</span></h5><ul style=\"color: rgb(116, 122, 128); font-family: &quot;Baloo Paaji 2&quot;, cursive; font-size: 14.96px;\"><li><span style=\"font-family: &quot;Times New Roman&quot;;\">Saldo Anda akan&nbsp;</span><span style=\"font-weight: bold; font-family: &quot;Times New Roman&quot;;\">Otomatis&nbsp;</span><span style=\"font-family: &quot;Times New Roman&quot;;\">dikembalikan maksimal dalam 1x24 jam, sesuai dengan jumlah nominal pesanan Anda.</span></li><li><span style=\"font-family: &quot;Times New Roman&quot;;\">Jika tidak? Silahkan untuk mengirim laporan melalui menu&nbsp;</span><span style=\"font-weight: bold; font-family: &quot;Times New Roman&quot;;\">Tiket&nbsp;</span><span style=\"font-family: &quot;Times New Roman&quot;;\">yang sudah kami sediakan.</span></li></ul> ');

-- --------------------------------------------------------

--
-- Table structure for table `pgen`
--

CREATE TABLE `pgen` (
  `id` int(11) NOT NULL,
  `name` varchar(9999) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `keygen` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pgen`
--

INSERT INTO `pgen` (`id`, `name`, `maintenance`, `keygen`) VALUES
(1, 'XYOURZONE', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pricelist`
--

CREATE TABLE `pricelist` (
  `id` int(11) NOT NULL,
  `game` varchar(255) NOT NULL,
  `durasi` varchar(255) NOT NULL,
  `harga` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Safe',
  `p_status` int(11) NOT NULL,
  `diskon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(11) NOT NULL,
  `name` varchar(9999) NOT NULL,
  `game1` varchar(255) NOT NULL,
  `game2` varchar(255) NOT NULL,
  `game3` varchar(255) NOT NULL,
  `dana` varchar(255) NOT NULL COMMENT 'Nomor Dana',
  `gopay` varchar(255) NOT NULL COMMENT 'Nomor Gopay',
  `ovo` varchar(9999) NOT NULL COMMENT 'Nomor Ovo',
  `url_yt` varchar(9999) NOT NULL,
  `url_tele` varchar(9999) NOT NULL,
  `url_ig` varchar(9999) NOT NULL,
  `token_key` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `name`, `game1`, `game2`, `game3`, `dana`, `gopay`, `ovo`, `url_yt`, `url_tele`, `url_ig`, `token_key`) VALUES
(1, 'Themaphack mod like no others', 'MLBB V1', 'MLBB V2', 'MLBB V3', '08561145687', '08561145687', '08561145687', 'https://www.youtube.com/channel/UCSsv-fhW7n-jOFeEtgu6zOA', 'https://t.me/themaphack', 'https://www.instagram.com/', 'D5-ADMIN-KJZW3');

-- --------------------------------------------------------

--
-- Table structure for table `provider`
--

CREATE TABLE `provider` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `api_url_services` text NOT NULL,
  `api_url_order` text NOT NULL,
  `api_url_status` text NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `api_id` varchar(255) NOT NULL,
  `profit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `provider`
--

INSERT INTO `provider` (`id`, `name`, `api_url_services`, `api_url_order`, `api_url_status`, `api_key`, `api_id`, `profit`) VALUES
(1, 'XYOURZONE', 'https://syhdnmodderz.my.id/GuiApi/panel/v2/P/api/json.php', 'https://t0pgamemurah.xyz/app/api/json.php', 'https://t0pgamemurah.xyz/app/api/json.php', 'Rrdb1Kt1UWqK5t1pOCnQ5sVidqNDF0', '8901', '1');

-- --------------------------------------------------------

--
-- Table structure for table `register_logs`
--

CREATE TABLE `register_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `register_logs`
--

INSERT INTO `register_logs` (`id`, `user_id`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 9, '180.242.213.126', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36', '2023-12-07 07:50:47'),
(2, 10, '180.244.139.98', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36', '2023-12-09 07:20:20'),
(3, 11, '180.242.131.134, 172.71.219.85', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', '2023-12-09 19:13:10'),
(4, 12, '37.79.35.240, 162.158.86.211', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0', '2023-12-12 21:45:25'),
(5, 13, '103.152.232.156, 162.158.106.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 OPR/104.0.0.0', '2023-12-14 00:57:25'),
(6, 14, '180.244.155.84, 162.158.162.170', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', '2023-12-30 23:09:17'),
(7, 15, '103.108.32.112, 172.70.143.11', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', '2024-01-04 10:42:27'),
(8, 16, '103.172.197.143', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', '2024-01-16 16:07:37'),
(9, 17, '103.147.82.243', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 OPR/106.0.0.0', '2024-02-22 12:38:20'),
(10, 19, '103.136.57.132', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', '2024-05-21 12:30:46'),
(11, 20, '112.215.238.192', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36', '2024-05-26 15:40:06'),
(12, 22, '202.67.46.247', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36', '2024-06-03 18:44:28'),
(13, 30, '103.3.221.27', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36', '2024-06-16 22:27:24'),
(14, 31, '103.125.43.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', '2024-06-18 00:36:03'),
(15, 33, '114.5.213.248, 162.158.163.114', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36', '2024-09-09 13:58:22'),
(16, 34, '103.147.82.243, 172.71.124.12', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 OPR/112.0.0.0', '2024-09-10 23:22:02'),
(17, 35, '103.147.82.243, 172.70.143.143', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 OPR/112.0.0.0', '2024-09-10 23:23:54'),
(18, 36, '103.147.82.243, 108.162.226.151', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 OPR/112.0.0.0', '2024-09-10 23:26:03'),
(19, 37, '114.5.109.77, 172.70.143.72', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36', '2024-09-13 11:42:08'),
(20, 38, '158.140.165.38, 172.69.166.41', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', '2024-09-23 14:22:24'),
(21, 39, '103.147.82.243, 162.158.29.42', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36', '2024-10-14 03:40:25'),
(22, 40, '103.136.57.216, 162.158.163.15', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36', '2024-10-14 13:47:47'),
(23, 42, '114.122.203.20, 172.70.143.44', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36', '2024-10-22 18:47:42'),
(24, 43, '103.120.170.19, 162.158.189.111', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36', '2024-10-22 19:28:28'),
(25, 55, '180.253.176.87, 172.69.134.46', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36', '2024-11-03 04:52:12'),
(26, 56, '2001:448a:10cd:2c38:14ac:b6d7:f0f4:223e, 162.158.106.149', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36', '2024-11-12 02:11:23'),
(27, 57, '2001:e68:5453:d84c:d59d:3604:b1bf:4c14, 172.71.152.81', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1', '2024-11-13 16:37:49'),
(28, 61, '103.183.8.242, 172.71.124.151', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2024-11-25 00:00:46'),
(29, 63, '103.52.146.163, 172.71.124.112', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36', '2024-12-18 21:22:48'),
(30, 65, '36.90.84.70, 162.158.90.98', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', '2024-12-24 13:17:03');

-- --------------------------------------------------------

--
-- Table structure for table `reqList`
--

CREATE TABLE `reqList` (
  `id` int(11) NOT NULL,
  `ip` varchar(9999) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restAPI`
--

CREATE TABLE `restAPI` (
  `id` int(11) NOT NULL,
  `game` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `static` varchar(9999) NOT NULL,
  `owner` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `restAPI`
--

INSERT INTO `restAPI` (`id`, `game`, `status`, `static`, `owner`) VALUES
(1, 'MLBB', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE'),
(2, 'MLBB Internal', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE'),
(3, 'FARLIGHT', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE'),
(4, 'MLBB HyperRoom', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE'),
(5, 'MLBB External', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE'),
(6, 'MLBB HyperRoom', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE'),
(8, 'CODM', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE'),
(9, 'AOV', 'Safe', 'Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E', 'XYOURZONE');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  `price` double NOT NULL,
  `profit` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `provider_id` int(11) NOT NULL,
  `provider_service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `category_id`, `service_name`, `note`, `min`, `max`, `price`, `profit`, `status`, `provider_id`, `provider_service_id`) VALUES
(25, 1, 'MLBB - Key 120 Days + 7 Days (Bonus)', 'This Key will be active for 24 hours / 120 Days + 7 Days (Bonus)\r\nOfficial Price 250.000 IDR', 1, 9999, 134999, 127, 1, 1, 1),
(26, 1, 'MLBB - Key 60 Days + 3 Days (Bonus)', 'This Key will be active for 24 hours / 60 Days + 3 Days (Bonus)\r\nOfficial Price 150.000 IDR', 1, 999, 84999, 63, 1, 1, 1),
(27, 1, 'MLBB - Key 30 Day', 'This Key will be active for 24 hours / 30 Day\r\nOfficial Price 90.000 IDR', 1, 999, 35000, 30, 1, 1, 1),
(28, 1, 'MLBB - Key 15 Day', 'This Key will be active for 24 hours / 15 Day\r\nOfficial Price 50.000 IDR', 1, 999, 20000, 15, 1, 1, 1),
(29, 1, 'MLBB - Key 7 Day', 'This Key will be active for 24 hours / 7 Days\r\nOfficial Price 35.000 IDR', 1, 999, 15000, 7, 1, 1, 1),
(30, 1, 'MLBB - Key 3 Day', 'This Key will be active for 24 hours / 3 Day\r\nOfficial Price: 20.000 IDR', 1, 999, 5000, 3, 1, 1, 1),
(31, 3, 'MLBB HyperRoom 15 Day', 'MLBB HyperRoom 15 Day', 1, 999, 20000, 15, 1, 1, 1),
(32, 3, 'MLBB HyperRoom 30 Day Zygisk Version', 'MLBB HyperRoom 30 Day Zygisk Version', 1, 999, 40000, 30, 1, 1, 3),
(34, 3, 'MLBB HyperRoom 60 Day', 'MLBB HyperRoom 60 Day', 1, 999, 80000, 60, 1, 1, 3),
(38, 3, '15 Days - HyperRoom', 'HyperRoom 15 Days.\r\nOfficial Price 20.000 IDR', 1, 999, 18000, 15, 1, 1, 5),
(39, 3, '30 Days - HyperRoom', 'HyperRoom 30 Day\r\nOfficial Price 40.000 IDR', 1, 999, 36000, 30, 1, 1, 5),
(40, 3, '60 Days - HyperRoom', 'HyperRoom 60 Day\r\nOfficial Price: 80.000 IDR', 1, 999, 75000, 60, 1, 1, 5),
(45, 4, '7 DAY - 20K IDR ($3)', '7 DAY - 20K IDR ($3)', 1, 1000, 19999, 7, 1, 1, 7),
(50, 1, 'MLBB - Key 1 Day', 'MLBB 1 DAYS\r\nORIGINAL PRICE: 10.000', 1, 5, 5000, 1, 1, 1, 1),
(51, 2, 'MLBB Injector - 7 Day', 'MLBB Injector - 7 Day\r\nOfficial Price: 45.000 IDR', 1, 1, 25000, 7, 1, 1, 2),
(52, 2, 'MLBB Injector - 30 Day', 'MLBB Injector - 30 Day\r\nOfficial Price: 100.000 IDR', 1, 1, 65000, 30, 1, 1, 2),
(53, 2, 'MLBB Injector - 60 Day', 'MLBB Injector - 60 Day\r\nOfficial Price: 180.000 IDR', 1, 1, 130000, 60, 1, 1, 2),
(54, 32, 'MLBB Private - Key 30 Day', 'Private MLBB Sebulan', 1, 10, 100000, 30, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `service_cat`
--

CREATE TABLE `service_cat` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sList`
--

CREATE TABLE `sList` (
  `id` int(11) NOT NULL,
  `access_key` varchar(9999) NOT NULL,
  `uuid` varchar(9999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `status` enum('Waiting','Responded','Closed') NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `user_id`, `subject`, `msg`, `status`, `created_at`, `updated_at`) VALUES
(4, 66, 'Tidak bisa input order', 'Tolong di cek ', 'Waiting', '2025-01-02 00:29:40', '2025-01-02 00:29:40'),
(5, 1, 'gak bisa rubah nameserver', 'sama seperti subjek', 'Waiting', '2025-02-02 08:19:04', '2025-02-02 08:19:04');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_replies`
--

CREATE TABLE `ticket_replies` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `is_admin` int(11) NOT NULL DEFAULT 0,
  `msg` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `id` int(11) NOT NULL,
  `ip` varchar(9999) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `data` varchar(255) NOT NULL,
  `access_key` varchar(255) NOT NULL,
  `cheat_name` varchar(255) NOT NULL,
  `cheat_text` varchar(255) NOT NULL,
  `cheat_exp` varchar(255) NOT NULL,
  `cheat_slot` int(11) NOT NULL,
  `slot` int(11) DEFAULT NULL,
  `device` varchar(9999) NOT NULL DEFAULT '0',
  `serial` varchar(9999) DEFAULT NULL,
  `Status` varchar(255) NOT NULL,
  `games` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0,
  `durasi` int(11) NOT NULL,
  `start` varchar(9999) NOT NULL,
  `vip` tinyint(1) NOT NULL DEFAULT 0,
  `isUse` int(11) DEFAULT 0,
  `sn` varchar(9999) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`id`, `ip`, `uid`, `data`, `access_key`, `cheat_name`, `cheat_text`, `cheat_exp`, `cheat_slot`, `slot`, `device`, `serial`, `Status`, `games`, `active`, `durasi`, `start`, `vip`, `isUse`, `sn`) VALUES
(12351, NULL, 1, 'baru', 'MLBB_3ONSPDTQZM', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-03-08 08:42:45', 1, 1, '0', NULL, 'Safe', 'MLBB', 0, 30, '2025-02-06 08:42:45', 100, 0, NULL),
(12356, NULL, 1, 'eudora', 'MLBB_IJWLQSNDRF', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-07-19 14:10:28', 5, 5, '0', '97f5a619-3b9e-383a-a02b-feecf47d18c4', 'Safe', 'MLBB', 1, 127, '2025-03-14 14:07:31', 100, 0, NULL),
(12357, NULL, 1, 'lukas', 'MLBB_ILLIQDGSNN', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-07-24 15:05:45', 10, 10, '0', 'aa69d7e3-44b4-3512-939d-eb5fb8b467aa', 'Safe', 'MLBB', 1, 127, '2025-03-19 14:40:41', 100, 0, NULL),
(12360, NULL, 1, '@ToracinnoBold', 'XYZ_ERZUDOGB73', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-07-30 14:29:27', 1, 1, '0', NULL, 'Safe', 'MLBB', 0, 127, '2025-03-25 14:29:27', 100, 0, NULL),
(12361, NULL, 1, 'ToracinnoBold', 'XYZ_TAT0UU4CAI', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-07-31 10:10:30', 1, 1, '0', NULL, 'Safe', 'MLBB', 0, 127, '2025-03-26 10:10:30', 100, 0, NULL),
(12363, NULL, 1, 'julian', 'MLBB_R40HZYIYMM', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-08-28 09:25:13', 100, 100, '0', '11514ec7-999f-3daf-9202-e999511573b5', 'Safe', 'MLBB', 1, 127, '2025-04-23 09:23:24', 100, 0, NULL),
(12364, NULL, 1, 'millo', 'MLBB_X6RUCOYD1Y', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-09-07 14:18:55', 100, 100, '0', 'acec2894-d535-3239-a546-2811be9ae3ba', 'Safe', 'MLBB', 1, 127, '2025-05-03 14:18:29', 100, 0, NULL),
(12365, NULL, 1, 'LAYLA', 'MLBB_AXGYZ3XXLX', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-09-15 19:23:58', 100, 100, '0', '2ea69871-4d44-36a1-a4e4-d203f4c3a9e5', 'Safe', 'MLBB', 1, 127, '2025-05-11 19:21:52', 100, 0, NULL),
(12366, '120.188.35.77', 1, 'FREE-EFNU9CHC', 'G5T1Z40Y-XYOURZONE-EFNU9CHC', '', 'Bypass Runing 24 Hours', '2025-05-24 17:28:46', 1, 1, '0', '297f0ad5-3f51-30a8-b2b4-c4fa58dd1bbc', 'Safe', 'MLBB', 1, 1, '2025-05-23 18:28:46', 20, 1, '2025-05-24 18:28:45'),
(12367, '114.4.213.28', 1, 'FREE-QRYGSH4C', 'XDL0DQGE-XYOURZONE-QRYGSH4C', '', 'Bypass Runing 24 Hours', '2025-05-26 12:45:41', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-25 13:45:41', 20, 1, '2025-05-26 13:45:41'),
(12368, '160.22.206.49', 1, 'FREE-Y4PWAHGY', 'HOYROZHL-XYOURZONE-Y4PWAHGY', '', 'Bypass Runing 24 Hours', '2025-05-26 14:35:45', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-25 15:35:45', 20, 1, '2025-05-26 15:35:45'),
(12370, '120.188.67.71', 1, 'FREE-FL2GUPAA', '7RFYDMWN-THMPHCK-FL2GUPAA', '', 'Bypass Runing 24 Hours', '2025-05-27 17:23:48', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-26 18:23:48', 20, 1, '2025-05-27 18:23:48'),
(12371, '140.213.185.2', 1, 'FREE-I90REBLQ', 'WE4MBI5Y-THMPHCK-I90REBLQ', '', 'Bypass Runing 24 Hours', '2025-05-28 17:06:22', 1, 1, '0', '162eeab0-8375-3793-a8cd-f0a7f98ea8f4', 'Safe', 'MLBB', 1, 1, '2025-05-27 18:06:22', 20, 1, '2025-05-28 18:06:22'),
(12372, '140.213.185.198', 1, 'FREE-NMUO7EML', 'EWSLOL71-THMPHCK-NMUO7EML', '', 'Bypass Runing 24 Hours', '2025-05-28 17:14:52', 1, 1, '0', '999ebfa8-b70d-3d71-9078-741e4244022b', 'Safe', 'MLBB', 1, 1, '2025-05-27 18:14:52', 20, 1, '2025-05-28 18:14:52'),
(12373, '90.134.5.236', 1, 'FREE-0QJGMX9E', 'MDW238XM-THMPHCK-0QJGMX9E', '', 'Bypass Runing 24 Hours', '2025-05-30 02:16:57', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-29 03:16:57', 20, 1, '2025-05-30 03:16:57'),
(12374, '112.215.238.35', 1, 'FREE-LNL9FGPS', '0AAPTSO3-THMPHCK-LNL9FGPS', '', 'Bypass Runing 24 Hours', '2025-05-30 08:05:27', 1, 1, '0', '6e1c449d-e19b-33ec-940d-ff67df9607fd', 'Safe', 'MLBB', 1, 1, '2025-05-29 09:05:27', 20, 1, '2025-05-30 09:05:27'),
(12375, '125.166.179.25', 1, 'FREE-JFK2ZIJY', 'KDPAGMMA-THMPHCK-JFK2ZIJY', '', 'Bypass Runing 24 Hours', '2025-05-30 14:12:54', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-29 15:12:54', 20, 1, '2025-05-30 15:12:54'),
(12376, '158.62.9.189', 1, 'FREE-FPAEFGFK', 'CJPMPD1S-THMPHCK-FPAEFGFK', '', 'Bypass Runing 24 Hours', '2025-05-31 13:01:15', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-30 14:01:15', 20, 1, '2025-05-31 14:01:15'),
(12377, '160.25.94.242', 1, 'FREE-6EPXDNB8', 'JYW9ZTLL-THMPHCK-6EPXDNB8', '', 'Bypass Runing 24 Hours', '2025-05-31 20:10:47', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-30 21:10:47', 20, 1, '2025-05-31 21:10:47'),
(12378, '114.10.153.159', 1, 'FREE-FGLOUQ5P', '6GHOGNAX-THMPHCK-FGLOUQ5P', '', 'Bypass Runing 24 Hours', '2025-06-01 00:38:47', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-05-31 01:38:47', 20, 1, '2025-06-01 01:38:47'),
(12379, '112.215.45.205', 1, 'FREE-UOOGLB0H', 'PC1ZHGYD-THMPHCK-UOOGLB0H', '', 'Bypass Runing 24 Hours', '2025-06-01 12:45:36', 1, 1, '0', 'abf122f4-bb70-3d51-bb1f-998552448298', 'Safe', 'MLBB', 1, 1, '2025-05-31 13:45:36', 20, 1, '2025-06-01 13:45:36'),
(12380, '114.10.152.106', 1, 'FREE-YUZFLXEJ', 'ZJCIG2TM-THMPHCK-YUZFLXEJ', '', 'Bypass Runing 24 Hours', '2025-06-02 00:47:24', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-01 01:47:24', 20, 1, '2025-06-02 01:47:24'),
(12381, '140.213.169.145', 1, 'FREE-PK5GXWII', 'JOR77GFW-THMPHCK-PK5GXWII', '', 'Bypass Runing 24 Hours', '2025-06-02 11:22:14', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-01 12:22:14', 20, 1, '2025-06-02 12:22:14'),
(12382, '140.213.169.145', 1, 'FREE-PK5GXWII', 'UZW8REF4-THMPHCK-PK5GXWII', '', 'Bypass Runing 24 Hours', '2025-06-02 11:22:20', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-01 12:22:20', 20, 1, '2025-06-02 12:22:20'),
(12383, '140.213.161.201', 1, 'FREE-NZTO0UEB', 'OJIABAAG-THMPHCK-NZTO0UEB', '', 'Bypass Runing 24 Hours', '2025-06-02 11:24:55', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-01 12:24:55', 20, 1, '2025-06-02 12:24:55'),
(12384, '182.1.230.204', 1, 'FREE-CGH3RSC6', 'SWDE1JGW-THMPHCK-CGH3RSC6', '', 'Bypass Runing 24 Hours', '2025-06-02 21:09:00', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-01 22:09:00', 20, 1, '2025-06-02 22:09:00'),
(12385, '176.64.17.49', 1, 'FREE-MHW9GR0O', 'AR0BSK6M-THMPHCK-MHW9GR0O', '', 'Bypass Runing 24 Hours', '2025-06-02 22:58:01', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-01 23:58:01', 20, 1, '2025-06-02 23:58:01'),
(12386, '114.10.152.98', 1, 'FREE-IE332WB3', 'JB1FLKJP-THMPHCK-IE332WB3', '', 'Bypass Runing 24 Hours', '2025-06-02 23:36:25', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-02 00:36:25', 20, 1, '2025-06-03 00:36:25'),
(12387, '114.10.152.14', 1, 'FREE-2E511MQU', 'TUHAIN2N-THMPHCK-2E511MQU', '', 'Bypass Runing 24 Hours', '2025-06-03 07:13:49', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-02 08:13:49', 20, 1, '2025-06-03 08:13:49'),
(12388, '114.10.30.137', 1, 'FREE-TDUTSGSK', 'CCTQ3KTF-THMPHCK-TDUTSGSK', '', 'Bypass Runing 24 Hours', '2025-06-03 12:00:25', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-02 13:00:25', 20, 1, '2025-06-03 13:00:25'),
(12389, '77.222.156.55', 1, 'FREE-CLTJFGTN', 'ZWMJUQYD-THMPHCK-CLTJFGTN', '', 'Bypass Runing 24 Hours', '2025-06-03 13:39:25', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-02 14:39:25', 20, 1, '2025-06-03 14:39:25'),
(12390, '88.154.1.72', 1, 'FREE-SIGYX8SQ', 'DMUXHM6U-THMPHCK-SIGYX8SQ', '', 'Bypass Runing 24 Hours', '2025-06-03 14:08:00', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-02 15:08:00', 20, 1, '2025-06-03 15:08:00'),
(12391, '77.111.246.40', 1, 'FREE-W3QFITWG', 'HUWYALZY-THMPHCK-W3QFITWG', '', 'Bypass Runing 24 Hours', '2025-06-03 17:04:30', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-02 18:04:30', 20, 1, '2025-06-03 18:04:30'),
(12392, '182.253.57.133', 1, 'FREE-YKAXHIE4', '46NMFZB9-THMPHCK-YKAXHIE4', '', 'Bypass Runing 24 Hours', '2025-06-04 06:28:25', 1, 1, '0', '96195983-e9b4-37ad-a9a3-32188a84b45f', 'Safe', 'MLBB', 1, 1, '2025-06-03 07:28:25', 20, 1, '2025-06-04 07:28:25'),
(12393, '43.245.86.40', 1, 'FREE-CBSENYRS', 'OC35WPL9-THMPHCK-CBSENYRS', '', 'Bypass Runing 24 Hours', '2025-06-04 14:06:22', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-03 15:06:22', 20, 1, '2025-06-04 15:06:22'),
(12394, '136.158.10.27', 1, 'FREE-GBF0T81Y', 'BEWZPQEX-THMPHCK-GBF0T81Y', '', 'Bypass Runing 24 Hours', '2025-06-04 15:18:34', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-03 16:18:34', 20, 1, '2025-06-04 16:18:34'),
(12395, '103.151.92.15', 1, 'FREE-JJJOLOKC', 'ZXB8P7PH-THMPHCK-JJJOLOKC', '', 'Bypass Runing 24 Hours', '2025-06-04 15:32:12', 1, 1, '0', 'c8f98f6d-677e-3025-afa9-52649155a376', 'Safe', 'MLBB', 1, 1, '2025-06-03 16:32:12', 20, 1, '2025-06-04 16:32:12'),
(12397, '77.111.247.7', 1, 'FREE-0JAJ81X4', 'O5WOZNRP-THMPHCK-0JAJ81X4', '', 'Bypass Runing 24 Hours', '2025-06-05 06:14:23', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-04 07:14:23', 20, 1, '2025-06-05 07:14:23'),
(12398, '103.155.232.225', 1, 'FREE-Z78A7YNU', 'OHZMH27A-THMPHCK-Z78A7YNU', '', 'Bypass Runing 24 Hours', '2025-06-05 21:18:56', 1, 1, '0', '41d40c3a-523a-33c2-92c4-07c824e3a87c', 'Safe', 'MLBB', 1, 1, '2025-06-04 22:18:56', 20, 1, '2025-06-05 22:18:56'),
(12399, '182.178.97.98', 1, 'FREE-I4U6ILNP', 'S3EPUSMS-THMPHCK-I4U6ILNP', '', 'Bypass Runing 24 Hours', '2025-06-05 21:32:44', 1, 1, '0', '982a3a5b-72f8-3c24-afdc-70e01f4f4289', 'Safe', 'MLBB', 1, 1, '2025-06-04 22:32:44', 20, 1, '2025-06-05 22:32:44'),
(12400, '219.100.37.233', 1, 'FREE-U4N42J3Z', 'RXFYL3BE-THMPHCK-U4N42J3Z', '', 'Bypass Runing 24 Hours', '2025-06-05 22:12:48', 1, 1, '0', '28ea3aa6-beb0-3298-bc62-6b2cbd2adbf7', 'Safe', 'MLBB', 1, 1, '2025-06-04 23:12:48', 20, 1, '2025-06-05 23:12:48'),
(12401, '92.115.70.112', 1, 'FREE-OMKMP5HG', 'KYME5OTI-THMPHCK-OMKMP5HG', '', 'Bypass Runing 24 Hours', '2025-06-06 15:39:05', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-05 16:39:05', 20, 1, '2025-06-06 16:39:05'),
(12402, '27.125.242.98', 1, 'FREE-SUXNCUIR', 'QW16PTWO-THMPHCK-SUXNCUIR', '', 'Bypass Runing 24 Hours', '2025-06-06 20:50:15', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-05 21:50:15', 20, 1, '2025-06-06 21:50:15'),
(12403, '203.189.186.241', 1, 'FREE-RJPYQB4N', 'WTW0RFSF-THMPHCK-RJPYQB4N', '', 'Bypass Runing 24 Hours', '2025-06-07 08:45:51', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-06 09:45:51', 20, 1, '2025-06-07 09:45:51'),
(12404, '182.178.97.98', 1, 'FREE-KGMKT0AJ', 'ZJ9ZQ61H-THMPHCK-KGMKT0AJ', '', 'Bypass Runing 24 Hours', '2025-06-07 19:05:45', 1, 1, '0', '7542ffbf-3bfb-37c6-9156-97e46ae022c6', 'Safe', 'MLBB', 1, 1, '2025-06-06 20:05:45', 20, 1, '2025-06-07 20:05:45'),
(12405, '93.159.49.145', 1, 'FREE-XWSHGKHH', '6XIWJWEL-THMPHCK-XWSHGKHH', '', 'Bypass Runing 24 Hours', '2025-06-07 23:34:16', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-07 00:34:16', 20, 1, '2025-06-08 00:34:16'),
(12407, '36.75.2.138', 1, 'FREE-BUDBPUJ6', 'UISIUJLT-THMPHCK-BUDBPUJ6', '', 'Bypass Runing 24 Hours', '2025-06-08 00:02:14', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-07 01:02:14', 20, 1, '2025-06-08 01:02:14'),
(12408, '116.97.107.196', 1, 'FREE-TTT1KO11', 'HWJXERWL-THMPHCK-TTT1KO11', '', 'Bypass Runing 24 Hours', '2025-06-08 11:18:42', 1, 1, '0', '2ed60137-4d3a-3e7d-bee4-1ad3b0e3ffda', 'Safe', 'MLBB', 1, 1, '2025-06-07 12:18:42', 20, 1, '2025-06-08 12:18:42'),
(12409, '182.253.57.133', 1, 'FREE-4YBCJE8R', 'SBIKEC2K-THMPHCK-4YBCJE8R', '', 'Bypass Runing 24 Hours', '2025-06-08 12:02:51', 1, 1, '0', '5a2faded-98d1-3813-90a3-59610ed93e4d', 'Safe', 'MLBB', 1, 1, '2025-06-07 13:02:51', 20, 1, '2025-06-08 13:02:51'),
(12410, '116.97.107.174', 1, 'FREE-0BKJHGBP', 'OYZMCK3E-THMPHCK-0BKJHGBP', '', 'Bypass Runing 24 Hours', '2025-06-08 19:28:01', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-07 20:28:01', 20, 1, '2025-06-08 20:28:01'),
(12411, '212.192.245.188', 1, 'FREE-FEXOTN08', 'XKNR9DKH-THMPHCK-FEXOTN08', '', 'Bypass Runing 24 Hours', '2025-06-08 20:19:26', 1, 1, '0', 'f38a87d8-70da-3f4f-8509-a7619cfe3d43', 'Safe', 'MLBB', 1, 1, '2025-06-07 21:19:26', 20, 1, '2025-06-08 21:19:26'),
(12412, '171.241.164.17', 1, 'FREE-LFRYKIAL', 'NJYULM9T-THMPHCK-LFRYKIAL', '', 'Bypass Runing 24 Hours', '2025-06-08 21:38:56', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-07 22:38:56', 20, 1, '2025-06-08 22:38:56'),
(12413, '185.41.120.40', 1, 'FREE-OJIBUE5H', 'NYO1QAQA-THMPHCK-OJIBUE5H', '', 'Bypass Runing 24 Hours', '2025-06-09 01:44:34', 1, 1, '0', 'd0f0726b-4568-3660-9882-841d4464aa68', 'Safe', 'MLBB', 1, 1, '2025-06-08 02:44:34', 20, 1, '2025-06-09 02:44:34'),
(12414, '59.146.107.194', 1, 'FREE-LM0SXK6L', 'ONGY5Y9D-THMPHCK-LM0SXK6L', '', 'Bypass Runing 24 Hours', '2025-06-09 12:55:11', 1, 1, '0', '31894997-7ce9-32ea-9cec-ac6da8d480d0', 'Safe', 'MLBB', 1, 1, '2025-06-08 13:55:11', 20, 1, '2025-06-09 13:55:11'),
(12415, '46.32.187.42', 1, 'FREE-TUPAGZKM', 'PFBDPMMD-THMPHCK-TUPAGZKM', '', 'Bypass Runing 24 Hours', '2025-06-09 16:22:52', 1, 1, '0', '1b29044b-e36e-323b-8890-b125ec17ee4c', 'Safe', 'MLBB', 1, 1, '2025-06-08 17:22:52', 20, 1, '2025-06-09 17:22:52'),
(12416, '113.185.43.53', 1, 'FREE-MPHNIEIL', '96RA8B6K-THMPHCK-MPHNIEIL', '', 'Bypass Runing 24 Hours', '2025-06-09 18:30:14', 1, 1, '0', 'a8b07e00-e37e-38cd-bfcc-491e85a8e794', 'Safe', 'MLBB', 1, 1, '2025-06-08 19:30:14', 20, 1, '2025-06-09 19:30:14'),
(12417, '113.185.42.14', 1, 'FREE-IN13OLGG', 'PMNAGNAN-THMPHCK-IN13OLGG', '', 'Bypass Runing 24 Hours', '2025-06-09 22:12:08', 1, 1, '0', 'c89b5d0e-455f-397d-949a-ae135bceab17', 'Safe', 'MLBB', 1, 1, '2025-06-08 23:12:08', 20, 1, '2025-06-09 23:12:08'),
(12418, '182.1.209.152', 1, 'FREE-QB0NYT8U', '9DCFSQSR-THMPHCK-QB0NYT8U', '', 'Bypass Runing 24 Hours', '2025-06-10 15:20:47', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-09 16:20:47', 20, 1, '2025-06-10 16:20:47'),
(12419, '116.97.107.173', 1, 'FREE-TI8BYNRM', 'N55IXC9Q-THMPHCK-TI8BYNRM', '', 'Bypass Runing 24 Hours', '2025-06-11 11:14:07', 1, 1, '0', '6428580f-a3f4-379d-bcc4-55e443f71cf0', 'Safe', 'MLBB', 1, 1, '2025-06-10 12:14:07', 20, 1, '2025-06-11 12:14:07'),
(12420, '113.185.44.173', 1, 'FREE-HBLXQ6LK', 'WLRYAAUZ-THMPHCK-HBLXQ6LK', '', 'Bypass Runing 24 Hours', '2025-06-11 14:26:34', 1, 1, '0', 'de812cd6-1f17-32f0-b61e-8fbd15761120', 'Safe', 'MLBB', 1, 1, '2025-06-10 15:26:34', 20, 1, '2025-06-11 15:26:34'),
(12421, '110.227.183.247', 1, 'FREE-WBTYXXBM', '9K91D4R1-THMPHCK-WBTYXXBM', '', 'Bypass Runing 24 Hours', '2025-06-12 07:27:43', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-11 08:27:43', 20, 1, '2025-06-12 08:27:43'),
(12422, '206.85.1.107', 1, 'FREE-ZJ76IASF', 'XQAX1O1P-THMPHCK-ZJ76IASF', '', 'Bypass Runing 24 Hours', '2025-06-12 08:50:35', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-11 09:50:35', 20, 1, '2025-06-12 09:50:35'),
(12423, '116.97.106.140', 1, 'FREE-4WXQ3FSC', 'MWMMBEFH-THMPHCK-4WXQ3FSC', '', 'Bypass Runing 24 Hours', '2025-06-12 08:59:27', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-11 09:59:27', 20, 1, '2025-06-12 09:59:27'),
(12424, '114.79.1.150', 1, 'FREE-YL3GJG5K', 'ALYDYAZ1-THMPHCK-YL3GJG5K', '', 'Bypass Runing 24 Hours', '2025-06-12 09:33:26', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-11 10:33:26', 20, 1, '2025-06-12 10:33:26'),
(12425, '180.75.247.172', 1, 'FREE-9XCWSCTJ', 'XO8JGDP5-THMPHCK-9XCWSCTJ', '', 'Bypass Runing 24 Hours', '2025-06-12 12:02:37', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-11 13:02:37', 20, 1, '2025-06-12 13:02:37'),
(12426, '175.143.56.131', 1, 'FREE-3L9PYHUK', 'DLOROAM5-THMPHCK-3L9PYHUK', '', 'Bypass Runing 24 Hours', '2025-06-12 13:11:21', 1, 1, '0', '3db183a6-d1e0-32ec-9a73-1657832e7274', 'Safe', 'MLBB', 1, 1, '2025-06-11 14:11:21', 20, 1, '2025-06-12 14:11:21'),
(12427, '193.104.75.35', 1, 'FREE-O76PKXYI', '1B3CRKJR-THMPHCK-O76PKXYI', '', 'Bypass Runing 24 Hours', '2025-06-12 14:29:03', 1, 1, '0', '48a046c8-6bd9-329f-a98c-21ed8aac36bf', 'Safe', 'MLBB', 1, 1, '2025-06-11 15:29:03', 20, 1, '2025-06-12 15:29:03'),
(12428, '180.190.41.138', 1, 'FREE-JH2XURHJ', 'NXEOEGYU-THMPHCK-JH2XURHJ', '', 'Bypass Runing 24 Hours', '2025-06-12 16:13:56', 1, 1, '0', '230bff5c-db7a-35af-bb6c-96b36dd3c2c0', 'Safe', 'MLBB', 1, 1, '2025-06-11 17:13:56', 20, 1, '2025-06-12 17:13:56'),
(12429, '180.253.187.217', 1, 'FREE-KBRXITM6', 'LSRSOMNR-THMPHCK-KBRXITM6', '', 'Bypass Runing 24 Hours', '2025-06-12 21:33:29', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-11 22:33:29', 20, 1, '2025-06-12 22:33:29'),
(12430, '116.97.107.118', 1, 'FREE-9G2WYQSO', 'JMT8NXKH-THMPHCK-9G2WYQSO', '', 'Bypass Runing 24 Hours', '2025-06-13 07:49:07', 1, 1, '0', '176f8571-8efc-3d38-85de-8b209c18f1cf', 'Safe', 'MLBB', 1, 1, '2025-06-12 08:49:07', 20, 1, '2025-06-13 08:49:07'),
(12431, '114.10.31.124', 1, 'FREE-RTLUHIMY', 'LH5HYNTK-THMPHCK-RTLUHIMY', '', 'Bypass Runing 24 Hours', '2025-06-13 08:48:31', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-12 09:48:31', 20, 1, '2025-06-13 09:48:31'),
(12432, '88.204.52.108', 1, 'FREE-APGDLSEA', 'UJI9A6MI-THMPHCK-APGDLSEA', '', 'Bypass Runing 24 Hours', '2025-06-13 21:27:31', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-12 22:27:31', 20, 1, '2025-06-13 22:27:31'),
(12433, '79.105.221.30', 1, 'FREE-WUBDW8UZ', '6RPTNDCH-THMPHCK-WUBDW8UZ', '', 'Bypass Runing 24 Hours', '2025-06-14 10:13:05', 1, 1, '0', 'f3e8a445-97d8-3323-8ce5-9daab4c29611', 'Safe', 'MLBB', 1, 1, '2025-06-13 11:13:05', 20, 1, '2025-06-14 11:13:05'),
(12434, '49.37.100.188', 1, 'FREE-YMKNJG6G', 'HDUTREIN-THMPHCK-YMKNJG6G', '', 'Bypass Runing 24 Hours', '2025-06-14 10:14:42', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-13 11:14:42', 20, 1, '2025-06-14 11:14:42'),
(12435, '79.105.37.254', 1, 'FREE-ACQY4X7D', 'O4BGZFL6-THMPHCK-ACQY4X7D', '', 'Bypass Runing 24 Hours', '2025-06-14 12:04:40', 1, 1, '0', '105fe57c-91d1-30db-ad4d-f8ba6f3a4bf6', 'Safe', 'MLBB', 1, 1, '2025-06-13 13:04:40', 20, 1, '2025-06-14 13:04:40'),
(12436, '180.75.247.172', 1, 'FREE-UICGOI58', 'OEGLBO9C-THMPHCK-UICGOI58', '', 'Bypass Runing 24 Hours', '2025-06-14 19:13:25', 1, 1, '0', '7fa5176c-305c-38c6-8fe9-787626589d53', 'Safe', 'MLBB', 1, 1, '2025-06-13 20:13:25', 20, 1, '2025-06-14 20:13:25'),
(12437, '112.215.174.107', 1, 'FREE-JCBLCLEF', 'XJQKFC7U-THMPHCK-JCBLCLEF', '', 'Bypass Runing 24 Hours', '2025-06-14 19:55:04', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-13 20:55:04', 20, 1, '2025-06-14 20:55:04'),
(12438, '176.62.76.5', 1, 'FREE-IFIIPBM8', 'KKLJ44LK-THMPHCK-IFIIPBM8', '', 'Bypass Runing 24 Hours', '2025-06-15 19:00:05', 1, 1, '0', '13d677af-feaa-3f9d-a911-644d1916a393', 'Safe', 'MLBB', 1, 1, '2025-06-14 20:00:05', 20, 1, '2025-06-15 20:00:05'),
(12439, '5.90.7.115', 1, 'FREE-HMJJKDJW', '2ZCMRRA4-THMPHCK-HMJJKDJW', '', 'Bypass Runing 24 Hours', '2025-06-16 07:50:05', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-15 08:50:05', 20, 1, '2025-06-16 08:50:05'),
(12440, '5.90.13.95', 1, 'FREE-G8LIGTUG', 'ONWSKT2Z-THMPHCK-G8LIGTUG', '', 'Bypass Runing 24 Hours', '2025-06-16 07:59:10', 1, 1, '0', 'e1d649c6-d15d-39e7-a927-17c0268e9fc4', 'Safe', 'MLBB', 1, 1, '2025-06-15 08:59:10', 20, 1, '2025-06-16 08:59:10'),
(12441, '176.62.76.3', 1, 'FREE-7SLD124I', 'FY32F0HR-THMPHCK-7SLD124I', '', 'Bypass Runing 24 Hours', '2025-06-16 11:19:16', 1, 1, '0', '9269cd33-02db-3b20-ae95-816ead70066d', 'Safe', 'MLBB', 1, 1, '2025-06-15 12:19:16', 20, 1, '2025-06-16 12:19:16'),
(12442, '36.69.230.99', 1, 'FREE-TXWZ1GPK', 'A6W3HYUN-THMPHCK-TXWZ1GPK', '', 'Bypass Runing 24 Hours', '2025-06-16 17:55:03', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-15 18:55:03', 20, 1, '2025-06-16 18:55:03'),
(12443, '146.190.97.85', 1, 'FREE-RSCOPRAN', 'HY8QPSGZ-THMPHCK-RSCOPRAN', '', 'Bypass Runing 24 Hours', '2025-06-16 18:58:59', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-15 19:58:59', 20, 1, '2025-06-16 19:58:59'),
(12444, '114.10.66.135', 1, 'FREE-SJWZATH5', 'CQ3LBLAH-THMPHCK-SJWZATH5', '', 'Bypass Runing 24 Hours', '2025-06-16 19:46:48', 1, 1, '0', '89c115a3-c070-31d6-9986-828b3f7c4e16', 'Safe', 'MLBB', 1, 1, '2025-06-15 20:46:48', 20, 1, '2025-06-16 20:46:48'),
(12445, '136.158.58.194', 1, 'FREE-PABLFMIR', 'EFSSBQYG-THMPHCK-PABLFMIR', '', 'Bypass Runing 24 Hours', '2025-06-16 21:04:12', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-15 22:04:12', 20, 1, '2025-06-16 22:04:12'),
(12446, '112.200.225.84', 1, 'FREE-RHKT7HIB', 'EJKNNAAK-THMPHCK-RHKT7HIB', '', 'Bypass Runing 24 Hours', '2025-06-16 23:06:25', 1, 1, '0', '6b8429e2-4544-3e12-b1db-04f585fab35f', 'Safe', 'MLBB', 1, 1, '2025-06-16 00:06:25', 20, 1, '2025-06-17 00:06:25'),
(12447, '175.158.36.154', 1, 'FREE-3BSPNXF9', 'JOHN3EDR-THMPHCK-3BSPNXF9', '', 'Bypass Runing 24 Hours', '2025-06-17 01:17:14', 1, 1, '0', '91631eb9-bc19-382a-876e-bad7979b4675', 'Safe', 'MLBB', 1, 1, '2025-06-16 02:17:14', 20, 1, '2025-06-17 02:17:14'),
(12448, '140.213.244.152', 1, 'FREE-ZNNTZJCJ', 'OQWX8G4S-THMPHCK-ZNNTZJCJ', '', 'Bypass Runing 24 Hours', '2025-06-17 03:17:01', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-16 04:17:01', 20, 1, '2025-06-17 04:17:01'),
(12449, '103.190.41.31', 1, 'FREE-CNMBWPBT', 'T9MFQG7I-THMPHCK-CNMBWPBT', '', 'Bypass Runing 24 Hours', '2025-06-17 18:12:30', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-16 19:12:30', 20, 1, '2025-06-17 19:12:30'),
(12450, '125.164.126.162', 1, 'FREE-K9QCMI73', 'AT17BSQY-THMPHCK-K9QCMI73', '', 'Bypass Runing 24 Hours', '2025-06-17 21:33:40', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-16 22:33:40', 20, 1, '2025-06-17 22:33:40'),
(12451, '177.244.106.18', 1, 'FREE-PX2HF0JZ', '410UUTXD-THMPHCK-PX2HF0JZ', '', 'Bypass Runing 24 Hours', '2025-06-18 01:48:27', 1, 1, '0', 'bdfb4d60-0474-3600-832a-d4c27f4d9f3a', 'Safe', 'MLBB', 1, 1, '2025-06-17 02:48:27', 20, 1, '2025-06-18 02:48:27'),
(12452, '169.224.105.230', 1, 'FREE-0RXAFWHI', 'KQYGHP2A-THMPHCK-0RXAFWHI', '', 'Bypass Runing 24 Hours', '2025-06-18 04:31:25', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-17 05:31:25', 20, 1, '2025-06-18 05:31:25'),
(12453, '49.145.238.164', 1, 'FREE-BXSAS4UC', 'SCWWLCN8-THMPHCK-BXSAS4UC', '', 'Bypass Runing 24 Hours', '2025-06-18 14:14:34', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-17 15:14:34', 20, 1, '2025-06-18 15:14:34'),
(12455, '114.122.38.38', 1, 'FREE-OTJCX5QJ', 'HXPD7APN-THMPHCK-OTJCX5QJ', '', 'Bypass Runing 24 Hours', '2025-06-19 20:00:38', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-18 21:00:38', 20, 1, '2025-06-19 21:00:38'),
(12456, '140.213.147.84', 1, 'FREE-QX1NNNCD', 'MPA8KSQQ-THMPHCK-QX1NNNCD', '', 'Bypass Runing 24 Hours', '2025-06-19 20:31:58', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-18 21:31:58', 20, 1, '2025-06-19 21:31:58'),
(12457, '128.1.190.8', 1, 'FREE-FWU2WZFD', '3FTMSDTY-THMPHCK-FWU2WZFD', '', 'Bypass Runing 24 Hours', '2025-06-19 23:50:05', 1, 1, '0', '2539347d-38ab-3afc-9cda-2d491cad82bf', 'Safe', 'MLBB', 1, 1, '2025-06-19 00:50:05', 20, 1, '2025-06-20 00:50:05'),
(12458, '125.164.11.247', 1, 'FREE-WCXEPEQC', 'ZK9SA2LS-THMPHCK-WCXEPEQC', '', 'Bypass Runing 24 Hours', '2025-06-20 17:13:37', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-19 18:13:37', 20, 1, '2025-06-20 18:13:37'),
(12459, '49.145.196.156', 1, 'FREE-OZNRFLKZ', 'Z4SHXTI0-THMPHCK-OZNRFLKZ', '', 'Bypass Runing 24 Hours', '2025-06-20 19:52:20', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-19 20:52:20', 20, 1, '2025-06-20 20:52:20'),
(12460, '110.139.236.12', 1, 'FREE-BE4FNTPO', 'S04KZRYP-THMPHCK-BE4FNTPO', '', 'Bypass Runing 24 Hours', '2025-06-20 22:21:01', 1, 1, '0', '9497b7ea-0239-3892-b074-48e5dec9c954', 'Safe', 'MLBB', 1, 1, '2025-06-19 23:21:01', 20, 1, '2025-06-20 23:21:01'),
(12461, '185.107.56.212', 1, 'FREE-24XBFC9B', 'TNUSYFDD-THMPHCK-24XBFC9B', '', 'Bypass Runing 24 Hours', '2025-06-21 12:53:09', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-20 13:53:09', 20, 1, '2025-06-21 13:53:09'),
(12462, '175.176.39.154', 1, 'FREE-10TR0TUW', 'HPEFWEDJ-THMPHCK-10TR0TUW', '', 'Bypass Runing 24 Hours', '2025-06-21 12:53:10', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-20 13:53:10', 20, 1, '2025-06-21 13:53:10'),
(12463, '180.253.191.72', 1, 'FREE-QY0HWT8N', 'YWILGNH1-THMPHCK-QY0HWT8N', '', 'Bypass Runing 24 Hours', '2025-06-22 13:28:32', 1, 1, '0', 'ac0b243e-3a1f-3454-9ad7-2c0422bfff21', 'Safe', 'MLBB', 1, 1, '2025-06-21 14:28:32', 20, 1, '2025-06-22 14:28:32'),
(12464, '182.253.57.133', 1, 'FREE-II4NS8WE', 'UTX5UTWI-THMPHCK-II4NS8WE', '', 'Bypass Runing 24 Hours', '2025-06-22 19:04:34', 1, 1, '0', 'dd65ac20-420f-37b9-a103-ac0b5fdfe18b', 'Safe', 'MLBB', 1, 1, '2025-06-21 20:04:34', 20, 1, '2025-06-22 20:04:34'),
(12465, '104.28.249.187', 1, 'FREE-N6MZKWIP', 'G8ULEHKI-THMPHCK-N6MZKWIP', '', 'Bypass Runing 24 Hours', '2025-06-22 20:20:26', 1, 1, '0', '0fa7d301-8ba3-3cd7-8c1a-14db2b554d81', 'Safe', 'MLBB', 1, 1, '2025-06-21 21:20:26', 20, 1, '2025-06-22 21:20:26'),
(12466, '104.28.217.187', 1, 'FREE-YSENU4RK', 'PQLG3HNY-THMPHCK-YSENU4RK', '', 'Bypass Runing 24 Hours', '2025-06-22 23:56:29', 1, 1, '0', '0d9e3124-6aba-3fa9-9040-27c3ac274e9c', 'Safe', 'MLBB', 1, 1, '2025-06-22 00:56:29', 20, 1, '2025-06-23 00:56:29'),
(12467, '143.44.165.47', 1, 'FREE-TQHCWLEU', 'LZIWC7AH-THMPHCK-TQHCWLEU', '', 'Bypass Runing 24 Hours', '2025-06-23 00:13:43', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-22 01:13:43', 20, 1, '2025-06-23 01:13:43'),
(12468, '180.191.162.243', 1, 'FREE-4G6N5WPJ', 'ZHS80IWL-THMPHCK-4G6N5WPJ', '', 'Bypass Runing 24 Hours', '2025-06-23 05:50:46', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-22 06:50:46', 20, 1, '2025-06-23 06:50:46'),
(12469, '112.215.245.22', 1, 'FREE-K5ZBQZJI', 'YP7K6KOF-THMPHCK-K5ZBQZJI', '', 'Bypass Runing 24 Hours', '2025-06-23 07:44:55', 1, 1, '0', '23e12384-bf54-338f-929f-f52f98c0a057', 'Safe', 'MLBB', 1, 1, '2025-06-22 08:44:55', 20, 1, '2025-06-23 08:44:55'),
(12471, '210.170.22.208', 1, 'FREE-RQMR8CIO', 'RGUDP6NC-THMPHCK-RQMR8CIO', '', 'Bypass Runing 24 Hours', '2025-06-23 09:36:43', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-22 10:36:43', 20, 1, '2025-06-23 10:36:43'),
(12472, '8.212.169.70', 1, 'FREE-9Y3ICAPD', 'HRUMOPPE-THMPHCK-9Y3ICAPD', '', 'Bypass Runing 24 Hours', '2025-06-23 11:01:56', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-22 12:01:56', 20, 1, '2025-06-23 12:01:56'),
(12473, '209.107.192.16', 1, 'FREE-NHHNOGBJ', 'FD3NZKQT-THMPHCK-NHHNOGBJ', '', 'Bypass Runing 24 Hours', '2025-06-23 13:10:30', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-22 14:10:30', 20, 1, '2025-06-23 14:10:30'),
(12474, '124.150.139.62', 1, 'FREE-P5ZNJ5US', 'XNO1SUBW-THMPHCK-P5ZNJ5US', '', 'Bypass Runing 24 Hours', '2025-06-23 14:11:11', 1, 1, '0', '48a9a093-205f-39ec-9507-2d9946c29e9f', 'Safe', 'MLBB', 1, 1, '2025-06-22 15:11:11', 20, 1, '2025-06-23 15:11:11'),
(12475, '172.105.9.117', 1, 'FREE-PGIYSCCD', 'TEGGT9MX-THMPHCK-PGIYSCCD', '', 'Bypass Runing 24 Hours', '2025-06-23 17:02:52', 1, 1, '0', '01e562dc-134c-3d03-9940-eb1248b5accd', 'Safe', 'MLBB', 1, 1, '2025-06-22 18:02:52', 20, 1, '2025-06-23 18:02:52'),
(12476, '216.247.19.111', 1, 'FREE-SLCFMGJC', 'AOUUDTFI-THMPHCK-SLCFMGJC', '', 'Bypass Runing 24 Hours', '2025-06-24 19:30:43', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-23 20:30:43', 20, 1, '2025-06-24 20:30:43'),
(12477, '114.10.135.49', 1, 'FREE-6SLKYML6', 'LOBSF0MO-THMPHCK-6SLKYML6', '', 'Bypass Runing 24 Hours', '2025-06-25 09:09:35', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-24 10:09:35', 20, 1, '2025-06-25 10:09:35'),
(12478, '125.164.22.197', 1, 'FREE-GD8EPYQ0', 'P2WNWF9Z-THMPHCK-GD8EPYQ0', '', 'Bypass Runing 24 Hours', '2025-06-25 17:37:34', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-24 18:37:34', 20, 1, '2025-06-25 18:37:34'),
(12479, '136.158.58.154', 1, 'FREE-D0UFJWUG', 'ZAK80EGX-THMPHCK-D0UFJWUG', '', 'Bypass Runing 24 Hours', '2025-06-25 21:43:27', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-24 22:43:27', 20, 1, '2025-06-25 22:43:27'),
(12480, '77.79.175.95', 1, 'FREE-9DERUF0O', '5YUUIQAT-THMPHCK-9DERUF0O', '', 'Bypass Runing 24 Hours', '2025-06-25 23:24:43', 1, 1, '0', '1295b7d8-9d87-36f0-a732-a2f024a4d06f', 'Safe', 'MLBB', 1, 1, '2025-06-25 00:24:43', 20, 1, '2025-06-26 00:24:43'),
(12481, '180.242.68.169', 1, 'FREE-ZMJBHWMN', 'RFZDOQWF-THMPHCK-ZMJBHWMN', '', 'Bypass Runing 24 Hours', '2025-06-26 11:31:32', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-25 12:31:32', 20, 1, '2025-06-26 12:31:32'),
(12482, '27.109.115.158', 1, 'FREE-BUJJ2WQO', 'OJXIAK7O-THMPHCK-BUJJ2WQO', '', 'Bypass Runing 24 Hours', '2025-06-26 15:41:46', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-25 16:41:46', 20, 1, '2025-06-26 16:41:46'),
(12483, '103.214.185.89', 1, 'FREE-MOBOBKUE', 'AQSQMIZP-THMPHCK-MOBOBKUE', '', 'Bypass Runing 24 Hours', '2025-06-26 16:30:57', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-25 17:30:57', 20, 1, '2025-06-26 17:30:57'),
(12485, '180.191.162.243', 1, 'FREE-FINJHK8Q', 'AHLPWMIY-THMPHCK-FINJHK8Q', '', 'Bypass Runing 24 Hours', '2025-06-27 11:19:59', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-26 12:19:59', 20, 1, '2025-06-27 12:19:59'),
(12486, '27.109.115.158', 1, 'FREE-WLWKTMZL', 'MNRSUZ2M-THMPHCK-WLWKTMZL', '', 'Bypass Runing 24 Hours', '2025-06-27 16:25:46', 1, 1, '0', '3a7d7599-3d6d-3030-8603-09db37f38537', 'Safe', 'MLBB', 1, 1, '2025-06-26 17:25:46', 20, 1, '2025-06-27 17:25:46'),
(12487, '208.115.233.116', 1, 'FREE-SYWEQHZE', 'DF0T1UDI-THMPHCK-SYWEQHZE', '', 'Bypass Runing 24 Hours', '2025-06-27 21:01:29', 1, 1, '0', 'be910f6b-92c3-3398-a70a-37b1549473e9', 'Safe', 'MLBB', 1, 1, '2025-06-26 22:01:29', 20, 1, '2025-06-27 22:01:29'),
(12488, NULL, 1, 'VIP 31', 'MLBB_HCNS7FWQPD', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-07-26 22:29:25', 10, 10, '0', 'ad6f2b10-eb23-35cc-8639-e097bcea205b', 'Safe', 'MLBB', 1, 30, '2025-06-26 22:23:57', 100, 0, NULL),
(12489, '110.5.69.94', 1, 'FREE-AZJ7INOK', 'OUQXMQSA-THMPHCK-AZJ7INOK', '', 'Bypass Runing 24 Hours', '2025-06-28 01:21:23', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-27 02:21:23', 20, 1, '2025-06-28 02:21:23'),
(12490, '95.180.128.103', 1, 'FREE-24PUFYMA', 'R0UGUPG7-THMPHCK-24PUFYMA', '', 'Bypass Runing 24 Hours', '2025-06-28 06:48:20', 1, 1, '0', '3086f417-a90e-3fc4-88c4-95302f8b3468', 'Safe', 'MLBB', 1, 1, '2025-06-27 07:48:20', 20, 1, '2025-06-28 07:48:20'),
(12492, '36.70.172.187', 1, 'FREE-HXAOCRJO', 'GRPIEFCI-THMPHCK-HXAOCRJO', '', 'Bypass Runing 24 Hours', '2025-06-30 01:24:32', 1, 1, '0', 'dc87511f-575d-382d-8fd7-cb17b7e296b0', 'Safe', 'MLBB', 1, 1, '2025-06-29 02:24:32', 20, 1, '2025-06-30 02:24:32'),
(12493, '136.158.78.67', 1, 'FREE-EBW5U19M', 'SEGQKPZC-THMPHCK-EBW5U19M', '', 'Bypass Runing 24 Hours', '2025-06-30 09:34:27', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-29 10:34:27', 20, 1, '2025-06-30 10:34:27'),
(12494, '114.122.41.221', 1, 'FREE-RTIXEES2', 'GFXNTQGY-THMPHCK-RTIXEES2', '', 'Bypass Runing 24 Hours', '2025-06-30 12:42:56', 1, 1, '0', '601cd46c-2f73-3327-967c-58223d0b5b19', 'Safe', 'MLBB', 1, 1, '2025-06-29 13:42:56', 20, 1, '2025-06-30 13:42:56'),
(12495, '37.19.205.247', 1, 'FREE-ZNZ9TDC5', '028ZCCXF-THMPHCK-ZNZ9TDC5', '', 'Bypass Runing 24 Hours', '2025-06-30 21:08:28', 1, 1, '0', '21c42687-e575-3935-9128-93696338a8df', 'Safe', 'MLBB', 1, 1, '2025-06-29 22:08:28', 20, 1, '2025-06-30 22:08:28'),
(12496, '180.191.207.254', 1, 'FREE-6T64HAZH', 'O9KJIFMO-THMPHCK-6T64HAZH', '', 'Bypass Runing 24 Hours', '2025-06-30 21:54:34', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-29 22:54:34', 20, 1, '2025-06-30 22:54:34'),
(12497, '36.70.172.187', 1, 'FREE-8RGHABJX', 'IGPDLABB-THMPHCK-8RGHABJX', '', 'Bypass Runing 24 Hours', '2025-07-01 10:25:19', 1, 1, '0', '759cc71e-fa1f-3769-aaf4-1f9215cf4383', 'Safe', 'MLBB', 1, 1, '2025-06-30 11:25:19', 20, 1, '2025-07-01 11:25:19'),
(12498, '213.230.118.27', 1, 'FREE-QHRQAIXY', 'U9YX1GJM-THMPHCK-QHRQAIXY', '', 'Bypass Runing 24 Hours', '2025-07-01 13:08:04', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-06-30 14:08:04', 20, 1, '2025-07-01 14:08:04'),
(12499, '210.170.22.208', 1, 'FREE-OX3THQ7G', 'BFLIOI3K-THMPHCK-OX3THQ7G', '', 'Bypass Runing 24 Hours', '2025-07-01 20:52:35', 1, 1, '0', '6aec6c89-0f19-37fc-93b5-d5a783218557', 'Safe', 'MLBB', 1, 1, '2025-06-30 21:52:35', 20, 1, '2025-07-01 21:52:35'),
(12500, '180.253.73.44', 1, 'FREE-O1HCB00D', 'J4UYJXH1-THMPHCK-O1HCB00D', '', 'Bypass Runing 24 Hours', '2025-07-01 23:16:46', 1, 1, '0', 'cb229001-33be-3412-b402-627a72e6c074', 'Safe', 'MLBB', 1, 1, '2025-07-01 00:16:46', 20, 1, '2025-07-02 00:16:46'),
(12502, '90.156.162.246', 1, 'FREE-CAUOHJ9I', 'J8DML9M4-THMPHCK-CAUOHJ9I', '', 'Bypass Runing 24 Hours', '2025-07-02 06:43:57', 1, 1, '0', '4eece1d5-bbde-318e-9603-22684857d026', 'Safe', 'MLBB', 1, 1, '2025-07-01 07:43:57', 20, 1, '2025-07-02 07:43:57'),
(12503, '36.81.11.54', 1, 'FREE-NMNXUOGZ', 'Y8QEJ16B-THMPHCK-NMNXUOGZ', '', 'Bypass Runing 24 Hours', '2025-07-02 13:43:19', 1, 1, '0', 'cef77717-d907-3d2d-bd2f-e4a2e8aa8b62', 'Safe', 'MLBB', 1, 1, '2025-07-01 14:43:19', 20, 1, '2025-07-02 14:43:19'),
(12504, '213.230.78.2', 1, 'FREE-GA4Y3GQE', 'WJ6NETNQ-THMPHCK-GA4Y3GQE', '', 'Bypass Runing 24 Hours', '2025-07-02 15:31:36', 1, 1, '0', '661b672c-8950-33e0-a9b6-406aa2570a6d', 'Safe', 'MLBB', 1, 1, '2025-07-01 16:31:36', 20, 1, '2025-07-02 16:31:36'),
(12505, '175.100.59.202', 1, 'FREE-LGIKFRFQ', 'XCOHY9XI-THMPHCK-LGIKFRFQ', '', 'Bypass Runing 24 Hours', '2025-07-02 20:07:05', 1, 1, '0', '433947d1-5b08-327f-9532-3f123d567331', 'Safe', 'MLBB', 1, 1, '2025-07-01 21:07:05', 20, 1, '2025-07-02 21:07:05'),
(12508, '213.206.62.182', 1, 'FREE-JFPYQNNF', 'LMZF9T6Q-THMPHCK-JFPYQNNF', '', 'Bypass Runing 24 Hours', '2025-07-03 14:49:57', 1, 1, '0', '0a941168-0415-33ee-8ec7-d31c3b981480', 'Safe', 'MLBB', 1, 1, '2025-07-02 15:49:57', 20, 1, '2025-07-03 15:49:57'),
(12509, '185.213.230.57', 1, 'FREE-H3H8NLYM', 'NBKLOZFP-THMPHCK-H3H8NLYM', '', 'Bypass Runing 24 Hours', '2025-07-04 05:20:57', 1, 1, '0', 'a20eec95-5538-3a01-9565-25b35af3123b', 'Safe', 'MLBB', 1, 1, '2025-07-03 06:20:57', 20, 1, '2025-07-04 06:20:57'),
(12510, '156.244.8.82', 1, 'FREE-RLZKNJXS', 'ZQN9TQ3Q-THMPHCK-RLZKNJXS', '', 'Bypass Runing 24 Hours', '2025-07-04 06:56:02', 1, 1, '0', 'dad95a1b-b05b-326a-90fd-c4528f3d5855', 'Safe', 'MLBB', 1, 1, '2025-07-03 07:56:02', 20, 1, '2025-07-04 07:56:02'),
(12511, NULL, 1, 'zetian', 'MLBB_GDZWJHRTMT', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-11-07 11:15:48', 10, 10, '0', '38a27142-a94f-3f3a-926b-3ea2a9893c87', 'Safe', 'MLBB', 1, 127, '2025-07-03 11:12:15', 100, 0, NULL),
(12512, '203.106.115.158', 1, 'FREE-WNLYF4NS', 'BDEOGOQ6-THMPHCK-WNLYF4NS', '', 'Bypass Runing 24 Hours', '2025-07-05 00:03:46', 1, 1, '0', '1433abde-db7b-3a02-9cb0-3e9295e5bd19', 'Safe', 'MLBB', 1, 1, '2025-07-04 01:03:46', 20, 1, '2025-07-05 01:03:46'),
(12513, '121.7.181.34', 1, 'FREE-UK5LY1XR', '8TX9LG44-THMPHCK-UK5LY1XR', '', 'Bypass Runing 24 Hours', '2025-07-05 21:53:40', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-04 22:53:40', 20, 1, '2025-07-05 22:53:40'),
(12514, '202.166.81.117', 1, 'FREE-OGEP1OJY', 'LHOHG8FC-THMPHCK-OGEP1OJY', '', 'Bypass Runing 24 Hours', '2025-07-06 09:24:05', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-05 10:24:05', 20, 1, '2025-07-06 10:24:05'),
(12515, '210.10.1.200', 1, 'FREE-2NQQN0G5', 'PFQL4E4U-THMPHCK-2NQQN0G5', '', 'Bypass Runing 24 Hours', '2025-07-06 10:51:30', 1, 1, '0', '073fe738-1bea-36f5-a54f-055fa46f7337', 'Safe', 'MLBB', 1, 1, '2025-07-05 11:51:30', 20, 1, '2025-07-06 11:51:30'),
(12516, '45.84.107.55', 1, 'FREE-0EWD0B8A', 'SROZIART-THMPHCK-0EWD0B8A', '', 'Bypass Runing 24 Hours', '2025-07-06 12:22:29', 1, 1, '0', '55bfa634-5438-38bc-887e-9d58912ccfd2', 'Safe', 'MLBB', 1, 1, '2025-07-05 13:22:29', 20, 1, '2025-07-06 13:22:29'),
(12517, '192.42.116.185', 1, 'FREE-ZMKBG9X6', '9EJCAJY6-THMPHCK-ZMKBG9X6', '', 'Bypass Runing 24 Hours', '2025-07-06 17:02:00', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-05 18:02:00', 20, 1, '2025-07-06 18:02:00'),
(12518, '185.40.4.29', 1, 'FREE-XOXIGL5M', 'IAZRMB3Q-THMPHCK-XOXIGL5M', '', 'Bypass Runing 24 Hours', '2025-07-06 17:03:53', 1, 1, '0', '4eb549df-40e1-3575-ad4a-403fef1aee90', 'Safe', 'MLBB', 1, 1, '2025-07-05 18:03:53', 20, 1, '2025-07-06 18:03:53'),
(12519, '162.128.3.77', 1, 'FREE-RZOJYHXU', '09XALLU1-THMPHCK-RZOJYHXU', '', 'Bypass Runing 24 Hours', '2025-07-07 06:33:58', 1, 1, '0', '32d5e2ef-6fa2-3d3e-a750-8fe6f15be792', 'Safe', 'MLBB', 1, 1, '2025-07-06 07:33:58', 20, 1, '2025-07-07 07:33:58'),
(12520, NULL, 1, 'VIP - Omega Zero', 'MLBB_FL5NDKUHMS', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-09-07 09:13:51', 10, 10, '0', NULL, 'Safe', 'MLBB', 0, 63, '2025-07-06 09:13:51', 100, 0, NULL),
(12521, NULL, 1, 'Omega Zero | VIP', 'MLBB_7Z71MIDORM', 'XYOURZONE', 'Bypass Allways On 24 hours', '2025-09-07 11:00:09', 10, 10, '0', '56f9eca4-2799-3e2b-bce9-2082ce3906f0', 'Safe', 'MLBB', 1, 63, '2025-07-06 09:17:25', 100, 0, NULL),
(12522, '178.128.54.80', 1, 'FREE-CJJK9K3I', 'XRWLEOGR-THMPHCK-CJJK9K3I', '', 'Bypass Runing 24 Hours', '2025-07-08 12:53:42', 1, 1, '0', '62a79521-fd17-3fdc-ad7c-55bc6da647a6', 'Safe', 'MLBB', 1, 1, '2025-07-07 13:53:42', 20, 1, '2025-07-08 13:53:42'),
(12523, '110.136.30.47', 1, 'FREE-KWB5SKJH', 'QSFISMB3-THMPHCK-KWB5SKJH', '', 'Bypass Runing 24 Hours', '2025-07-08 13:31:30', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-07 14:31:30', 20, 1, '2025-07-08 14:31:30'),
(12524, '85.140.161.90', 1, 'FREE-AIWTICFR', 'DEG0ZSMG-THMPHCK-AIWTICFR', '', 'Bypass Runing 24 Hours', '2025-07-08 18:49:31', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-07 19:49:31', 20, 1, '2025-07-08 19:49:31'),
(12525, '125.164.19.188', 1, 'FREE-0U5Z4HKJ', 'U78WZMMD-THMPHCK-0U5Z4HKJ', '', 'Bypass Runing 24 Hours', '2025-07-08 19:59:50', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-07 20:59:50', 20, 1, '2025-07-08 20:59:50'),
(12526, '125.164.17.111', 1, 'FREE-X85AGNYS', '0EKITFN1-THMPHCK-X85AGNYS', '', 'Bypass Runing 24 Hours', '2025-07-08 20:11:20', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-07 21:11:20', 20, 1, '2025-07-08 21:11:20'),
(12527, '125.164.20.206', 1, 'FREE-IOAWPP53', 'SPYMAJGJ-THMPHCK-IOAWPP53', '', 'Bypass Runing 24 Hours', '2025-07-08 20:19:06', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-07 21:19:06', 20, 1, '2025-07-08 21:19:06'),
(12528, '120.28.200.119', 1, 'FREE-JXK5GJFJ', 'UF0IGAKM-THMPHCK-JXK5GJFJ', '', 'Bypass Runing 24 Hours', '2025-07-08 20:55:22', 1, 1, '0', 'cfd8ae97-7c12-3de3-8b33-055914f5a928', 'Safe', 'MLBB', 1, 1, '2025-07-07 21:55:22', 20, 1, '2025-07-08 21:55:22'),
(12529, '103.80.230.97', 1, 'FREE-C0RCOE9B', 'RUSULCGZ-THMPHCK-C0RCOE9B', '', 'Bypass Runing 24 Hours', '2025-07-08 22:54:59', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-07 23:54:59', 20, 1, '2025-07-08 23:54:59'),
(12530, '196.131.157.220', 1, 'FREE-RS03NAAI', 'RYNRT2QO-THMPHCK-RS03NAAI', '', 'Bypass Runing 24 Hours', '2025-07-09 07:21:31', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-08 08:21:31', 20, 1, '2025-07-09 08:21:31'),
(12531, '120.29.69.69', 1, 'FREE-PAONLHFL', 'SCBQKH5K-THMPHCK-PAONLHFL', '', 'Bypass Runing 24 Hours', '2025-07-09 08:32:37', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-08 09:32:37', 20, 1, '2025-07-09 09:32:37'),
(12532, '182.4.39.17', 1, 'FREE-G47CDRKI', '3MBPQOU7-THMPHCK-G47CDRKI', '', 'Bypass Runing 24 Hours', '2025-07-09 12:25:50', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-08 13:25:50', 20, 1, '2025-07-09 13:25:50'),
(12533, '62.16.2.22', 1, 'FREE-BZEKS6OC', 'RDKAXCZO-THMPHCK-BZEKS6OC', '', 'Bypass Runing 24 Hours', '2025-07-09 12:38:41', 1, 1, '0', '2d0b8806-9cbb-3de7-b635-7c8a4d60f1e9', 'Safe', 'MLBB', 1, 1, '2025-07-08 13:38:41', 20, 1, '2025-07-09 13:38:41'),
(12534, '103.105.76.87', 1, 'FREE-S67JYPET', '2UXGJX8M-THMPHCK-S67JYPET', '', 'Bypass Runing 24 Hours', '2025-07-09 13:45:04', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-08 14:45:04', 20, 1, '2025-07-09 14:45:04'),
(12535, '125.162.209.254', 1, 'FREE-O2LUXFNH', '6D5TJZI3-THMPHCK-O2LUXFNH', '', 'Bypass Runing 24 Hours', '2025-07-09 20:01:09', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-08 21:01:09', 20, 1, '2025-07-09 21:01:09'),
(12536, '149.102.244.69', 1, 'FREE-THDA5OSG', '92AIS2WI-THMPHCK-THDA5OSG', '', 'Bypass Runing 24 Hours', '2025-07-10 04:45:26', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-09 05:45:26', 20, 1, '2025-07-10 05:45:26'),
(12537, '149.102.244.69', 1, 'FREE-THDA5OSG', 'PPFDPHSW-THMPHCK-THDA5OSG', '', 'Bypass Runing 24 Hours', '2025-07-10 04:56:46', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-09 05:56:46', 20, 1, '2025-07-10 05:56:46'),
(12538, '54.37.204.108', 1, 'FREE-MOOKBACL', 'SEULLNZX-THMPHCK-MOOKBACL', '', 'Bypass Runing 24 Hours', '2025-07-10 06:11:27', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-09 07:11:27', 20, 1, '2025-07-10 07:11:27'),
(12539, '140.213.139.228', 1, 'FREE-SE6JX3GZ', 'DOAQ2WHY-THMPHCK-SE6JX3GZ', '', 'Bypass Runing 24 Hours', '2025-07-10 10:58:20', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-09 11:58:20', 20, 1, '2025-07-10 11:58:20'),
(12541, '2.134.162.150', 1, 'FREE-XXDHMHMQ', 'IYX7ASQ0-THMPHCK-XXDHMHMQ', '', 'Bypass Runing 24 Hours', '2025-07-10 23:30:27', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-10 00:30:27', 20, 1, '2025-07-11 00:30:27'),
(12542, '85.117.106.141', 1, 'FREE-84J6RGIP', 'EGTJMRQP-THMPHCK-84J6RGIP', '', 'Bypass Runing 24 Hours', '2025-07-11 01:03:18', 1, 1, '0', '16d9996b-9e19-39e7-ac34-b8ce30836fe0', 'Safe', 'MLBB', 1, 1, '2025-07-10 02:03:18', 20, 1, '2025-07-11 02:03:18'),
(12543, '196.191.159.11', 1, 'FREE-FJDUA5IG', '2YLAE8HT-THMPHCK-FJDUA5IG', '', 'Bypass Runing 24 Hours', '2025-07-11 02:46:55', 1, 1, '0', '612ef346-d3ec-3ba0-9471-ce46ed3faf2f', 'Safe', 'MLBB', 1, 1, '2025-07-10 03:46:55', 20, 1, '2025-07-11 03:46:55'),
(12544, '117.20.116.247', 1, 'FREE-8H04YJQR', 'J9ROZDRM-THMPHCK-8H04YJQR', '', 'Bypass Runing 24 Hours', '2025-07-11 10:26:29', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-10 11:26:29', 20, 1, '2025-07-11 11:26:29'),
(12546, '188.162.1.206', 1, 'FREE-8GJAW4HX', 'DQL5AUXW-THMPHCK-8GJAW4HX', '', 'Bypass Runing 24 Hours', '2025-07-12 02:54:36', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-11 03:54:36', 20, 1, '2025-07-12 03:54:36'),
(12547, '188.162.1.83', 1, 'FREE-IZFIDMLU', 'KZYCSCT5-THMPHCK-IZFIDMLU', '', 'Bypass Runing 24 Hours', '2025-07-12 13:46:55', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-11 14:46:55', 20, 1, '2025-07-12 14:46:55'),
(12548, '180.253.164.141', 1, 'FREE-8TSHM8G2', 'HUC4HR4J-THMPHCK-8TSHM8G2', '', 'Bypass Runing 24 Hours', '2025-07-12 15:03:48', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-11 16:03:48', 20, 1, '2025-07-12 16:03:48'),
(12549, '112.205.143.183', 1, 'FREE-PQX9DUQK', 'FLQO6PX6-THMPHCK-PQX9DUQK', '', 'Bypass Runing 24 Hours', '2025-07-12 19:58:46', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-11 20:58:46', 20, 1, '2025-07-12 20:58:46'),
(12550, '31.223.42.189', 1, 'FREE-NFH5RARE', 'NYOB5EYK-THMPHCK-NFH5RARE', '', 'Bypass Runing 24 Hours', '2025-07-12 20:55:43', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-11 21:55:43', 20, 1, '2025-07-12 21:55:43'),
(12551, '85.106.97.38', 1, 'FREE-9X3NFIJF', 'O739J7S7-THMPHCK-9X3NFIJF', '', 'Bypass Runing 24 Hours', '2025-07-12 21:35:51', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-11 22:35:51', 20, 1, '2025-07-12 22:35:51'),
(12552, '140.233.157.100', 1, 'FREE-9XLHTGBU', 'ZYBFPQIS-THMPHCK-9XLHTGBU', '', 'Bypass Runing 24 Hours', '2025-07-13 05:18:15', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-12 06:18:15', 20, 1, '2025-07-13 06:18:15'),
(12553, '185.228.105.23', 1, 'FREE-A4HFLQWU', 'ZBCGWNQF-THMPHCK-A4HFLQWU', '', 'Bypass Runing 24 Hours', '2025-07-13 12:28:58', 1, 1, '0', '4ad0d681-1a37-344f-aff8-b7e008cd3dd8', 'Safe', 'MLBB', 1, 1, '2025-07-12 13:28:58', 20, 1, '2025-07-13 13:28:58'),
(12554, '50.60.236.208', 1, 'FREE-U31JGCS7', 'GSHKZ8YM-THMPHCK-U31JGCS7', '', 'Bypass Runing 24 Hours', '2025-07-14 04:01:43', 1, 1, '0', '09176c1b-ecd8-3a4e-affd-a0ec5da4b1cf', 'Safe', 'MLBB', 1, 1, '2025-07-13 05:01:43', 20, 1, '2025-07-14 05:01:43'),
(12555, '140.213.171.14', 1, 'FREE-XGB2OIHE', '60NXAY5Q-THMPHCK-XGB2OIHE', '', 'Bypass Runing 24 Hours', '2025-07-14 10:10:16', 1, 1, '0', '34ef1809-9972-39db-957e-f67076b69e16', 'Safe', 'MLBB', 1, 1, '2025-07-13 11:10:16', 20, 1, '2025-07-14 11:10:16'),
(12556, '61.245.13.10', 1, 'FREE-KTKFGRWF', '02M7PWP9-THMPHCK-KTKFGRWF', '', 'Bypass Runing 24 Hours', '2025-07-14 17:22:55', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-13 18:22:55', 20, 1, '2025-07-14 18:22:55'),
(12557, '46.155.230.101', 1, 'FREE-6YAJCBYC', 'HNJIXXE2-THMPHCK-6YAJCBYC', '', 'Bypass Runing 24 Hours', '2025-07-15 12:00:47', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-14 13:00:47', 20, 1, '2025-07-15 13:00:47'),
(12558, '176.219.6.229', 1, 'FREE-CZ5XF108', '5DBAL5JT-THMPHCK-CZ5XF108', '', 'Bypass Runing 24 Hours', '2025-07-15 12:24:32', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-14 13:24:32', 20, 1, '2025-07-15 13:24:32'),
(12559, '112.215.165.123', 1, 'FREE-GGGF1MJN', 'Q09FHCJT-THMPHCK-GGGF1MJN', '', 'Bypass Runing 24 Hours', '2025-07-15 18:34:38', 1, 1, '0', 'c7f5afc9-b75c-3331-a862-1ef7d2b3247e', 'Safe', 'MLBB', 1, 1, '2025-07-14 19:34:38', 20, 1, '2025-07-15 19:34:38'),
(12560, '120.188.37.143', 1, 'FREE-SKETHFF4', 'QNRB5FF9-THMPHCK-SKETHFF4', '', 'Bypass Runing 24 Hours', '2025-07-15 21:09:18', 1, 1, '0', NULL, 'Safe', 'MLBB', 1, 1, '2025-07-14 22:09:18', 20, 1, '2025-07-15 22:09:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `balance` double NOT NULL,
  `level` enum('Member','Admin','Client') NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `api_key` varchar(255) NOT NULL,
  `uplink` int(11) NOT NULL DEFAULT 1,
  `remember_me` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `balance`, `level`, `status`, `api_key`, `uplink`, `remember_me`, `created_at`) VALUES
(1, 'adminlogin', '$2y$10$Re6aJmbMEAqZUnpU91APh.iVNL9oGfBJsosakMOP0SnaEYQq7.udG', 'XYOURZONE', 9999761447737, 'Admin', 1, 'Rrdb1Kt1UWqK5t1pOCnQ5sVidqNDF0', 1, '1', '2023-09-09 23:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `vouchers`
--

CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `voucher_code` text NOT NULL,
  `status` int(11) NOT NULL,
  `uplink` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `vouchers`
--

INSERT INTO `vouchers` (`id`, `user_id`, `amount`, `voucher_code`, `status`, `uplink`, `created_at`) VALUES
(1, 34, 100000, 'UPOf2nY4GndpGbT', 0, 1, '2023-07-23 07:38:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_log`
--
ALTER TABLE `access_log`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_access` (`ip_address`,`access_date`);

--
-- Indexes for table `app`
--
ALTER TABLE `app`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `balance_logs`
--
ALTER TABLE `balance_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposit_methods`
--
ALTER TABLE `deposit_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `free`
--
ALTER TABLE `free`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invite`
--
ALTER TABLE `invite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_akses`
--
ALTER TABLE `log_akses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mod_data`
--
ALTER TABLE `mod_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pgen`
--
ALTER TABLE `pgen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pricelist`
--
ALTER TABLE `pricelist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register_logs`
--
ALTER TABLE `register_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reqList`
--
ALTER TABLE `reqList`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restAPI`
--
ALTER TABLE `restAPI`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_cat`
--
ALTER TABLE `service_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sList`
--
ALTER TABLE `sList`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_replies`
--
ALTER TABLE `ticket_replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_log`
--
ALTER TABLE `access_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app`
--
ALTER TABLE `app`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `balance_logs`
--
ALTER TABLE `balance_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `deposit_methods`
--
ALTER TABLE `deposit_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `free`
--
ALTER TABLE `free`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `invite`
--
ALTER TABLE `invite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `log_akses`
--
ALTER TABLE `log_akses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=246;

--
-- AUTO_INCREMENT for table `mod_data`
--
ALTER TABLE `mod_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pgen`
--
ALTER TABLE `pgen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pricelist`
--
ALTER TABLE `pricelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `provider`
--
ALTER TABLE `provider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `register_logs`
--
ALTER TABLE `register_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `reqList`
--
ALTER TABLE `reqList`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restAPI`
--
ALTER TABLE `restAPI`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `service_cat`
--
ALTER TABLE `service_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sList`
--
ALTER TABLE `sList`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ticket_replies`
--
ALTER TABLE `ticket_replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12561;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `vouchers`
--
ALTER TABLE `vouchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
