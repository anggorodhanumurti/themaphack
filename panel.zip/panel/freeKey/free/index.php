<?php
require '../../app/mainconfig.php';
require '../../app/lib/partials/head-css.php';
require '../../app/lib/partials/title-meta.php';

?>
<body oncontextmenu="return false">
    <div class="container text-center">
       <h1 id="countdown">10</h1>
       <h1 id="redirect-page">Redirect...</h1>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 
    
    <script>
        let countdown = 10;
        const countdownElement = document.getElementById('countdown');
        const hiddenPage = document.getElementById('hidden-page');
        const redirectPage = document.getElementById('redirect-page');
        
        function updateCountdown() {
            countdown--;
            countdownElement.textContent = countdown;

            if (countdown === 0) {
                clearInterval(countdownInterval);
                window.location.href = "https://gplinks.in/st?api=ab0786f54a974d18672c49ee31672d4c1cd9ffa6&url=https://t0pgamemurah.xyz/datZ/gen-key/free/";
            }
        }
        const countdownInterval = setInterval(updateCountdown, 1000); // Update every 1 second
    </script>
</body>
</html>
    