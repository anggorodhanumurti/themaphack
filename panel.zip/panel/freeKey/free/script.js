let countdownTime = 5; // Initial seconds

// Update the countdown display
function updateCountdown() {
    document.getElementById('countdown').textContent = countdownTime;
    countdownTime--;

    if (countdownTime < 0) {
        clearInterval(countdownInterval); 
        document.getElementById('redirect-message').textContent = 'Redirecting...';
        window.location.href = 'http://www.example.com'; // Replace with your target URL
    }
}

// Start the countdown
let countdownInterval = setInterval(updateCountdown, 1000); // Update every second
