<?php
session_start();
$ip = '';
if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
     $ip = $_SERVER['HTTP_CLIENT_IP'];
} else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
     $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $paw = "VN";
    $pass = array();
    $alphaLength = strlen($alphabet) - 1;
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
}
/*
$encip = base64_encode($ip);
    $p1 = $str2;
    $p2 = sha1($encip);
    $p3 = base64_encode($str2."::".$p2);
    if($_POST['server'] == 1) {
        $_SESSION['KeyGen'] = "server1";
	    header("Location: https://besargaji.com/st/?api=25f6bf4f29c026fa33ad212523c6d2c179f4600d&url=https://D5STUDIOmods.xyz/gen-key/free/jump.php"."?session=".$p3);
	    $_SERVER['game'] = "Gen";
	    die();
    }
*/

/*
$str2 = randomPassword();
$dall = base64_decode($_GET['session']);
$arry = explode("::",$dall);
$encip = base64_encode($ip);
$p1 = $str2;
$p2 = sha1($encip);
$p3 = base64_encode($p2);
if($arry[1] == $p2){
    if ($_SESSION['KeyGen'] == "Page1"){
        header("Location: https://besargaji.com/st/?api=25f6bf4f29c026fa33ad212523c6d2c179f4600d&url=https://besargaji.com/st/?api=25f6bf4f29c026fa33ad212523c6d2c179f4600d&url=https://semawur.com/st/?api=fe68208b4ba30a626c9ea4ad3777a558f033568e&url=https://D5STUDIOmods.xyz/gen-key/free/");    
        $_SESSION['enc'] = $encip;
        $_SESSION['KeyGen'] = "un";
    } else {
        $_SESSION['enc'] = 'Goblok';
        $result = array('Access' => 'ERROR', 'msg' => 'Mau Bypass Bang?');
        print(json_encode($result, JSON_PRETTY_PRINT));
    }
} else {
    header("Location: https://besargaji.com/st/?api=25f6bf4f29c026fa33ad212523c6d2c179f4600d&url=https://D5STUDIOmods.xyz/gen-key/");
}
*/

?>