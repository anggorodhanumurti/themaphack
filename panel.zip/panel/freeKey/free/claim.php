<?php
require '../../app/mainconfig.php';

unset($_SESSION['generate']);
header("location: ../");

?>