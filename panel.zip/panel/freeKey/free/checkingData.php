<?php
require '../../app/mainconfig.php';
require '../../app/lib/partials/head-css.php';
require '../../app/lib/partials/title-meta.php';
//session_start();

date_default_timezone_set('Asia/Jakarta');
$besok = date('Y-m-d H:i:s', strtotime("+1 day", strtotime(date("Y-m-d H:i:s"))));
//end penting
if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
     $ip = $_SERVER['HTTP_CLIENT_IP'];
    
}  
//if user is from the proxy  
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
     $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
    
}  
//if user is from the remote address  
else{  
    $ip = $_SERVER['REMOTE_ADDR'];
}

if ($config['web']['FreeToken'] == 1) {
	$result = array('status' => false, 'data' => array('msg' => 'Key Gen Temporary Closed!'));
	exit(json_encode($result, JSON_PRETTY_PRINT));
}

function getkeys() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array();
    $alphaLength = strlen($alphabet) - 1;
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
}

//=========================== 1 IP ADDRESS 1 TIMES GET KEY IN 24 HOURS ===========================\\
$conn = new mysqli('localhost', 'rljxtwtd_xyzbase', 'isal0101@', 'rljxtwtd_xyzbase');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$ip_address = $_SERVER['REMOTE_ADDR'];

// Check if the IP has accessed in the last hour
$query = "SELECT COUNT(*) as count FROM log_akses WHERE ip = ? AND timestamp > NOW() - INTERVAL 1 DAY";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $ip_address);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['count'] > 0) {
    $msg = 'Please Try Again..';
    $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
    $output = "Try Again Tomorrow!!";
    $expired = "..";
} else {
    // Log the access
    $sql = "INSERT INTO log_akses (ip, timestamp, user_agent) VALUES ('".$_SERVER['REMOTE_ADDR']."', NOW(), '".$_SERVER['HTTP_USER_AGENT']."')";
    //$model->db_insert($db, "log_akses", array('ip' => $_SERVER['REMOTE_ADDR'], 'timestap' => date("Y-m-d H:i:s"), 'user_agent' => $_SERVER['HTTP_USER_AGENT']) == true);
    //$sql = "INSERT INTO log_akses (user_agent) VALUES ('".$_SERVER['HTTP_USER_AGENT']."')";
    mysqli_query($conn, $sql);

    if($_GET['data']){
        $old_key = base64_decode($_GET['data']);
        $split = explode("::", $old_key);
        $session_key = $split[1];
        $verif_ip = $split[0];
        $game = $_SESSION['generate']['game'];
        $ip = $_SESSION['generate']['data'];
        if($verif_ip == $ip){
            if($session_key == $_SESSION['generate']['key']){
                //pass
                $s_key = strtoupper(getkeys());
                $key = $s_key."-XYOURZONE-".$_SESSION['generate']['key'];
                $cek_key = $model->db_query($db, "*", "token" ,"access_key='".$key."'");
                $cek = $model->db_query($db, "*", "token", "ip = '" .$verif_ip."'");
                if($cek_key['count'] < 1){
                    
                    if($model->db_insert($db, "token", array('ip'=>$ip,'uid' =>  1, 'data' => "FREE-".$_SESSION['generate']['key'], 'access_key' => $s_key."-XYOURZONE-".$_SESSION['generate']['key'], 'cheat_name' => $data['brand'], 'cheat_text' => "Bypass Runing 24 Hours", 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$_SESSION['generate']['time']." hour", strtotime(date("Y-m-d H:i:s")))), 'cheat_slot' => 1, 'slot' => 1, 'Status' => "Safe", 'vip' => 20, 'games'=> $game, 'durasi' => 1,'active' => 1, 'start'=> date('Y-m-d H:i:s'),'isUse'=>1, 'sn' => $besok)) == true){
                        $msg = "Token ".$s_key."-XYOURZONE-".$_SESSION['generate']['key']." Has been claimed before ";
                        $result_msg = array('alert' => 'danger', 'title' => 'Success!', 'msg' => $msg);
                        $output = $s_key."-XYOURZONE-".$_SESSION['generate']['key'];
                        $expired = date('Y-m-d H:i:s', strtotime("+".$_SESSION['generate']['time']." hour", strtotime(date("Y-m-d H:i:s"))));
                        $_SESSION['claim'] = array('ip'=>$ip,'uid' =>  1, 'data' => $s_key."-".$_SESSION['generate']['key'], 'access_key' => $s_key."-XYOURZONE-".$_SESSION['generate']['key'], 'cheat_name' => $data['brand'], 'cheat_text' => "Bypass Runing 24 Hours", 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$_SESSION['generate']['time']." hour", strtotime(date("Y-m-d H:i:s")))), 'cheat_slot' => 1, 'slot' => 1, 'Status' => "Safe", 'vip' => 20, 'games'=> $game,'sn' => $besok, 'isUse'=>1, 'durasi' => 1,'active' => 1, 'start'=> date('Y-m-d H:i:s'));
                    }else{
                        $msg = 'Please Try Again..';
                        $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
                        $output = "Try Again!!";
                        $expired = "..";
                    }
                }else{
                    $msg = "Token ".$s_key."-XYOURZONE-".$_SESSION['generate']['key']." Has been claimed before";
                    $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
                    $output = "Try Again!!";
                    $expired = "..";
                }
            }else{
                $output = "session key invalid";
                $expired = "..";
            }
        }else{
            $output = "Try Again";
            $expired = "..";
        }
    } else{
        $msg = 'Try Again..';
        $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
        $output = "Sorry, try again ";
    }
}

if(isset($_POST['countdown']) == 5) {
    $msg = 'Choose The Server';
    $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
}

$stmt->close();

?>
<body oncontextmenu="return false">
    
    <div class="container text-center">
       <h1 id="countdown">5</h1>
       <h1 id="redirect-page">Redirect...</h1></br></br>
       <h1 id="redirect-page2">Yang make bypass link anak kontol, mati aja lu anjing</h1>
    </div>
    <div id="hidden-page">
        <div id="app" data-bs-theme="light">
            <div class="container-fluid d-flex align-items-center vh-100">
                <div class="container">
                    <div class="row d-flex justify-content-center">
                        <div class="col-md-7 col-lg-6 col-xl-5 col-xxl-4">
                            <div class="card m-0" data-aos="zoom-in">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="theme-toggle d-flex gap-2  align-items-center mt-3 mt-sm-0">
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                                            class="iconify iconify--system-uicons" width="20" height="20"
                                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 21 21">
                                                <g fill="none" fill-rule="evenodd" stroke="currentColor"
                                                stroke-linecap="round" stroke-linejoin="round">
                                                    <path
                                                    d="M10.5 14.5c2.219 0 4-1.763 4-3.982a4.003 4.003 0 0 0-4-4.018c-2.219 0-4 1.781-4 4c0 2.219 1.781 4 4 4zM4.136 4.136L5.55 5.55m9.9 9.9l1.414 1.414M1.5 10.5h2m14 0h2M4.135 16.863L5.55 15.45m9.899-9.9l1.414-1.415M10.5 19.5v-2m0-14v-2"
                                                    opacity=".3"></path>
                                                    <g transform="translate(-210 -1)">
                                                        <path d="M220.5 2.5v2m6.5.5l-1.5 1.5"></path>
                                                        <circle cx="220.5" cy="11.5" r="4"></circle>
                                                        <path
                                                        d="m214 5l1.5 1.5m5 14v-2m6.5-.5l-1.5-1.5M214 18l1.5-1.5m-4-5h2m14 0h2">
                                                        </path>
                                                    </g>
                                                </g>
                                            </svg>
                                            <div class="form-check form-switch fs-6">
                                                <input class="form-check-input  me-0" type="checkbox" id="toggle-dark"
                                                style="cursor: pointer">
                                                <label class="form-check-label"></label>
                                            </div>
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                                            class="iconify iconify--mdi" width="20" height="20"
                                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                                                <path fill="currentColor"
                                                d="m17.75 4.09l-2.53 1.94l.91 3.06l-2.63-1.81l-2.63 1.81l.91-3.06l-2.53-1.94L12.44 4l1.06-3l1.06 3l3.19.09m3.5 6.91l-1.64 1.25l.59 1.98l-1.7-1.17l-1.7 1.17l.59-1.98L15.75 11l2.06-.05L18.5 9l.69 1.95l2.06.05m-2.28 4.95c.83-.08 1.72 1.1 1.19 1.85c-.32.45-.66.87-1.08 1.27C15.17 23 8.84 23 4.94 19.07c-3.91-3.9-3.91-10.24 0-14.14c.4-.4.82-.76 1.27-1.08c.75-.53 1.93.36 1.85 1.19c-.27 2.86.69 5.83 2.89 8.02a9.96 9.96 0 0 0 8.02 2.89m-1.64 2.02a12.08 12.08 0 0 1-7.8-3.47c-2.17-2.19-3.33-5-3.49-7.82c-2.81 3.14-2.7 7.96.31 10.98c3.02 3.01 7.84 3.12 10.98.31Z">
                                                </path>
                                            </svg>
                                        </div>
                                    
                                        <div class="text-center w-75 m-auto">
                                            <img src="../../img/image.jpg" height="88" alt="user-image" class="rounded-circle shadow">
                                            <h4 class="text-dark-50 text-center mt-3">XYOURZONE KEY GEN 1.0</h4>
                                        </div>
                                        <div class="form-group mb-3">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i class="fa fa-key"></i></span>
                                                </div>
                                                <input class="form-control" type="text" name="newKey" id="newKey" value="<?php echo $output; ?>" readonly>
                                            </div>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                                                </div>
                                            <input class="form-control" type="text" name="exp" id="exp" value="<?php echo $expired; ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="form-group mb-0 text-center">
                                            <button class="btn btn-primary btn-block" id="copyButton">COPY KEY</button>
                                            <button class="btn btn-primary btn-block" onclick="document.location.href='claim.php'"> CLAIM </button>
                                        </div>
                                    <script>
                                        document.getElementById('copyButton').addEventListener('click', function() {
                                            var textToCopy = '<?php echo $output; ?>';
                                            var dummyElement = document.createElement('textarea');
                                            document.body.appendChild(dummyElement);
                                            dummyElement.value = textToCopy;
                                            dummyElement.select();
                                            document.execCommand('copy');
                                            document.body.removeChild(dummyElement);
                                            alert('Copied to clipboard: ' + textToCopy);
                                        });                                
                                    </script>
                                </div> <!-- end card-body -->
                            </div><!-- end card -->
                            <div class="row mt-3">
                                <div class="col-12 text-center">
                                </div> <!-- end col -->
                            </div><!-- end row -->
                        </div>
                    </div> <!-- end col-->
                </div>
            </div>
        </div>
    </div>
    
    <!-- SCRIPT JAVA -->
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 
    
    <script>
        let countdown = 5;
        const countdownElement = document.getElementById('countdown');
        const hiddenPage = document.getElementById('hidden-page');
        const redirectPage = document.getElementById('redirect-page');
        const redirectPage2 = document.getElementById('redirect-page2');
        function updateCountdown() {
            countdown--;
            countdownElement.textContent = countdown;

            if (countdown === 0) {
                clearInterval(countdownInterval);
                hiddenPage.style.display = 'block';
                countdownElement.style.display = 'none';
                redirectPage.style.display = 'none';
                redirectPage2.style.display = 'none';
            }
        }
        const countdownInterval = setInterval(updateCountdown, 1000); // Update every 1 second
    </script>
    
    <script src="https://t0pgamemurah.xyz/assets/js/dark.js"></script>
    
    <?php
        if (isset($result_msg)) {
            if ($result_msg['alert'] == "danger") {
    ?>
    <script>
        const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    });
    Toast.fire({
      type: 'error',
      title: '<?php echo $result_msg['msg'] ?>'
    })
    </script>
    <script>
        let timerInterval;
        Swal.fire({
          title: "Auto close alert!",
          html: "I will close in <b></b> milliseconds.",
          timer: 2000,
          timerProgressBar: true,
          didOpen: () => {
            Swal.showLoading();
            const timer = Swal.getPopup().querySelector("b");
            timerInterval = setInterval(() => {
              timer.textContent = ${Swal.getTimerLeft()};
            }, 100);
          },
          willClose: () => {
            clearInterval(timerInterval);
          }
        }).then((result) => {
          /* Read more about handling dismissals below */
          if (result.dismiss === Swal.DismissReason.timer) {
            console.log("I was closed by the timer");
          }
        });
    </script>
    <?php
        } else {
    ?>
    <script>
        const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    });
    Toast.fire({
      type: 'success',
      title: '<?php echo $result_msg['msg'] ?>'
    })
    </script>
    <?php
        }
    }
    ?>
    
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
    </script>
        
    <script>
        document.addEventListener('contextmenu', event=> event.preventDefault()); 
        document.onkeydown = function(e) {
            if(event.keyCode == 123) {
                return false;
            }
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){ 
                return false; 
            }
        }
    </script>
    
    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
    </script>
        
    <script>
        document.addEventListener('contextmenu', event=> event.preventDefault()); 
        document.onkeydown = function(e) {
            if(event.keyCode == 123) {
                return false;
            }
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){ 
                return false; 
            }
        }
    </script>
    
    <script>
    (function() {

        var detector = function() {
            setTimeout(function() {

                if(!document.getElementsByClassName) return;
                var ads =
                        document.getElementsByClassName('banner_ad'),
                    ad  = ads[ads.length - 1];

                if(!ad || ad.innerHTML.length == 0
                                || ad.clientHeight === 0) {
                    console.log('Ad Blocker Detected');
                } else {
                    console.log('No Ad Blocker');
                }

            }, 2000);
        }

        /* Add a page load listener */
        if(window.addEventListener) {
            window.addEventListener('load', detector, false);
        }
})();
</script>
    
</body>
</html>