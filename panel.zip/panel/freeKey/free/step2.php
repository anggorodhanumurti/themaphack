<?php

require '../../app/mainconfig.php';

date_default_timezone_set('Asia/Jakarta');

session_start();

function getkey() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array();
    $alphaLength = strlen($alphabet) - 1;
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass);
}

function getIP(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }else{
        if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        }else{
            return $_SERVER['REMOTE_ADDR'];
        }
    }
}

if ($config['web']['maintenance'] == 1) {
	$result = array('status' => false, 'data' => array('msg' => 'Maintenance'));
	exit(json_encode($result, JSON_PRETTY_PRINT));
}
if ($config['web']['FreeToken'] == 1) {
	$result = array('status' => false, 'data' => array('msg' => 'Key Gen Temporary Closed!'));
	exit(json_encode($result, JSON_PRETTY_PRINT));
}

if($_POST['server'] == 0) {
    $msg = 'Choose The Server';
    $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
}
/*
if ($_POST['server'] == 3) {
    if($_POST['game'] == 0) {
        $msg = 'Choose The Game';
        $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
    }else{
        $s_key = strtoupper(getkey());
        $pgen = $model->db_query($db, "*", "categories", "id = '".$_POST['game']."'");
        $lock = base64_encode(getIP()."::".$s_key);
        $_SESSION['generate'] = array('data' => getIP(), 'key' => $s_key, 'game' => $pgen['rows']['name'], 'sttusLock' => $lock, 'time' => $pgen['rows']['time']);
        die(header("Location: https://paid4link.com/st?api=4603bbb969bc4120a7643dc478f041039b74d9ee&url=https://t0pgamemurah.xyz/datZ/gen-key/free/checkingData.php"."?data=".$lock));
    }
}
if ($_POST['server'] == 2) {
    if($_POST['game'] == 0) {
        $msg = 'Choose The Game';
        $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
    }else{
        $s_key = strtoupper(getkey());
        $pgen = $model->db_query($db, "*", "categories", "id = '".$_POST['game']."'");
        $lock = base64_encode(getIP()."::".$s_key);
        $_SESSION['generate'] = array('data' => getIP(), 'key' => $s_key, 'game' => $pgen['rows']['name'], 'sttusLock' => $lock, 'time' => $pgen['rows']['time']);
        die(header("Location: https://shrinkme.io/st?api=c24d3de794f584c7440b01f810109b5de2dac824&url=https://t0pgamemurah.xyz/datZ/gen-key/free/checkingData.php"."?data=".$lock));
    }
} */
if($_GET['data']){
    if ($_POST['server'] == 1) {
        if($_POST['game'] == 0) {
            $msg = 'Choose The Game';
            $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
        } else if ($_POST['captchaText'] && ($_POST['captchaText']!="")){
        	if(strcasecmp($_SESSION['captchaCode'], $_POST['captchaText']) != 0){
        	    $msg = 'It seems you have entered invalid captcha code! Please try again.';
                $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
        	}else{
        	    $msg = 'Your captcha code have been matched successfully.';
                $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
                $s_key = strtoupper(getkey());
                $pgen = $model->db_query($db, "*", "categories", "id = '".$_POST['game']."'");
                $lock = base64_encode(getIP()."::".$s_key);
                $_SESSION['generate'] = array('data' => getIP(), 'key' => $s_key, 'game' => $pgen['rows']['name'], 'sttusLock' => $lock, 'time' => $pgen['rows']['time']);
                die(header("Location: https://shrinkme.io/st?api=c24d3de794f584c7440b01f810109b5de2dac824&url=https://t0pgamemurah.xyz/datZ/gen-key/free/checkingData.php"."?data=".$lock));
        	}
        } else {
        	$msg = 'Enter Captcha Code';
            $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
        }
        
    }
}
if ($_POST['server'] == 4) {
    if($_POST['game'] == 0) {
        $msg = 'Choose The Game';
        $result_msg = array('alert' => 'danger', 'title' => 'Error!', 'msg' => $msg);
    }else{
        $s_key = strtoupper(getkey());
        $pgen = $model->db_query($db, "*", "categories", "id = '".$_POST['game']."'");
        $lock = base64_encode(getIP()."::".$s_key);
        $_SESSION['generate'] = array('data' => getIP(), 'key' => $s_key, 'game' => $pgen['rows']['name'], 'sttusLock' => $lock, 'time' => $pgen['rows']['time']);
        die(header("Location: https://vipurl.in/st?api=8116c8f21f542e7f64af40e6afd03eccb07a3529&url=https://t0pgamemurah.xyz/datZ/gen-key/free/checkingData.php"."?data=".$lock));
    }
}



?>
<?php
require '../../app/lib/partials/head-css.php';
require '../../app/lib/partials/title-meta.php';
$data = $model->db_query($db, "*", "pgen", "id = '1'");
$query_list = "SELECT * FROM categories WHERE status = '1' ORDER BY id DESC";
$records_per_page = 40;
$starting_position = 0;
$new_query = $query_list." LIMIT $starting_position, $records_per_page";
$new_query = mysqli_query($db, $new_query);
?>
<?php $profile = $model->db_query($db, "*", "profile" ,"token_key='D5-ADMIN-KJZW3'"); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<body>
    <div class="text_ads"> </div>
    <div id="app" data-bs-theme="light" class="text-ad-links">
        <div class="container-fluid d-flex align-items-center vh-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-7 col-lg-6 col-xl-5 col-xxl-4">
                        <div class="card m-0" data-aos="zoom-in">
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="theme-toggle d-flex gap-2  align-items-center mt-3 mt-sm-0">
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                                            class="iconify iconify--system-uicons" width="20" height="20"
                                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 21 21">
                                            <g fill="none" fill-rule="evenodd" stroke="currentColor"
                                                stroke-linecap="round" stroke-linejoin="round">
                                                <path
                                                    d="M10.5 14.5c2.219 0 4-1.763 4-3.982a4.003 4.003 0 0 0-4-4.018c-2.219 0-4 1.781-4 4c0 2.219 1.781 4 4 4zM4.136 4.136L5.55 5.55m9.9 9.9l1.414 1.414M1.5 10.5h2m14 0h2M4.135 16.863L5.55 15.45m9.899-9.9l1.414-1.415M10.5 19.5v-2m0-14v-2"
                                                    opacity=".3"></path>
                                                <g transform="translate(-210 -1)">
                                                    <path d="M220.5 2.5v2m6.5.5l-1.5 1.5"></path>
                                                    <circle cx="220.5" cy="11.5" r="4"></circle>
                                                    <path
                                                        d="m214 5l1.5 1.5m5 14v-2m6.5-.5l-1.5-1.5M214 18l1.5-1.5m-4-5h2m14 0h2">
                                                    </path>
                                                </g>
                                            </g>
                                        </svg>
                                        <div class="form-check form-switch fs-6">
                                            <input class="form-check-input  me-0" type="checkbox" id="toggle-dark"
                                                style="cursor: pointer">
                                            <label class="form-check-label"></label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img"
                                            class="iconify iconify--mdi" width="20" height="20"
                                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="m17.75 4.09l-2.53 1.94l.91 3.06l-2.63-1.81l-2.63 1.81l.91-3.06l-2.53-1.94L12.44 4l1.06-3l1.06 3l3.19.09m3.5 6.91l-1.64 1.25l.59 1.98l-1.7-1.17l-1.7 1.17l.59-1.98L15.75 11l2.06-.05L18.5 9l.69 1.95l2.06.05m-2.28 4.95c.83-.08 1.72 1.1 1.19 1.85c-.32.45-.66.87-1.08 1.27C15.17 23 8.84 23 4.94 19.07c-3.91-3.9-3.91-10.24 0-14.14c.4-.4.82-.76 1.27-1.08c.75-.53 1.93.36 1.85 1.19c-.27 2.86.69 5.83 2.89 8.02a9.96 9.96 0 0 0 8.02 2.89m-1.64 2.02a12.08 12.08 0 0 1-7.8-3.47c-2.17-2.19-3.33-5-3.49-7.82c-2.81 3.14-2.7 7.96.31 10.98c3.02 3.01 7.84 3.12 10.98.31Z">
                                            </path>
                                        </svg>
                                    </div>
                                    <h4 class="mb-0"><strong>STEP 2</strong></h4>
                                    
                                    <div class="text-left mt-3">
                                        <form method="POST">
                                            <div class="form-group">
                                                <label>Game</label>
                                                <select class="form-control" name="game" id="game">
                                                    <option value="0">Select Game...</option>
                                                    <?php
                                                    while ($data_query = mysqli_fetch_assoc($new_query)) {
                                                    ?>
                                                    <option value="<?php echo $data_query['id']?>"><?php echo $data_query['name'] ?></option>
                                                    <?php
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                            <div class="form-group mb-3">
                                                <label>Server</label>
                                                <select class="form-control" name="server" id="server">
                                                    <option value="0">Select Server..</option>
                                                    <option value="1">Server 1 </option>
                                                </select>
                                            </div>
                                            
                                            <form name="form" class="form" action="" method="post">								
                            					<div class="form-group">
                            						<label for="captcha" class="text-info">
                            						<?php if($statusMessage) { ?>
                            							<span class="text-danger"><strong><?php echo $statusMessage; ?></strong></span>
                            						<?php } ?>	
                            						</label><br>
                            						<input type="text" name="captchaText" id="captchaText" class="form-control" placeholder="Enter Captcha code" required>
                            					</div>
                            					<div class="form-group">								
                            						<img src="../captcha.php?rand=<?php echo rand(); ?>" id='captchaCode'>
                            						<br>
                            						<p><br>Wants new Captcha code? <a href="javascript:void(0)" id="refreshCaptchaCode">refresh</a></p>
                            					</div>										
                            					<div class="form-group">	
                            						<input type="submit" name="submit" class="btn btn-info btn-md" value="Submit">								
                            					</div>							
                            				</form>
                                            
                                            <div class="form-group mb-0 text-center">
                                                <!--
                                                <button class="btn btn-primary btn-block" type="submit"> Get Key </button> -->
                                            </div>
                                        </form>
                                    </div>
                                </div> <!-- end col-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="rightbar-overlay"></div>
    
    <script src="ads-frontend.min.js"></script>
    
    <!--
    <script type="text/javascript" src="adblock.js"></script>

    <script type="text/javascript">
        detectAdblock().then((res) => {
            alert(`Using Adblockers: ${JSON.stringify(res)}`);
            alert("Disable Adblock Fucking Ashole");
            location.reload();
        });
    </script> -->
    
    <script src="https://t0pgamemurah.xyz/datZ/assets/js/dark.js"></script>
    <script src="https://t0pgamemurah.xyz/datZ/assets/js/perfect-scrollbar.min.js"></script>
    <script src="https://t0pgamemurah.xyz/datZ/assets/js/app.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.3.2/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="captcha_code.js"></script>
    <?php
        if (isset($result_msg)) {
            if ($result_msg['alert'] == "danger") {
    ?>
    <script>
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
    Toast.fire({
      type: 'error',
      title: '<?php echo $result_msg['msg'] ?>'
    })
  </script>
  <?php
    } else {
  ?>
  <script>
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
    Toast.fire({
      type: 'success',
      title: '<?php echo $result_msg['msg'] ?>'
    })
  </script>
  <?php
    }
  }
  ?>

    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());
    </script>
        
    <script>
        document.addEventListener('contextmenu', event=> event.preventDefault()); 
        document.onkeydown = function(e) {
            if(event.keyCode == 123) {
                return false;
            }
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){ 
                return false; 
            } 
            if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){ 
                return false; 
            }
        }
    </script>
    
    <script>
    (function() {

        var detector = function() {
            setTimeout(function() {

                if(!document.getElementsByClassName) return;
                var ads =
                        document.getElementsByClassName('banner_ad'),
                    ad  = ads[ads.length - 1];

                if(!ad || ad.innerHTML.length == 0
                                || ad.clientHeight === 0) {
                    console.log('Ad Blocker Detected');
                } else {
                    console.log('No Ad Blocker');
                }

            }, 2000);
        }

        /* Add a page load listener */
        if(window.addEventListener) {
            window.addEventListener('load', detector, false);
        }
})();
</script>
    
</body>
</html>
<?php
//require '../lib/footer.php';
?>