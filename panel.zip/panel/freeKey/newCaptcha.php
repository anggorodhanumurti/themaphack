<?php
// Fungsi untuk menghasilkan gambar dengan teks terdistorsi
function generateCaptchaImage($text) {
    // Buat gambar baru
    $width = 200;
    $height = 50;
    $image = imagecreatetruecolor($width, $height);

    // Warna latar belakang dan teks
    $backgroundColor = imagecolorallocate($image, 255, 255, 255);
    $textColor = imagecolorallocate($image, 0, 0, 0);

    // Isi latar belakang dengan warna putih
    imagefill($image, 0, 0, $backgroundColor);

    // Tulis teks dengan font acak dan distorsi
    $fonts = array('self.ttf', 'kiddy.ttf');
    $font = $fonts[array_rand($fonts)];
    for ($i = 0; $i < strlen($text); $i++) {
        $x = rand(5, $width - 5);
        $y = rand(20, $height - 5);
        imagettftext($image, 20, rand(-20, 20), $x, $y, $textColor, $font, $text[$i]);
    }

    // Tambahkan noise untuk membuat gambar lebih sulit dibaca
    for ($i = 0; $i < 500; $i++) {
        imagesetpixel($image, rand(0, $width), rand(0, $height), $textColor);
    }

    // Simpan gambar sebagai file sementara atau tampilkan langsung
    header('Content-Type: image/png');
    imagepng($image);
    imagedestroy($image);
}


// Form untuk memasukkan jawaban pengguna
echo '<form method="post">';
echo '<img src="captcha.php" alt="CAPTCHA">';
echo '<input type="text" name="captcha_answer">';
echo '<input type="submit" value="Submit">';
echo '</form>';

// Validasi jawaban jika form telah dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (validateCaptcha($_POST['captcha_answer'], $_SESSION['captcha'])) {
        echo 'CAPTCHA benar!';
    } else {
        echo 'CAPTCHA salah!';
    }
}