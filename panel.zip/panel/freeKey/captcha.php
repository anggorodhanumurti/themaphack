<?php
$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
$captcha_string = '';
for ($i = 0; $i < 8; $i++) {
    $captcha_string .= $characters[rand(0, strlen($characters) - 1)];
}

$image = imagecreatetruecolor(190, 50);
$background_color = imagecolorallocate($image, 255, 255, 255); // White background
imagefill($image, 0, 0, $background_color);

// Font color
$text_color = imagecolorallocate($image, 0, 0, 0); // Black text
$black =imagecolorallocate($image, 0,0,0);

$fontPath = __DIR__ . '/self.ttf';

// Check if the font file exists
if (!file_exists($fontPath)) {
    die("Font file not found: $fontPath");
}

// Font file path
$font_file = $fontPath; // Replace with your font file

// Add text to image
imagettftext($image, 24, 0, 15, 39, $text_color, $font_file, $captcha_string);

// Add noise
for ($i = 0; $i < 35; $i++) {
    $x = rand(1, 150);
    $y = rand(1, 50);
    $color = imagecolorallocate($image, rand(0, 255), rand(0, 255), rand(0, 255));
    imageline($image, rand(0, 200), rand(0,50), rand(0, 200), rand(0, 50), $black);
    imagefilledellipse($image, rand(0, 200), rand(0, 50), 2, 2, $black);
    imagesetpixel($image, $x, $y, $color);
}

// Output the image
header('Content-type: image/png');
imagepng($image);
imagedestroy($image);

// Store the CAPTCHA string in a session
session_start();
$_SESSION['captchaCode'] = $captcha_string;

?>