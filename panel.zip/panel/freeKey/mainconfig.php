<?php 
if (isset($_SESSION['adblocker_detected'])) { 
?>
    header("Refresh:0");
<?php  
    // Optionally unset the session variable here
    // unset($_SESSION['adblocker_detected']);
} 
?>