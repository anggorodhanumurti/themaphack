<?php
$secretKey = 'ES_328825da63424da38cd70562e382b39a';
$siteKey = 'd4fc641a-f214-4928-bb32-bcf824822438';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $token = $_POST['h-captcha-response'];

  $verifyUrl = 'https://hcaptcha.com/siteverify';
  $data = [
    'secret' => $secretKey,
    'response' => $token,
    'remoteip' => $_SERVER['REMOTE_ADDR']
  ];

  $options = [
    'http' => [
      'method' => 'POST',
      'header' => 'Content-Type: application/x-www-form-urlencoded',
      'content' => http_build_query($data)
    ]
  ];

  $context = stream_context_create($options);
  $response = file_get_contents($verifyUrl, false, $context);

  $responseData = json_decode($response);

  if ($responseData->success) {
    // Captcha is valid, proceed with form submission
    header('Location: https://t0pgamemurah.xyz/freeKey/getKey.php');
  } else {
    // Captcha is invalid, display error message
    echo 'Captcha verification failed!';
  }
}