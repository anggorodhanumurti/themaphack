<?php

require '../../app/mainconfig.php';

date_default_timezone_set('Asia/Jakarta');

$G1 = $model->db_query($db, "*", "categories", "id = '2'");
$G1_name = $G1['rows']['name'];
$G1_static = $G1['rows']['static'];
$G1_satus = $G1['rows']['status'];
$G1_version = $G1['rows']['appver'];

$G2 = $model->db_query($db, "*", "categories", "id = '1'");
$G2_name = $G2['rows']['name'];
$G2_static = $G2['rows']['static'];
$G2_satus = $G2['rows']['status'];
$G2_version = $G2['rows']['appver'];

$G3 = $model->db_query($db, "*", "categories", "id = '3'");
$G3_name = $G3['rows']['name'];
$G3_static = $G3['rows']['static'];
$G3_satus = $G3['rows']['status'];
$G3_version = $G3['rows']['appver'];

$G4 = $model->db_query($db, "*", "categories", "id = '6'");
$G4_name = $G4['rows']['name'];
$G4_static = $G4['rows']['static'];
$G4_satus = $G4['rows']['status'];
$G4_version = $G4['rows']['appver'];

$G5 = $model->db_query($db, "*", "categories", "id = '4");
$G5_name = $G5['rows']['name'];
$G5_static = $G5['rows']['static'];
$G5_satus = $G5['rows']['status'];
$G5_version = $G5['rows']['appver'];

$G6 = $model->db_query($db, "*", "categories", "id = '5");
$G6_name = $G6['rows']['name'];
$G6_static = $G6['rows']['static'];
$G6_satus = $G6['rows']['status'];
$G6_version = $G6['rows']['appver'];

if ($_POST){
	if (check_input($_POST, array('user_key', 'serial', 'game')) == false) {
		$result = array('status' => false, 'data' => array('reason' => 'Inappropriate request'));
	} else {
		if ($_POST['game'] == $G1_name) {
			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G1_name."'")) {
			    if (mysqli_num_rows($ress) == 1) {
    			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
    					$result = array('status' => false, 'reason' => 'Input Your Key');
    				} else {
    				    if($cek1['count'] > 0){
            				if($cek1['rows']['status'] != 2) {
            					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
            				}else{
            					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
            					$slot = $cek2['rows']['cheat_slot'];
            					$vip = false;
            					if ($cek2['rows']['vip'] == 1) {
            						$vip = true;
            					}
            
            					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
            					$stime =  time();
            					$serial = "";
            					$time1 = new DateTime(date("Y-m-d H:i:s"));
            					$time2 = new DateTime($cek2['rows']['cheat_exp']);
            					$interval = $time1->diff($time2)->format("%r%a");
            					$jam = $time1->diff($time2)->format("%r%h");
            					$sisa = "$interval hari $jam jam";
            					$min = intval($cek2['rows']['cheat_slot']) - 1;
            					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
            					$myArray = array(
                					'token'=> $enc,
                					'MOD_NAME'      => $cek1['rows']['brand'],
                					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                					'EXP'           => $cek2['rows']['cheat_exp'],
                					'MOD_SLOT'      => $cek2['rows']['slot'],
                					'device'        => $cek2['rows']['slot'],
                					'MOD_STATUS'    => 'Safe',
                					'isVip'         => $cek2['rows']['vip'],
                					'iniVip'        => $cek2['rows']['vip'],
                					'DURASI'        => $sisa,
                					'rng'           => $stime,
                					'client'        => $cek2['rows']['data'],
                					'AutoSkills'    => 'on',
                					'serial'        => $_POST['serial']
            					);
            					if ($cek2['count'] == 0) { //if serial is zero
            						$result = array('status' => false, 'reason' => 'Key Invalid');
            					} else {
            						if ($cek2['rows']['active'] == 0) {
            							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
            							$result = array('status' => true, 'data' => $myArray);
            							}else{
            							$result = array('status' => false, 'reason' => 'Try Again');
            							}
            						} else {
            							if($cek2['rows']['serial'] == 0){
            								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
            									$result = array('status' => true, 'data' => $myArray);
            									}else{
            									$result = array('status' => false, 'reason' => 'Try Again');
            									}
            								}
            							}else{
            								if($_POST['serial'] == $cek2['rows']['serial']){
            									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
            										$result = array('status' => true, 'data' => $myArray);
            									} else {
            										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
            											$result = array('status' => false, 'reason' => 'Expired Key');
            										}else {
            											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
            										}
            									}
            								}else{
            									$result = array('status' => false, 'reason' => 'Invalid Device'); 
            								}
            							}
            						}
            					}
            				}
            			}
    				}
			    }else {
            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
            	}
			}
		} else {
		    if ($_POST['game'] == $G2_name) {
    			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
    			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G2_name."'")) {
    			    if (mysqli_num_rows($ress) == 1) {
        			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
        					$result = array('status' => false, 'reason' => 'Input Your Key');
        				} else {
        				    if($cek1['count'] > 0){
                				if($cek1['rows']['status'] != 1) {
                					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
                				}else{
                					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
                					$slot = $cek2['rows']['cheat_slot'];
                					$vip = false;
                					if ($cek2['rows']['vip'] == 1) {
                						$vip = true;
                					}
                
                					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
                					$stime =  time();
                					$serial = "";
                					$time1 = new DateTime(date("Y-m-d H:i:s"));
                					$time2 = new DateTime($cek2['rows']['cheat_exp']);
                					$interval = $time1->diff($time2)->format("%r%a");
                					$jam = $time1->diff($time2)->format("%r%h");
                					$sisa = "$interval hari $jam jam";
                					$min = intval($cek2['rows']['cheat_slot']) - 1;
                					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                					$myArray = array(
                    					'token'=> $enc,
                    					'MOD_NAME'      => $cek1['rows']['brand'],
                    					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                    					'EXP'           => $cek2['rows']['cheat_exp'],
                    					'MOD_SLOT'      => $cek2['rows']['slot'],
                    					'device'        => $cek2['rows']['slot'],
                    					'MOD_STATUS'    => 'Safe',
                    					'isVip'         => $cek2['rows']['vip'],
                    					'iniVip'        => $cek2['rows']['vip'],
                    					'DURASI'        => $sisa,
                    					'rng'           => $stime,
                    					'client'        => $cek2['rows']['data'],
                    					'AutoSkills'    => 'on',
                    					'serial'        => $_POST['serial']
                					);
                					if ($cek2['count'] == 0) { //if serial is zero
                						$result = array('status' => false, 'reason' => 'Key Invalid');
                					} else {
                						if ($cek2['rows']['active'] == 0) {
                							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
                							$result = array('status' => true, 'data' => $myArray);
                							}else{
                							$result = array('status' => false, 'reason' => 'Try Again');
                							}
                						} else {
                							if($cek2['rows']['serial'] == 0){
                								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
                									$result = array('status' => true, 'data' => $myArray);
                									}else{
                									$result = array('status' => false, 'reason' => 'Try Again');
                									}
                								}
                							}else{
                								if($_POST['serial'] == $cek2['rows']['serial']){
                									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                										$result = array('status' => true, 'data' => $myArray);
                									} else {
                										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
                											$result = array('status' => false, 'reason' => 'Expired Key');
                										}else {
                											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
                										}
                									}
                								}else{
                									$result = array('status' => false, 'reason' => 'Invalid Device'); 
                								}
                							}
                						}
                					}
                				}
                			}
        				}
    			    }else {
                	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
                	}
    			}
    		} else {
    		    if ($_POST['game'] == $G3_name) {
        			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
        			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G3_name."'")) {
        			    if (mysqli_num_rows($ress) == 1) {
            			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
            					$result = array('status' => false, 'reason' => 'Input Your Key');
            				} else {
            				    if($cek1['count'] > 0){
                    				if($cek1['rows']['status'] != 1) {
                    					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
                    				}else{
                    					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
                    					$slot = $cek2['rows']['cheat_slot'];
                    					$vip = false;
                    					if ($cek2['rows']['vip'] == 1) {
                    						$vip = true;
                    					}
                    
                    					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
                    					$stime =  time();
                    					$serial = "";
                    					$time1 = new DateTime(date("Y-m-d H:i:s"));
                    					$time2 = new DateTime($cek2['rows']['cheat_exp']);
                    					$interval = $time1->diff($time2)->format("%r%a");
                    					$jam = $time1->diff($time2)->format("%r%h");
                    					$sisa = "$interval hari $jam jam";
                    					$min = intval($cek2['rows']['cheat_slot']) - 1;
                    					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                    					$myArray = array(
                        					'token'=> $enc,
                        					'MOD_NAME'      => $cek1['rows']['brand'],
                        					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                        					'EXP'           => $cek2['rows']['cheat_exp'],
                        					'MOD_SLOT'      => $cek2['rows']['slot'],
                        					'device'        => $cek2['rows']['slot'],
                        					'MOD_STATUS'    => 'Safe',
                        					'isVip'         => $cek2['rows']['vip'],
                        					'iniVip'        => $cek2['rows']['vip'],
                        					'DURASI'        => $sisa,
                        					'rng'           => $stime,
                        					'client'        => $cek2['rows']['data'],
                        					'AutoSkills'    => 'on',
                        					'serial'        => $_POST['serial']
                    					);
                    					if ($cek2['count'] == 0) { //if serial is zero
                    						$result = array('status' => false, 'reason' => 'Key Invalid');
                    					} else {
                    						if ($cek2['rows']['active'] == 0) {
                    							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
                    							$result = array('status' => true, 'data' => $myArray);
                    							}else{
                    							$result = array('status' => false, 'reason' => 'Try Again');
                    							}
                    						} else {
                    							if($cek2['rows']['serial'] == 0){
                    								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                    									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
                    									$result = array('status' => true, 'data' => $myArray);
                    									}else{
                    									$result = array('status' => false, 'reason' => 'Try Again');
                    									}
                    								}
                    							}else{
                    								if($_POST['serial'] == $cek2['rows']['serial']){
                    									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                    										$result = array('status' => true, 'data' => $myArray);
                    									} else {
                    										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
                    											$result = array('status' => false, 'reason' => 'Expired Key');
                    										}else {
                    											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
                    										}
                    									}
                    								}else{
                    									$result = array('status' => false, 'reason' => 'Invalid Device'); 
                    								}
                    							}
                    						}
                    					}
                    				}
                    			}
            				}
        			    }else {
                    	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
                    	}
        			}
        		} else {
        		    if ($_POST['game'] == $G4_name) {
            			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
            			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G4_name."'")) {
            			    if (mysqli_num_rows($ress) == 1) {
                			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
                					$result = array('status' => false, 'reason' => 'Input Your Key');
                				} else {
                				    if($cek1['count'] > 0){
                        				if($cek1['rows']['status'] != 1) {
                        					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
                        				}else{
                        					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
                        					$slot = $cek2['rows']['cheat_slot'];
                        					$vip = false;
                        					if ($cek2['rows']['vip'] == 1) {
                        						$vip = true;
                        					}
                        
                        					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
                        					$stime =  time();
                        					$serial = "";
                        					$time1 = new DateTime(date("Y-m-d H:i:s"));
                        					$time2 = new DateTime($cek2['rows']['cheat_exp']);
                        					$interval = $time1->diff($time2)->format("%r%a");
                        					$jam = $time1->diff($time2)->format("%r%h");
                        					$sisa = "$interval hari $jam jam";
                        					$min = intval($cek2['rows']['cheat_slot']) - 1;
                        					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                        					$myArray = array(
                            					'token'=> $enc,
                            					'MOD_NAME'      => $cek1['rows']['brand'],
                            					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                            					'EXP'           => $cek2['rows']['cheat_exp'],
                            					'MOD_SLOT'      => $cek2['rows']['slot'],
                            					'device'        => $cek2['rows']['slot'],
                            					'MOD_STATUS'    => 'Safe',
                            					'isVip'         => $cek2['rows']['vip'],
                            					'iniVip'        => $cek2['rows']['vip'],
                            					'DURASI'        => $sisa,
                            					'rng'           => $stime,
                            					'client'        => $cek2['rows']['data'],
                            					'AutoSkills'    => 'on',
                            					'serial'        => $_POST['serial']
                        					);
                        					if ($cek2['count'] == 0) { //if serial is zero
                        						$result = array('status' => false, 'reason' => 'Key Invalid');
                        					} else {
                        						if ($cek2['rows']['active'] == 0) {
                        							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
                        							$result = array('status' => true, 'data' => $myArray);
                        							}else{
                        							$result = array('status' => false, 'reason' => 'Try Again');
                        							}
                        						} else {
                        							if($cek2['rows']['serial'] == 0){
                        								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                        									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
                        									$result = array('status' => true, 'data' => $myArray);
                        									}else{
                        									$result = array('status' => false, 'reason' => 'Try Again');
                        									}
                        								}
                        							}else{
                        								if($_POST['serial'] == $cek2['rows']['serial']){
                        									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                        										$result = array('status' => true, 'data' => $myArray);
                        									} else {
                        										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
                        											$result = array('status' => false, 'reason' => 'Expired Key');
                        										}else {
                        											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
                        										}
                        									}
                        								}else{
                        									$result = array('status' => false, 'reason' => 'Invalid Device'); 
                        								}
                        							}
                        						}
                        					}
                        				}
                        			}
                				}
            			    }else {
                        	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
                        	}
            			}
            		} else {
            		    if ($_POST['game'] == $G5_name) {
                			$cek1 = $model->db_query($db, "*", "categories", "name = '".$_POST['game']."'");
                			if ($ress = mysqli_query($db, "SELECT * FROM token WHERE access_key = '".$_POST['user_key']."' AND games = '".$G5_name."'")) {
                			    if (mysqli_num_rows($ress) == 1) {
                    			    if (!$_POST['game'] or !$_POST['user_key'] or !$_POST['serial']){
                    					$result = array('status' => false, 'reason' => 'Input Your Key');
                    				} else {
                    				    if($cek1['count'] > 0){
                            				if($cek1['rows']['status'] != 1) {
                            					$result = array('status' => false, 'reason' => 'Service Under Maintenance');
                            				}else{
                            					$cek2 = $model->db_query($db, "*", "token", "access_key='".$_POST['user_key']."'");
                            					$slot = $cek2['rows']['cheat_slot'];
                            					$vip = false;
                            					if ($cek2['rows']['vip'] == 1) {
                            						$vip = true;
                            					}
                            
                            					$enc = md5($_POST['game']."-".$_POST['user_key']."-".$_POST['serial']."-".$cek1['rows']['static']);
                            					$stime =  time();
                            					$serial = "";
                            					$time1 = new DateTime(date("Y-m-d H:i:s"));
                            					$time2 = new DateTime($cek2['rows']['cheat_exp']);
                            					$interval = $time1->diff($time2)->format("%r%a");
                            					$jam = $time1->diff($time2)->format("%r%h");
                            					$sisa = "$interval hari $jam jam";
                            					$min = intval($cek2['rows']['cheat_slot']) - 1;
                            					$besok = date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))));
                            					$myArray = array(
                                					'token'=> $enc,
                                					'MOD_NAME'      => $cek1['rows']['brand'],
                                					'MOD_EXP'       => $cek2['rows']['cheat_exp'],
                                					'EXP'           => $cek2['rows']['cheat_exp'],
                                					'MOD_SLOT'      => $cek2['rows']['slot'],
                                					'device'        => $cek2['rows']['slot'],
                                					'MOD_STATUS'    => 'Safe',
                                					'isVip'         => $cek2['rows']['vip'],
                                					'iniVip'        => $cek2['rows']['vip'],
                                					'DURASI'        => $sisa,
                                					'rng'           => $stime,
                                					'client'        => $cek2['rows']['data'],
                                					'AutoSkills'    => 'on',
                                					'serial'        => $_POST['serial']
                            					);
                            					if ($cek2['count'] == 0) { //if serial is zero
                            						$result = array('status' => false, 'reason' => 'Key Invalid');
                            					} else {
                            						if ($cek2['rows']['active'] == 0) {
                            							if($model->db_update($db, "token", array('serial' => $_POST['serial'], 'active' => 1, 'cheat_exp' => date('Y-m-d H:i:s', strtotime("+".$cek2['rows']['durasi']." day", strtotime(date("Y-m-d H:i:s"))))), "access_key = '".$_POST['user_key']."'") == true){
                            							$result = array('status' => true, 'data' => $myArray);
                            							}else{
                            							$result = array('status' => false, 'reason' => 'Try Again');
                            							}
                            						} else {
                            							if($cek2['rows']['serial'] == 0){
                            								if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                            									if($model->db_update($db, "token", array('serial' => $_POST['serial']), "access_key = '".$_POST['user_key']."'") == true){
                            									$result = array('status' => true, 'data' => $myArray);
                            									}else{
                            									$result = array('status' => false, 'reason' => 'Try Again');
                            									}
                            								}
                            							}else{
                            								if($_POST['serial'] == $cek2['rows']['serial']){
                            									if(date("Y-m-d H:i:s") < $cek2['rows']['cheat_exp']){
                            										$result = array('status' => true, 'data' => $myArray);
                            									} else {
                            										if ($model->db_delete($db, "token", "access_key = '".$_POST['user_key']."'") == true) {
                            											$result = array('status' => false, 'reason' => 'Expired Key');
                            										}else {
                            											$result = array('status' => false, 'reason' => 'Error To Get key Data'); 
                            										}
                            									}
                            								}else{
                            									$result = array('status' => false, 'reason' => 'Invalid Device'); 
                            								}
                            							}
                            						}
                            					}
                            				}
                            			}
                    				}
                			    }else {
                            	    $result = array('status' => false, 'reason' => 'Key Games Not Valid');
                            	}
                			}
                		} else {
                            $result = array('status' => false, 'reason' => 'Key Expired or Not Register in This Game');
                        }
            		}
        		}
    		}
    		
		}
    } print(json_encode($result, JSON_PRETTY_PRINT));
} else{
  require '../../app/lib/partials/head-css.php';
  require '../../app/lib/partials/title-meta.php';
?>

</html>

<?php
}
?>
